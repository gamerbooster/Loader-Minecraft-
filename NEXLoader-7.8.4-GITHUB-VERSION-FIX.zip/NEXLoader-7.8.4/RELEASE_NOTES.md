# NEXLoader 7.8.3.3

- Added central bounded ZIP/JAR member reads for the Python core, with per-class and per-JSON limits.
- Embedded Jar-in-Jar extraction now enforces an actual streaming decompression ceiling.
- Java class scanning skips oversized class members with explicit diagnostics instead of buffering them.
- Android PackAnalyzer now uses bounded stream reads for nested JARs and metadata.
- Android file/folder imports now enforce file count, nesting and byte ceilings.
- Android conversion captures the external-download checkbox before entering the worker thread.
- Added regression tests for bounded archive reads and Android input hardening.
- Bumped Android versionCode/versionName and synchronized core metadata to 7.8.3.

## 7.7 hardening retained

- Corrupt Fabric, Quilt, Forge and NeoForge manifests fail explicitly instead of becoming an `unknown` mod.
- Empty ModPacks are marked incomplete with an `EMPTY_MODPACK` diagnostic.
- External Modrinth downloads are verified from streamed temporary files and published atomically only after integrity checks.
- Local Modrinth artifact verification hashes files incrementally.

## 7.7 worldgen retained

- Conservative Java worldgen lowering for simple ore configured features.
- Simple fixed-block worldgen lowering for supported random/vegetal patch providers.
- Simple placed-feature lowering to Bedrock scatter features for count/in-square/biome and uniform absolute height modifiers.
- Generated feature rules can attach converted placed features to converted custom biomes.
- Complex worldgen graphs remain lossless under `nex_untranslated/worldgen/` and explicit as adaptable.

Real APK generation remains gated on an actual Android SDK + Gradle environment and is not claimed unless `assembleDebug` succeeds.
