from pathlib import Path
import shutil, subprocess, textwrap, zipfile, json, sys
ROOT=Path(__file__).parents[2]
SRC=ROOT/'android/app/src/main/java/com/nex/loader/PackAnalyzer.kt'
assert SRC.exists()
base=Path('/tmp/nex70_kotlin'); shutil.rmtree(base,ignore_errors=True)
(base/'org/json').mkdir(parents=True); out=base/'out'; out.mkdir()
(base/'org/json/JSONObject.java').write_text(r'''package org.json;
import java.util.*;
public class JSONObject {
 final Map<String,Object> m;
 public JSONObject(){m=new LinkedHashMap<>();}
 public JSONObject(String s){Object v=new P(s).v(); if(!(v instanceof Map)) throw new RuntimeException("object"); m=(Map<String,Object>)v;}
 JSONObject(Map<String,Object> x){m=x;}
 public String optString(String k,String d){Object v=m.get(k); return v==null?d:String.valueOf(v);}
 public Object opt(String k){return m.get(k);}
 public JSONObject optJSONObject(String k){Object v=m.get(k); return v instanceof Map?new JSONObject((Map<String,Object>)v):null;}
 public JSONArray optJSONArray(String k){Object v=m.get(k); return v instanceof List?new JSONArray((List<Object>)v):null;}
 public Iterator<String> keys(){return m.keySet().iterator();}
 static class P{final String s; int i; P(String s){this.s=s;} void w(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
 Object v(){w(); char c=s.charAt(i); if(c=='{')return o(); if(c=='[')return a(); if(c=='\"')return q(); if(s.startsWith("true",i)){i+=4;return true;} if(s.startsWith("false",i)){i+=5;return false;} if(s.startsWith("null",i)){i+=4;return null;} int st=i; while(i<s.length()&&",]}".indexOf(s.charAt(i))<0&&!Character.isWhitespace(s.charAt(i)))i++; return s.substring(st,i);}
 Map<String,Object> o(){Map<String,Object> x=new LinkedHashMap<>(); i++; w(); if(s.charAt(i)=='}'){i++;return x;} for(;;){w();String k=q();w();if(s.charAt(i++)!=':')throw new RuntimeException();x.put(k,v());w();if(s.charAt(i)=='}'){i++;return x;}if(s.charAt(i++)!=',')throw new RuntimeException();}}
 List<Object> a(){List<Object>x=new ArrayList<>();i++;w();if(s.charAt(i)==']'){i++;return x;}for(;;){x.add(v());w();if(s.charAt(i)==']'){i++;return x;}if(s.charAt(i++)!=',')throw new RuntimeException();}}
 String q(){if(s.charAt(i++)!='\"')throw new RuntimeException();StringBuilder b=new StringBuilder();while(i<s.length()){char c=s.charAt(i++);if(c=='\"')return b.toString();if(c=='\\'&&i<s.length())c=s.charAt(i++);b.append(c);}throw new RuntimeException();}}
}''')
(base/'org/json/JSONArray.java').write_text(r'''package org.json;
import java.util.*;
public class JSONArray {
 final List<Object> l; public JSONArray(){l=new ArrayList<>();} JSONArray(List<Object>x){l=x;} public int length(){return l.size();}
 public JSONObject optJSONObject(int i){Object v=(i>=0&&i<l.size())?l.get(i):null; return v instanceof Map?new JSONObject((Map<String,Object>)v):null;}
 public String optString(int i){Object v=(i>=0&&i<l.size())?l.get(i):null; return v==null?"":String.valueOf(v);}
}''')
(base/'Test.kt').write_text(r'''package com.nex.loader
import java.nio.file.*
import java.util.zip.*
fun main(){val d=Paths.get("/tmp/nex70"); Files.createDirectories(d); val p=d.resolve("x.jar"); ZipOutputStream(Files.newOutputStream(p)).use{z->z.putNextEntry(ZipEntry("fabric.mod.json"));z.write("""{"id":"x","version":"2.0.0","depends":{"missing":">=1.0"}}""".toByteArray());z.closeEntry()}; ZipFile(p.toFile()).use{z->val r=PackAnalyzer.analyze(z,"x.jar"); check(r.mods.single().modId=="x"); check(r.missing.size==1); println("TEST70 PASS")}}''')
subprocess.run(['javac','-d',str(out),str(base/'org/json/JSONObject.java'),str(base/'org/json/JSONArray.java')],check=True)
jar=base/'analyzer.jar'
subprocess.run(['kotlinc',str(SRC),str(base/'Test.kt'),'-cp',str(out),'-include-runtime','-d',str(jar)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
r=subprocess.run(['java','-cp',f'{jar}:{out}','com.nex.loader.TestKt'],check=True,text=True,capture_output=True)
print('1 Android PackAnalyzer compile + runtime preflight: PASS')
print(r.stdout.strip())
print('ALL 1 TEST PASS')
