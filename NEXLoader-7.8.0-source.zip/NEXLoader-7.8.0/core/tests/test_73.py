from pathlib import Path
import re
ROOT=Path(__file__).parents[2]
main=ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.kt'
dir_an=ROOT/'android/app/src/main/java/com/nex/loader/DirectoryAnalyzer.kt'
build=ROOT/'android/app/build.gradle'
manifest=ROOT/'android/app/src/main/AndroidManifest.xml'
assert main.exists() and dir_an.exists() and build.exists() and manifest.exists()
main_text=main.read_text(encoding='utf-8')
dir_text=dir_an.read_text(encoding='utf-8')
build_text=build.read_text(encoding='utf-8')
manifest_text=manifest.read_text(encoding='utf-8')
assert 'class MainActivity : ComponentActivity()' in main_text
assert 'ActivityResultContracts.OpenDocument()' in main_text
assert 'ActivityResultContracts.OpenDocumentTree()' in main_text
assert 'application/zip' in main_text and 'application/octet-stream' in main_text and 'application/x-modrinth-modpack+zip' in main_text
assert 'takePersistableUriPermission' in main_text
assert 'return ZipFile(temp).use { PackAnalyzer.analyze(it, name) }' in dir_text
assert "androidx.activity:activity-ktx:1.13.0" in build_text
version=(ROOT/'VERSION').read_text(encoding='utf-8').strip(); major,minor,patch=version.split('.')
assert f'versionCode {int(major)*10+int(minor)}' in build_text and f"versionName '0.{major}.{minor}'" in build_text
assert 'android.intent.category.BROWSABLE' in manifest_text and 'application/x-modrinth-modpack+zip' in manifest_text
print('1 modern Android Activity Result/file handoff wiring: PASS')
print('2 DirectoryAnalyzer return-path compile guard: PASS')
print('3 Android version/dependency sync: PASS')
