from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
main=(ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.kt').read_text(encoding='utf-8')
pack=(ROOT/'android/app/src/main/java/com/nex/loader/PackAnalyzer.kt').read_text(encoding='utf-8')
assert 'MAX_SELECTED_INPUT_BYTES' in main
assert 'MAX_SELECTED_TREE_FILES' in main and 'MAX_SELECTED_TREE_BYTES' in main
assert 'copyLimited(' in main
assert 'fetchMissingExternals = fetchExternals.isChecked' in main
assert 'MAX_ANDROID_ZIP_MEMBER_BYTES' in pack and 'readLimited(' in pack
print('1 Android selected-file ceiling: PASS')
print('2 Android folder count/byte ceilings: PASS')
print('3 Android nested archive bounded reads: PASS')
print('4 UI option captured before worker thread: PASS')
print('ALL ANDROID HARDENING TESTS PASS')
