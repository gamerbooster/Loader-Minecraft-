#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ANDROID=ROOT/'android'
APP=ANDROID/'app'
MAIN=APP/'src/main/java/com/nex/loader/MainActivity.kt'
PACK=APP/'src/main/java/com/nex/loader/PackAnalyzer.kt'
MANIFEST=APP/'src/main/AndroidManifest.xml'
BUILD=APP/'build.gradle'
SETTINGS=ANDROID/'settings.gradle'
WRAPPER=ANDROID/'gradle/wrapper/gradle-wrapper.properties'

checks=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

check('Android project files present', all(p.is_file() for p in [MAIN,PACK,MANIFEST,BUILD,SETTINGS,WRAPPER]))
main=MAIN.read_text(encoding='utf-8'); pack=PACK.read_text(encoding='utf-8'); manifest=MANIFEST.read_text(encoding='utf-8'); build=BUILD.read_text(encoding='utf-8'); settings=SETTINGS.read_text(encoding='utf-8'); wrapper=WRAPPER.read_text(encoding='utf-8')
check('AGP 8.11.1 declared', "com.android.application' version '8.11.1'" in (ANDROID/'build.gradle').read_text())
check('Gradle 8.13 distribution declared', 'gradle-8.13-bin.zip' in wrapper)
check('Kotlin toolchain 17 declared', 'jvmToolchain(17)' in build)
check('Chaquopy 17 + Python 3.13', "com.chaquo.python'" in (ANDROID/'build.gradle').read_text() and "version = '3.13'" in build)
check('compile/target SDK 35', 'compileSdk 35' in build and 'targetSdk 35' in build)
check('Chaquopy ABIs are 64-bit', all(x in build for x in ["'arm64-v8a'","'x86_64'"]))
check('exported launcher', 'android:exported="true"' in manifest)
check('FileProvider not exported', 'android:exported="false"' in manifest and 'FileProvider' in manifest)
check('HTTPS permission', 'android.permission.INTERNET' in manifest)
check('bounded Android archive reader', 'readLimited(' in pack and 'MAX_ANDROID_ZIP_MEMBER_BYTES' in pack)
check('bounded Android input copy', 'copyLimited(' in main and 'MAX_SELECTED_INPUT_BYTES' in main)
check('folder byte/file ceilings', 'MAX_SELECTED_TREE_FILES' in main and 'MAX_SELECTED_TREE_BYTES' in main)
check('background worker captures fetch flag', 'fetchMissingExternals = fetchExternals.isChecked' in main and 'fetchMissingExternals' in main)
# Fail the source lint if new unbounded patterns are introduced in the Android analyzer/input copy.
check('no readBytes in PackAnalyzer', 'readBytes()' not in pack)
check('no copyTo in MainActivity input ingestion', 'input.copyTo' not in main)
check('embedded Python core has io_limits', (APP/'src/main/python/nexcore/nex/io_limits.py').is_file())
core=(ROOT/'core/nex/io_limits.py').read_bytes(); android_core=(APP/'src/main/python/nexcore/nex/io_limits.py').read_bytes()
check('core ↔ Android io_limits identical', core==android_core)
failed=[x for x in checks if not x[1]]
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))
print(f'ANDROID SOURCE LINT: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: raise SystemExit(1)
