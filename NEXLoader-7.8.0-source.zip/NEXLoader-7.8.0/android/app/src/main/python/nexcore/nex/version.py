NEXLOADER_VERSION = '7.8.0'
TARGET_RUNTIME='1.26.52.3'
# Bedrock pack/JSON format versions are distinct from the product runtime number.
MIN_ENGINE=[1,26,50]
SCRIPT_API='2.9.0'
SCRIPT_UI_API='2.2.0'

def target_info():
    return {'runtime':TARGET_RUNTIME,'min_engine_version':MIN_ENGINE,'script_api':SCRIPT_API,'script_ui_api':SCRIPT_UI_API}
