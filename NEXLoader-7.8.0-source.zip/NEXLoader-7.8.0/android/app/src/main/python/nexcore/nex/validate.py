import re
from .ir import Program
MOD_RE=re.compile(r'^[a-z0-9_.-]+$')
ID_RE=re.compile(r'^[a-z0-9_.-]+:[a-z0-9/_.-]+$')
VALID={'convertible','emulated','adaptable','incompatible','unknown'}
SUPPORTED={'register_block','register_item','register_recipe','register_loot_table','register_model','register_texture','register_blockstate','register_entity','register_content','event','mixin','call','capability','spawn_body','tick_body','world_message','runtime_op','remove_effect','dependency_error','teleport','damage','impulse','run_command','dynamic_property','tick','register_config','register_tag','register_language','register_sound','register_function','register_worldgen','register_entity','intermod_call','resource_conflict','entrypoint','keybind','ui_screen','hud_overlay','particle'}

def validate_program(p:Program):
    errs=[]; seen=set()
    if not MOD_RE.fullmatch(p.mod_id): errs.append(f'invalid mod_id: {p.mod_id}')
    for i,o in enumerate(p.operations):
        if o.status in {'convertible','emulated'} and o.op not in SUPPORTED: errs.append(f'unsupported convertible op {o.op}')
        if o.op in {'register_block','register_item','register_recipe','register_loot_table','register_model','register_texture','register_blockstate','register_entity'} and not ID_RE.fullmatch(o.id): errs.append(f'invalid resource id: {o.id}')
        if o.status not in VALID: errs.append(f'invalid status: {o.status}')
        key=(o.op,o.id)
        if key in seen and o.op.startswith('register_'): errs.append(f'duplicate registration: {o.op}:{o.id}')
        seen.add(key)
    return errs
