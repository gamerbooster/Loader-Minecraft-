package com.nex.loader

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Offline preflight analyzer used by the Android shell.
 * The Python core remains authoritative for full conversion; this class gives
 * the user a useful dependency/loader report before full conversion starts.
 */
data class AndroidDependency(
    val modId: String,
    val versionSpec: String,
    val mandatory: Boolean,
    val kind: String,
    val sourceMod: String,
)

data class AndroidMod(
    val modId: String,
    val version: String,
    val loader: String,
    val source: String,
    val dependencies: List<AndroidDependency>,
)

data class AndroidAnalysis(
    val kind: String,
    val mods: List<AndroidMod>,
    val missing: List<AndroidDependency>,
    val conflicts: List<String>,
    val cycles: List<List<String>>,
    val warnings: List<String>,
) {
    fun display(): String = buildString {
        appendLine("NEXLoader — análisis offline")
        appendLine("Tipo: $kind")
        appendLine("Mods detectados: ${mods.size}")
        if (mods.isNotEmpty()) {
            appendLine()
            mods.sortedBy { it.modId }.forEach { mod ->
                appendLine("• ${mod.modId} ${mod.version} [${mod.loader}]")
                appendLine("  ${mod.source}")
                mod.dependencies.forEach { dep ->
                    appendLine("  ↳ ${dep.modId} ${dep.versionSpec}${if (dep.mandatory) " (obligatoria)" else " (opcional)"}")
                }
            }
        }
        appendLine()
        appendLine("Dependencias faltantes: ${missing.size}")
        missing.forEach { appendLine("  ✗ ${it.sourceMod} → ${it.modId} ${it.versionSpec}") }
        appendLine("Conflictos: ${conflicts.size}")
        conflicts.forEach { appendLine("  ! $it") }
        appendLine("Ciclos: ${cycles.size}")
        cycles.forEach { appendLine("  ! ${it.joinToString(" → ")}") }
        appendLine("Avisos: ${warnings.size}")
        warnings.forEach { appendLine("  • $it") }
        appendLine()
        appendLine(if (missing.isEmpty() && conflicts.isEmpty() && cycles.isEmpty()) {
            "Estado: dependencias resueltas en el preflight Android"
        } else {
            "Estado: revisión necesaria antes de convertir en modo estricto"
        })
        appendLine("Nota: el conversor NEX completo es el motor Python embebido en esta versión.")
    }
}

object PackAnalyzer {
    private const val MAX_NESTED_JAR_BYTES: Long = 128L * 1024L * 1024L
    private const val MAX_METADATA_BYTES: Long = 4L * 1024L * 1024L
    private const val MAX_ANDROID_ZIP_MEMBER_BYTES: Long = 256L * 1024L * 1024L

    fun analyze(zip: ZipFile, selectedName: String): AndroidAnalysis {
        val entries = zip.entries().toList().filterNot { it.isDirectory }
        val jarEntries = entries.filter { it.name.endsWith(".jar", ignoreCase = true) }
        val isJar = selectedName.endsWith(".jar", ignoreCase = true)
        val kind = when {
            isJar -> "JAR"
            selectedName.endsWith(".mrpack", true) -> "MRPACK"
            selectedName.endsWith(".modpack", true) || jarEntries.isNotEmpty() -> "MODPACK"
            else -> "ZIP"
        }

        val mods = mutableListOf<AndroidMod>()
        val warnings = mutableListOf<String>()
        if (isJar) {
            mods += inspectArchive(zip, "selected")
        } else {
            jarEntries.sortedBy { it.name }.forEach { entry ->
                if (entry.size > MAX_NESTED_JAR_BYTES) {
                    warnings += "${entry.name}: JAR exceeds Android analyzer safety limit ($MAX_NESTED_JAR_BYTES bytes)"
                    return@forEach
                }
                val bytes = zip.getInputStream(entry).use { readLimited(it, MAX_NESTED_JAR_BYTES) }
                mods += inspectJarBytes(bytes, entry.name)
            }
        }
        if (jarEntries.isEmpty() && !isJar) warnings += "No se encontraron archivos JAR en el ModPack."
        if (!isJar && jarEntries.isNotEmpty() && mods.isEmpty() && warnings.none { it.contains("JAR exceeds") }) {
            warnings += "No se encontraron manifests válidos de mods Java en el ModPack."
        }

        val byId = linkedMapOf<String, AndroidMod>()
        val versionConflicts = mutableListOf<String>()
        mods.groupBy { it.modId }.forEach { (id, group) ->
            val distinct = group.map { it.version }.distinct().sorted()
            if (distinct.size > 1) versionConflicts += "$id versiones duplicadas: ${distinct.joinToString(", ")}"
            byId[id] = group.maxWithOrNull(Comparator { a, b -> cmp(a.version, b.version) }) ?: group.first()
        }

        val missing = mutableListOf<AndroidDependency>()
        mods.forEach { mod ->
            mod.dependencies.forEach { dep ->
                val target = byId[dep.modId]
                if (dep.kind == "conflicts" || dep.kind == "breaks") {
                    if (target != null && (dep.kind == "conflicts" || satisfies(target.version, dep.versionSpec))) {
                        versionConflicts += "${mod.modId} declara ${dep.kind} con ${dep.modId} ${dep.versionSpec} (encontró ${target.version})"
                    }
                } else if (target == null) {
                    if (dep.mandatory) missing += dep else warnings += "${mod.modId}: falta opcional ${dep.modId}"
                } else if (!satisfies(target.version, dep.versionSpec)) {
                    val msg = "${mod.modId} requiere ${dep.modId} ${dep.versionSpec}, encontró ${target.version}"
                    if (dep.mandatory) versionConflicts += msg else warnings += msg
                }
            }
        }

        val cycles = findCycles(byId.values.toList())
        return AndroidAnalysis(kind, mods, missing.distinctBy { listOf(it.sourceMod, it.modId, it.versionSpec) }, versionConflicts.distinct(), cycles, warnings.distinct())
    }

    private fun inspectArchive(zip: ZipFile, source: String): List<AndroidMod> = inspectArchiveMetadata(
        zip, source
    )

    private fun inspectArchiveMetadata(zip: ZipFile, source: String): List<AndroidMod> {
        val out = mutableListOf<AndroidMod>()
        for (name in listOf("fabric.mod.json", "quilt.mod.json", "META-INF/mods.toml", "META-INF/neoforge.mods.toml")) {
            val entry = zip.getEntry(name) ?: continue
            if (entry.size > MAX_METADATA_BYTES) continue
            val text = runCatching { zip.getInputStream(entry).use { readLimited(it, MAX_METADATA_BYTES).toString(Charsets.UTF_8) } }.getOrNull() ?: continue
            when (name) {
                "fabric.mod.json" -> parseFabric(text, source)?.also(out::add)
                "quilt.mod.json" -> parseQuilt(text, source)?.also(out::add)
                "META-INF/mods.toml" -> parseForge(text, source, "forge")?.let(out::addAll)
                "META-INF/neoforge.mods.toml" -> parseForge(text, source, "neoforge")?.let(out::addAll)
            }
        }
        return out
    }

    private fun inspectJarBytes(bytes: ByteArray, source: String): List<AndroidMod> {
        if (bytes.size.toLong() > MAX_NESTED_JAR_BYTES) return emptyList()
        val out = mutableListOf<AndroidMod>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var e: ZipEntry? = zis.nextEntry
            while (e != null) {
                if (!e.isDirectory && e.name in setOf("fabric.mod.json", "quilt.mod.json", "META-INF/mods.toml", "META-INF/neoforge.mods.toml")) {
                    val declared = e.size
                    if (declared < 0 || declared <= MAX_METADATA_BYTES) {
                        val text = readLimited(zis, MAX_METADATA_BYTES).toString(Charsets.UTF_8)
                        when (e.name) {
                            "fabric.mod.json" -> parseFabric(text, source)?.also(out::add)
                            "quilt.mod.json" -> parseQuilt(text, source)?.also(out::add)
                            "META-INF/mods.toml" -> parseForge(text, source, "forge")?.let(out::addAll)
                            "META-INF/neoforge.mods.toml" -> parseForge(text, source, "neoforge")?.let(out::addAll)
                        }
                    }
                }
                e = zis.nextEntry
            }
        }
        return out
    }

    @Suppress("UNUSED_PARAMETER")
    private fun inspectArchiveEntries(entries: Map<String, ByteArray>, source: String): List<AndroidMod> {
        val out = mutableListOf<AndroidMod>()
        entries["fabric.mod.json"]?.let { parseFabric(String(it), source)?.also(out::add) }
        entries["quilt.mod.json"]?.let { parseQuilt(String(it), source)?.also(out::add) }
        entries["META-INF/mods.toml"]?.let { parseForge(String(it), source, "forge")?.also(out::addAll) }
        entries["META-INF/neoforge.mods.toml"]?.let { parseForge(String(it), source, "neoforge")?.also(out::addAll) }
        return out
    }

    private fun parseFabric(text: String, source: String): AndroidMod? = runCatching {
        val o = JSONObject(text)
        val id = o.optString("id", "unknown")
        if (id == "unknown") return null
        val deps = parseMapDeps(id, o.optJSONObject("depends"), "depends", true) +
            parseMapDeps(id, o.optJSONObject("recommends"), "recommends", false) +
            parseMapDeps(id, o.optJSONObject("suggests"), "suggests", false) +
            parseMapDeps(id, o.optJSONObject("conflicts"), "conflicts", false) +
            parseMapDeps(id, o.optJSONObject("breaks"), "breaks", false)
        AndroidMod(id, o.optString("version", "1.0.0"), "fabric", source, deps)
    }.getOrNull()

    private fun parseQuilt(text: String, source: String): AndroidMod? = runCatching {
        val root = JSONObject(text).optJSONObject("quilt_loader") ?: return null
        val id = root.optString("id", "unknown")
        if (id == "unknown") return null
        val deps = mutableListOf<AndroidDependency>()
        val arr = root.optJSONArray("depends") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val depId = item.optString("id", "")
            if (depId.isBlank()) continue
            val versions = item.opt("versions")
            val spec = when (versions) {
                is JSONArray -> (0 until versions.length()).joinToString(" || ") { versions.optString(it) }
                else -> versions?.toString()?.ifBlank { "*" } ?: "*"
            }
            deps += AndroidDependency(depId, spec, true, "depends", id)
        }
        AndroidMod(id, root.optString("version", "1.0.0"), "quilt", source, deps)
    }.getOrNull()

    private fun parseMapDeps(sourceMod: String, obj: JSONObject?, kind: String, mandatory: Boolean): List<AndroidDependency> {
        if (obj == null) return emptyList()
        val out = mutableListOf<AndroidDependency>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            out += AndroidDependency(id, obj.opt(id)?.toString() ?: "*", mandatory, kind, sourceMod)
        }
        return out
    }

    private fun parseForge(text: String, source: String, loader: String): List<AndroidMod>? = runCatching {
        val mods = Regex("\\[\\[mods\\]\\]([\\s\\S]*?)(?=\\[\\[|$)").findAll(text).mapNotNull { block ->
            val body = block.groupValues[1]
            val id = tomlString(body, "modId") ?: return@mapNotNull null
            val version = tomlString(body, "version") ?: "1.0.0"
            val deps = mutableListOf<AndroidDependency>()
            val depPattern = Regex("\\[\\[dependencies\\.(${Regex.escape(id)})\\]\\]([\\s\\S]*?)(?=\\[\\[|$)")
            depPattern.findAll(text).forEach { dm ->
                val b = dm.groupValues[2]
                val depId = tomlString(b, "modId") ?: return@forEach
                val range = tomlString(b, "versionRange") ?: "*"
                val mandatory = tomlBool(b, "mandatory") ?: true
                deps += AndroidDependency(depId, range, mandatory, "depends", id)
            }
            AndroidMod(id, version, loader, source, deps)
        }.toList()
        if (mods.isEmpty()) null else mods
    }.getOrNull()

    private fun tomlString(body: String, key: String): String? = Regex("(?m)^\\s*$key\\s*=\\s*\\\"([^\\\"]*)\\\"").find(body)?.groupValues?.get(1)
    private fun tomlBool(body: String, key: String): Boolean? = Regex("(?m)^\\s*$key\\s*=\\s*(true|false)").find(body)?.groupValues?.get(1)?.toBoolean()

    private fun readZipBytes(zip: ZipFile, name: String): ByteArray? = runCatching { zip.getEntry(name)?.let { entry -> if (entry.size > MAX_ANDROID_ZIP_MEMBER_BYTES) null else zip.getInputStream(entry).use { readLimited(it, MAX_ANDROID_ZIP_MEMBER_BYTES) } } }.getOrNull()

    private fun readLimited(input: java.io.InputStream, maxBytes: Long): ByteArray {
        require(maxBytes > 0)
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(1024 * 1024)
        var total = 0L
        while (true) {
            val remaining = maxBytes - total
            if (remaining < 0) error("input exceeds safety limit")
            val want = minOf(buffer.size.toLong(), remaining + 1).toInt()
            val n = input.read(buffer, 0, want)
            if (n < 0) break
            total += n
            if (total > maxBytes) error("input exceeds safety limit: $total > $maxBytes")
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun versionKey(v: String): List<Int> = Regex("\\d+").findAll(v).map { it.value.toIntOrNull() ?: 0 }.toList().ifEmpty { listOf(0) }

    private fun cmp(a: String, b: String): Int {
        val aa = versionKey(a); val bb = versionKey(b); val n = maxOf(aa.size, bb.size)
        for (i in 0 until n) {
            val x = aa.getOrElse(i) { 0 }; val y = bb.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    private fun satisfies(version: String, spec: String): Boolean {
        val s = spec.trim()
        if (s.isEmpty() || s == "*" || s.equals("latest", true)) return true
        s.split("||").map { it.trim() }.filter { it.isNotEmpty() }.forEach { alt ->
            if (satisfiesOne(version, alt)) return true
        }
        return false
    }

    private fun satisfiesOne(version: String, s: String): Boolean {
        return when {
            s.startsWith(">=") -> cmp(version, s.substring(2).trim()) >= 0
            s.startsWith(">") -> cmp(version, s.substring(1).trim()) > 0
            s.startsWith("<=") -> cmp(version, s.substring(2).trim()) <= 0
            s.startsWith("<") -> cmp(version, s.substring(1).trim()) < 0
            s.contains('x', true) || s.contains('*') -> {
                val parts = s.replace('*', 'x', true).split('.')
                val vp = version.split('.')
                parts.takeWhile { !it.equals("x", true) }.indices.all { i -> vp.getOrNull(i) == parts[i] }
            }
            else -> cmp(version, s.removePrefix("=").trim()) == 0
        }
    }

    private fun findCycles(nodes: List<AndroidMod>): List<List<String>> {
        val graph = nodes.associate { it.modId to it.dependencies.filter { d -> d.mandatory }.map { d -> d.modId } }
        val result = mutableListOf<List<String>>()
        val visiting = mutableListOf<String>(); val visited = mutableSetOf<String>()
        fun dfs(id: String) {
            if (id in visited) return
            val at = visiting.indexOf(id)
            if (at >= 0) {
                val cycle = visiting.subList(at, visiting.size) + id
                if (cycle !in result) result += cycle
                return
            }
            visiting += id
            graph[id].orEmpty().forEach { if (it in graph) dfs(it) }
            visiting.removeAt(visiting.lastIndex); visited += id
        }
        graph.keys.sorted().forEach(::dfs)
        return result
    }
}
