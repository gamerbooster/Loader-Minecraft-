package com.nex.loader

import java.io.File
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.io.FileOutputStream

object DirectoryAnalyzer {
    fun analyze(root: File, name: String): AndroidAnalysis {
        val jars = root.walkTopDown().filter { it.isFile && it.extension.equals("jar", true) }.sortedBy { it.absolutePath }.toList()
        val temp = File.createTempFile("nex_dir_analysis_", ".zip")
        try {
            ZipOutputStream(FileOutputStream(temp)).use { zos ->
                jars.forEach { jar ->
                    val entry = java.util.zip.ZipEntry(jar.relativeTo(root).path.replace(File.separatorChar, '/'))
                    zos.putNextEntry(entry)
                    jar.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            return ZipFile(temp).use { PackAnalyzer.analyze(it, name) }
        } finally {
            temp.delete()
        }
    }
}
