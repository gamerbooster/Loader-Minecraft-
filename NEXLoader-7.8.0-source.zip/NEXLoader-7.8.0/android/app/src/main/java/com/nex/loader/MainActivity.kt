package com.nex.loader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

class MainActivity : ComponentActivity() {
    companion object {
        private const val MAX_SELECTED_INPUT_BYTES = 2L * 1024L * 1024L * 1024L
        private const val MAX_SELECTED_TREE_FILES = 100_000
        private const val MAX_SELECTED_TREE_BYTES = 2L * 1024L * 1024L * 1024L
    }
    private lateinit var status: TextView
    private lateinit var analyzeButton: Button
    private lateinit var convertButton: Button
    private lateinit var shareButton: Button
    private lateinit var openButton: Button
    private lateinit var fetchExternals: CheckBox
    private var selectedPath: File? = null
    private var selectedName: String = "nex_input.bin"
    private var lastAddon: File? = null
    private var conversionThread: Thread? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) acceptFile(uri)
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                contentResolver.takePersistableUriPermission(uri, takeFlags)
            }
            acceptTree(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.app_name)
        buildUi()
        intent?.data?.let { acceptFile(it) }
    }

    override fun onDestroy() {
        conversionThread?.interrupt()
        conversionThread = null
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply { text = getString(R.string.app_title); textSize = 24f })
        root.addView(TextView(this).apply { text = getString(R.string.app_subtitle); textSize = 15f })
        root.addView(Button(this).apply { text = getString(R.string.pick_input); setOnClickListener { pickInputFile() } })
        root.addView(Button(this).apply { text = getString(R.string.pick_folder); setOnClickListener { pickInputFolder() } })
        fetchExternals = CheckBox(this).apply {
            text = getString(R.string.fetch_externals)
            isChecked = false
        }
        root.addView(fetchExternals)
        analyzeButton = Button(this).apply {
            text = getString(R.string.analyze_input); isEnabled = false
            setOnClickListener { analyzeSelected() }
        }
        convertButton = Button(this).apply {
            text = getString(R.string.convert_input); isEnabled = false
            setOnClickListener { convertSelected() }
        }
        shareButton = Button(this).apply {
            text = getString(R.string.share_output); isEnabled = false
            setOnClickListener { shareAddon() }
        }
        openButton = Button(this).apply {
            text = getString(R.string.open_output); isEnabled = false
            setOnClickListener { openAddon() }
        }
        status = TextView(this).apply { text = getString(R.string.no_input); textSize = 14f }
        root.addView(analyzeButton); root.addView(convertButton); root.addView(shareButton); root.addView(openButton)
        root.addView(ScrollView(this).apply {
            addView(status)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        })
        setContentView(root)
    }

    private fun pickInputFile() {
        filePicker.launch(arrayOf(
            "application/java-archive",
            "application/zip",
            "application/octet-stream",
            "application/x-zip-compressed",
            "application/x-modrinth-modpack+zip",
            "*/*"
        ))
    }

    private fun pickInputFolder() = folderPicker.launch(null)

    private fun acceptFile(uri: Uri) {
        runCatching {
            val name = DocumentFile.fromSingleUri(this, uri)?.name ?: "nex_input.bin"
            val dst = cacheDir.resolve("inputs").apply { mkdirs() }.resolve(sanitize(name))
            val declared = DocumentFile.fromSingleUri(this, uri)?.length() ?: -1L
            if (declared > MAX_SELECTED_INPUT_BYTES) error("Selected file is too large: $declared bytes")
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open selected file" }
                copyLimited(input, dst.outputStream(), MAX_SELECTED_INPUT_BYTES)
            }
            selectedPath = dst
            selectedName = name
            lastAddon = null
            setReadyState()
            status.text = getString(R.string.selected_input, name)
        }.onFailure { e ->
            status.text = getString(R.string.analysis_error, e.message ?: e::class.simpleName)
        }
    }

    private fun acceptTree(uri: Uri) {
        runCatching {
            val rootDoc = DocumentFile.fromTreeUri(this, uri) ?: error("Cannot open folder")
            val base = cacheDir.resolve("inputs").resolve("pack_${System.currentTimeMillis()}")
            base.mkdirs()
            val stats = CopyStats()
            copyTree(rootDoc, base, stats, 0)
            selectedPath = base
            selectedName = rootDoc.name ?: "ModPack"
            lastAddon = null
            setReadyState()
            status.text = getString(R.string.selected_input, selectedName)
        }.onFailure { e ->
            status.text = getString(R.string.analysis_error, e.message ?: e::class.simpleName)
        }
    }

    private class CopyStats(var files: Int = 0, var bytes: Long = 0L)

    private fun copyTree(doc: DocumentFile, target: File, stats: CopyStats, depth: Int) {
        require(depth <= 64) { "Folder nesting exceeds safety limit" }
        doc.listFiles().forEach { child ->
            val safeName = sanitize(child.name ?: "unnamed")
            val out = target.resolve(safeName)
            if (child.isDirectory) {
                out.mkdirs(); copyTree(child, out, stats, depth + 1)
            } else {
                stats.files += 1
                require(stats.files <= MAX_SELECTED_TREE_FILES) { "Folder contains too many files" }
                val declared = child.length()
                val remaining = MAX_SELECTED_TREE_BYTES - stats.bytes
                require(remaining > 0) { "Folder is too large" }
                if (declared >= 0) require(declared <= remaining) { "Folder is too large" }
                contentResolver.openInputStream(child.uri).use { input ->
                    requireNotNull(input) { "Cannot read ${child.name}" }
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { output -> copyLimited(input, output, remaining) }
                }
                stats.bytes += out.length()
                require(stats.bytes <= MAX_SELECTED_TREE_BYTES) { "Folder is too large" }
            }
        }
    }

    private fun setReadyState() {
        analyzeButton.isEnabled = true
        convertButton.isEnabled = true
        shareButton.isEnabled = false
        openButton.isEnabled = false
    }

    private fun analyzeSelected() {
        val src = selectedPath ?: return
        status.text = "Analizando…"
        Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val bridge = Python.getInstance().getModule("nex_android_bridge")
                val raw = bridge.callAttr("analyze", src.absolutePath, src.isDirectory || src.extension.lowercase() in setOf("zip", "mrpack", "modpack")).toString()
                val obj = JSONObject(raw)
                val msg = buildString {
                    appendLine("Modo: ${obj.optString("mode")}")
                    appendLine("Estado: ${obj.optString("status")}")
                    obj.optString("loader").takeIf { it.isNotBlank() }?.let { appendLine("Loader: $it") }
                    if (obj.has("mods")) appendLine("Mods: ${obj.optInt("mods", 0)}")
                    appendLine("Operaciones: ${obj.optInt("operations", 0)}")
                    obj.optJSONObject("capability_counts")?.let { appendLine("Capabilities: $it") }
                    obj.optJSONArray("missing")?.let { if (it.length() > 0) appendLine("Dependencias faltantes: ${it.length()}") }
                    obj.optJSONArray("conflicts")?.let { if (it.length() > 0) appendLine("Conflictos: ${it.length()}") }
                    obj.optJSONArray("cycles")?.let { if (it.length() > 0) appendLine("Ciclos: ${it.length()}") }
                }
                runOnUiThread { status.text = msg }
            } catch (pythonError: Exception) {
                // Kotlin analyzer remains as a local fallback if Python is unavailable or a pack is malformed.
                runCatching {
                    val result = if (src.isDirectory) DirectoryAnalyzer.analyze(src, selectedName)
                    else ZipFile(src).use { PackAnalyzer.analyze(it, selectedName) }
                    runOnUiThread { status.text = result.display() }
                }.onFailure { e ->
                    runOnUiThread { status.text = getString(R.string.analysis_error, e.message ?: pythonError.message ?: e::class.simpleName) }
                }
            }
        }.start()
    }

    private fun convertSelected() {
        val src = selectedPath ?: return
        val fetchMissingExternals = fetchExternals.isChecked
        convertButton.isEnabled = false; analyzeButton.isEnabled = false; shareButton.isEnabled = false; openButton.isEnabled = false
        status.text = getString(R.string.converting)
        conversionThread?.interrupt()
        conversionThread = Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val out = cacheDir.resolve("converted").resolve(System.currentTimeMillis().toString())
                out.mkdirs()
                val bridge = Python.getInstance().getModule("nex_android_bridge")
                val raw = bridge.callAttr(
                    "convert",
                    src.absolutePath,
                    out.absolutePath,
                    src.isDirectory || src.extension.lowercase() in setOf("zip", "mrpack", "modpack"),
                    false,
                    "2.9.0",
                    fetchMissingExternals
                ).toString()
                val obj = JSONObject(raw)
                lastAddon = obj.optString("mcaddon").takeIf { it.isNotBlank() }?.let(::File)
                val msg = buildString {
                    appendLine("Estado: ${obj.optString("status")}")
                    appendLine("Salida: ${obj.optString("output_dir")}")
                    appendLine("Runtime: ${obj.optJSONArray("runtime_modules")?.toString() ?: "[]"}")
                    lastAddon?.let { appendLine(getString(R.string.conversion_done, it.name)) }
                }
                runOnUiThread {
                    status.text = msg
                    convertButton.isEnabled = true; analyzeButton.isEnabled = true
                    shareButton.isEnabled = lastAddon?.isFile == true; openButton.isEnabled = lastAddon?.isFile == true
                }
            } catch (e: InterruptedException) {
                runOnUiThread { status.text = getString(R.string.conversion_error, "Conversión cancelada") }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = getString(R.string.conversion_error, e.message ?: e::class.simpleName)
                    convertButton.isEnabled = true; analyzeButton.isEnabled = true
                    openButton.isEnabled = false; shareButton.isEnabled = false
                }
            }
        }.also { it.start() }
    }

    private fun openAddon() {
        val addon = lastAddon ?: return
        if (!addon.isFile) return
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", addon)
        val types = listOf("application/zip", "application/octet-stream", "*/*")
        for (type in types) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, type)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent); return
            }
        }
        shareAddon()
    }

    private fun shareAddon() {
        val addon = lastAddon ?: return
        if (!addon.isFile) return
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", addon)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_title)))
    }

    private fun copyLimited(input: java.io.InputStream, output: java.io.OutputStream, maxBytes: Long) {
        require(maxBytes > 0)
        val buffer = ByteArray(1024 * 1024)
        var total = 0L
        while (true) {
            val remaining = maxBytes - total
            if (remaining < 0) error("input exceeds safety limit")
            val want = minOf(buffer.size.toLong(), remaining + 1).toInt()
            val n = input.read(buffer, 0, want)
            if (n < 0) break
            total += n
            if (total > maxBytes) error("input exceeds safety limit: $total > $maxBytes")
            output.write(buffer, 0, n)
        }
    }

    private fun sanitize(name: String): String = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
}
