# NEXLoader 7.8.4 — Android/GitHub versioning fix

- `VERSION` is now the single source of truth for the Android `versionName`.
- Android `versionCode` is derived from `VERSION` (`7.8.4` -> `784`).
- The APK user-facing `versionName` is exactly `7.8.4` (not `0.7.8.4`).
- GitHub Actions verifies the APK's embedded `versionName` with `aapt` after compilation.
- The uploaded artifact is named `NEXLoader-7.8.4-debug` and the APK is renamed to `NEXLoader-7.8.4-debug.apk`.
- The workflow reads the version from `VERSION`, so future version bumps do not require hard-coding the artifact name.
- A pre-build version check prevents GitHub from publishing an APK with an old version.

The existing Gradle 8.13 notice is informational; it is not a build failure.
