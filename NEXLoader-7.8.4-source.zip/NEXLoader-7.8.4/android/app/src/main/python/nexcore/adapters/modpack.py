from __future__ import annotations

import json, tempfile, zipfile, shutil, hashlib, os
from dataclasses import asdict
from pathlib import Path
from .loader import detect
from .dependencies import ModNode, Dependency, resolve
from .resources import build_ir
from analyzer.intermod import analyze_cross_mod_calls
from .loader import extract_mod_config
from .external_fetch import fetch_modrinth_files
from nex.ir import Program, Operation
from nex.io_limits import ArchiveLimitError, MAX_CLASS_BYTES, read_stream_limited, read_zip_member


def _jar_files(root: Path):
    return sorted([p for p in root.rglob('*.jar') if p.is_file()], key=lambda p:str(p).lower())


def _discover_embedded_jars(jar: Path, work: Path):
    """Extract Jar-in-Jar payloads (Forge/Fabric patterns) for metadata inspection."""
    out=[]
    try:
        with zipfile.ZipFile(jar) as z:
            names=[n for n in z.namelist() if n.lower().endswith('.jar') and (n.startswith('META-INF/jarjar/') or n.startswith('META-INF/jars/'))]
            for idx,name in enumerate(sorted(set(names))):
                zi = z.getinfo(name)
                if int(getattr(zi, 'file_size', 0) or 0) > MAX_EMBEDDED_JAR_BYTES:
                    continue
                target=work/f'embedded_{idx}_{Path(name).name}'
                target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(zi) as src:
                    raw=read_stream_limited(src, MAX_EMBEDDED_JAR_BYTES)
                target.write_bytes(raw)
                out.append((target,name))
    except Exception:
        pass
    return out


def _manifest_nodes(root: Path):
    """Read Modrinth/CurseForge pack metadata and record externally referenced artifacts."""
    info={'external_files': [], 'overlays': []}
    m=root/'modrinth.index.json'
    if m.exists():
        try:
            data=json.loads(m.read_text(encoding='utf-8'))
            info['format']='modrinth'; info['name']=data.get('name'); info['versionId']=data.get('versionId')
            for f in data.get('files',[]) or []:
                if not isinstance(f,dict): continue
                path=str(f.get('path') or '')
                downloads=f.get('downloads') or []
                info['external_files'].append({'path':path,'downloads':downloads,'hashes':f.get('hashes') or {},'size':f.get('fileSize'),'env':f.get('env')})
        except Exception: pass
    c=root/'manifest.json'
    if c.exists():
        try:
            data=json.loads(c.read_text(encoding='utf-8'))
            if data.get('manifestType')=='minecraftModpack' or 'minecraft' in data:
                info['format']='curseforge'; info['name']=data.get('name'); info['version']=data.get('version')
                for f in data.get('files',[]) or []:
                    if not isinstance(f,dict): continue
                    info['external_files'].append({'projectID':f.get('projectID'),'fileID':f.get('fileID'),'required':bool(f.get('required',True))})
        except Exception: pass
    info['external_files_count']=len(info['external_files'])
    return info




def _scan_overrides(root: Path):
    roots=[('overrides',root/'overrides'),('client-overrides',root/'client-overrides'),('server-overrides',root/'server-overrides')]
    result=[]
    for scope,base in roots:
        if not base.exists() or not base.is_dir():
            continue
        files=[]; categories={}
        for f in sorted(base.rglob('*')):
            if not f.is_file(): continue
            rel=str(f.relative_to(base)).replace('\\','/')
            files.append(rel)
            first=rel.split('/',1)[0].lower()
            cat='other'
            if first in {'config','defaultconfigs'}: cat='config'
            elif first in {'resourcepacks','assets'}: cat='resources'
            elif first in {'shaderpacks','shaders'}: cat='shaders'
            elif first in {'kubejs','scripts','datapacks','data'}: cat='scripts_data'
            categories[cat]=categories.get(cat,0)+1
        result.append({'scope':scope,'files':len(files),'categories':categories,'paths':files[:500],'truncated':len(files)>500})
    return result

def _verify_external_artifacts(root: Path, packinfo: dict):
    """Verify Modrinth-local artifacts by declared size/hash; report what cannot be verified."""
    verified=[]; mismatched=[]; missing=[]; unverifiable=[]
    for rec in packinfo.get('external_files',[]) or []:
        path=str(rec.get('path') or '').replace('\\','/').lstrip('/')
        if path:
            target=(root/path).resolve()
            try:
                target.relative_to(root.resolve())
            except ValueError:
                mismatched.append({**rec,'reason':'unsafe_path'})
                continue
            if not target.exists() or not target.is_file():
                missing.append({**rec,'reason':'not_present'})
                continue
            hashes=rec.get('hashes') or {}
            try:
                got_size=target.stat().st_size
            except OSError as exc:
                mismatched.append({**rec,'path':path,'reason':'stat_error','detail':str(exc)})
                continue
            raw_expected_size=rec.get('size')
            expected_size=None
            if raw_expected_size is not None:
                try:
                    expected_size=int(raw_expected_size)
                except (TypeError,ValueError):
                    mismatched.append({**rec,'path':path,'size':got_size,'reason':'invalid_expected_size','expected_size':raw_expected_size})
                    continue
                if expected_size < 0:
                    mismatched.append({**rec,'path':path,'size':got_size,'reason':'invalid_expected_size','expected_size':expected_size})
                    continue
            result={'path':path,'size':got_size,'expected_size':expected_size,'hashes':{}}
            if expected_size is not None and expected_size != got_size:
                mismatched.append({**result,'reason':'size_mismatch'})
                continue
            hashers={algo:hashlib.new(algo) for algo in ('sha1','sha512') if str(hashes.get(algo) or '').strip()}
            with target.open('rb') as fh:
                while True:
                    chunk=fh.read(1024 * 1024)
                    if not chunk: break
                    for h in hashers.values(): h.update(chunk)
            hash_fail=[]
            for algo,h in hashers.items():
                expected=str(hashes.get(algo) or '').lower()
                got=h.hexdigest()
                result['hashes'][algo]=got
                if got != expected: hash_fail.append({'algorithm':algo,'expected':expected,'actual':got})
            if hash_fail:
                mismatched.append({**result,'reason':'hash_mismatch','details':hash_fail})
            elif hashes or expected_size is not None:
                verified.append({**result,'status':'verified'})
            else:
                unverifiable.append({**result,'reason':'no_hash_or_size'})
        elif rec.get('projectID') is not None or rec.get('fileID') is not None:
            # CurseForge manifests identify remote project/file IDs but do not
            # embed a stable local path. We record this explicitly rather than
            # pretending local presence has been verified.
            unverifiable.append({**rec,'reason':'curseforge_remote_reference'})
        else:
            unverifiable.append({**rec,'reason':'no_local_reference'})
    return {'verified':verified,'mismatched':mismatched,'missing':missing,'unverifiable':unverifiable,
            'counts':{'verified':len(verified),'mismatched':len(mismatched),'missing':len(missing),'unverifiable':len(unverifiable)}}

MAX_ARCHIVE_MEMBERS = int(os.environ.get("NEX_MAX_ARCHIVE_MEMBERS", "100000"))
MAX_ARCHIVE_UNCOMPRESSED = int(os.environ.get("NEX_MAX_ARCHIVE_UNCOMPRESSED", str(4 * 1024 * 1024 * 1024)))
MAX_EMBEDDED_JAR_BYTES = int(os.environ.get("NEX_MAX_EMBEDDED_JAR_BYTES", str(128 * 1024 * 1024)))

def _validate_archive_members(infos, root: Path):
    if len(infos) > MAX_ARCHIVE_MEMBERS:
        raise ValueError(f"archive has too many members: {len(infos)} > {MAX_ARCHIVE_MEMBERS}")
    total = 0
    resolved_root = root.resolve()
    for member in infos:
        target = (root / member.filename).resolve()
        try:
            target.relative_to(resolved_root)
        except ValueError:
            raise ValueError(f"unsafe archive path: {member.filename}")
        if member.is_dir():
            continue
        size = int(getattr(member, "file_size", 0) or 0)
        total += size
        if total > MAX_ARCHIVE_UNCOMPRESSED:
            raise ValueError(f"archive uncompressed size exceeds safety limit: {total} > {MAX_ARCHIVE_UNCOMPRESSED}")



def extract_pack(pack: str|Path, work: Path|None=None) -> tuple[Path, dict]:
    src=Path(pack)
    owned=work is None
    work=Path(work or tempfile.mkdtemp(prefix='nexpack_'))
    if src.is_dir():
        mi=_manifest_nodes(src); mi['overlays']=_scan_overrides(src); return src, {'cleanup': False, **mi}
    if src.suffix.lower() not in {'.zip','.mrpack','.modpack'}:
        raise ValueError('ModPack must be a directory or a supported ZIP/.mrpack file')
    root=work/'pack'; root.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z:
        infos = z.infolist()
        _validate_archive_members(infos, root)
        z.extractall(root)
    mi=_manifest_nodes(root); mi['overlays']=_scan_overrides(root); return root, {'cleanup': owned, **mi}


def inspect_modpack(pack: str|Path):
    tmp=Path(tempfile.mkdtemp(prefix='nexpack_inspect_'))
    try:
        root,packinfo=extract_pack(pack,tmp)
        jars=_jar_files(root)
        nodes=[]; jar_infos=[]
        invalid=[]
        embedded_root=tmp/'embedded_inspect'; embedded_root.mkdir(parents=True,exist_ok=True)
        for jar in jars:
            try:
                info=detect(jar)
            except Exception as e:
                invalid.append({'path':str(jar.relative_to(root)),'error':str(e)})
                continue
            for mod in info.get('mods',[]):
                deps=[Dependency(**d) for d in mod.get('dependencies',[]) if isinstance(d,dict)]
                n=ModNode(mod['id'],str(mod.get('version') or '1.0.0'),mod.get('loader','unknown'),str(jar.relative_to(root)),deps)
                nodes.append(n); jar_infos.append((jar,info,n))
            for embedded,entry in _discover_embedded_jars(jar,embedded_root):
                try: einfo=detect(embedded)
                except Exception: continue
                for mod in einfo.get('mods',[]):
                    deps=[Dependency(**d) for d in mod.get('dependencies',[]) if isinstance(d,dict)]
                    source=f'{jar.relative_to(root)}!{entry}'
                    n=ModNode(mod['id'],str(mod.get('version') or '1.0.0'),mod.get('loader','unknown'),source,deps)
                    nodes.append(n); jar_infos.append((embedded,einfo,n))
        res=resolve(nodes)
        if invalid:
            packinfo=dict(packinfo); packinfo['invalid_jar_files']=invalid; packinfo['invalid_jar_count']=len(invalid)
        return {'pack':packinfo,'root':str(root),'mods':jar_infos,'resolution':res}
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def build_modpack_ir(pack: str|Path, pack_id: str|None=None, fetch_externals: bool=False):
    tmp=Path(tempfile.mkdtemp(prefix='nexpack_build_'))
    root,packinfo=extract_pack(pack,tmp)
    fetch_report=fetch_modrinth_files(root, packinfo) if fetch_externals else {'downloaded':[],'skipped':[],'failed':[]}
    jars=_jar_files(root)
    nodes=[]; records=[]
    cross_entries=[]
    invalid=[]
    embedded_root=tmp/'embedded_build'; embedded_root.mkdir(parents=True,exist_ok=True)
    for jar in jars:
        try:
            info=detect(jar)
        except Exception as e:
            invalid.append({'path':str(jar.relative_to(root)),'error':str(e)})
            continue
        for mod in info.get('mods',[]):
            deps=[Dependency(**d) for d in mod.get('dependencies',[]) if isinstance(d,dict)]
            node=ModNode(mod['id'],str(mod.get('version') or '1.0.0'),mod.get('loader','unknown'),str(jar.relative_to(root)),deps)
            nodes.append(node); records.append((jar,info,node))
            with zipfile.ZipFile(jar) as z:
                classes=[]
                for n in sorted(z.namelist()):
                    if not n.endswith('.class'): continue
                    try: classes.append((n,read_zip_member(z,n,MAX_CLASS_BYTES)))
                    except ArchiveLimitError: continue
            cross_entries.append((node.mod_id,node.source,classes))
        for embedded,entry in _discover_embedded_jars(jar,embedded_root):
            try: einfo=detect(embedded)
            except Exception: continue
            for mod in einfo.get('mods',[]):
                deps=[Dependency(**d) for d in mod.get('dependencies',[]) if isinstance(d,dict)]
                source=f'{jar.relative_to(root)}!{entry}'
                node=ModNode(mod['id'],str(mod.get('version') or '1.0.0'),mod.get('loader','unknown'),source,deps)
                nodes.append(node); records.append((embedded,einfo,node))
                with zipfile.ZipFile(embedded) as z:
                    classes=[]
                    for n in sorted(z.namelist()):
                        if not n.endswith('.class'): continue
                        try: classes.append((n,read_zip_member(z,n,MAX_CLASS_BYTES)))
                        except ArchiveLimitError: continue
                cross_entries.append((node.mod_id,node.source,classes))
    resolution=resolve(nodes)
    if not nodes:
        merged_empty_note = {'code':'EMPTY_MODPACK','message':'No valid Java mod archives were found in the ModPack.'}
    else:
        merged_empty_note = None
    target_id=pack_id or packinfo.get('name') or (f'nexpack_{Path(pack).stem.lower()}' if not Path(pack).is_dir() else 'nexpack')
    target_id=''.join(c if c.isalnum() or c in '._-' else '_' for c in str(target_id).lower())[:80] or 'nexpack'
    external_verification=_verify_external_artifacts(root, packinfo) if packinfo.get('external_files_count') else {'verified':[],'mismatched':[],'missing':[],'unverifiable':[],'counts':{'verified':0,'mismatched':0,'missing':0,'unverifiable':0}}
    merged=Program(target_id, version='1.0.0')
    if merged_empty_note is not None:
        merged.diagnostics.append(merged_empty_note)
        merged.operations.append(Operation('modpack_empty','modpack:empty',merged_empty_note,'adaptable','modpack'))
    for bad in invalid:
        merged.operations.append(Operation('invalid_mod_archive',f"invalid:{bad['path']}",bad,'adaptable','modpack',bad['path']))
    merged.diagnostics.extend([
        {'code':'MODPACK_DETECTED','loader_summary':sorted({n.loader for n in nodes}),'mods_found':len(nodes),'pack_format':packinfo.get('format'),'external_files_declared':packinfo.get('external_files_count',0),'embedded_mods':sum(1 for n in nodes if '!META-INF/' in n.source)},
        {'code':'INVALID_JAR_FILES','count':len(invalid),'files':invalid},
        {'code':'PACK_OVERLAYS','overlays':packinfo.get('overlays',[]),'note':'Override trees are analyzed and reported; Java/loader-specific files are not silently treated as Bedrock content.'},
        {'code':'EXTERNAL_FETCH','enabled':bool(fetch_externals),'downloaded':len(fetch_report['downloaded']),'skipped':len(fetch_report['skipped']),'failed':len(fetch_report['failed']),'details':fetch_report},
        {'code':'DEPENDENCY_RESOLUTION','complete':resolution.complete,'ordered':[n.mod_id for n in resolution.ordered],
         'missing':[asdict(x) for x in resolution.missing],'conflicts':resolution.conflicts,'cycles':resolution.cycles,'warnings':resolution.warnings},
    ])
    if packinfo.get('external_files_count'):
        ev=external_verification
        merged.diagnostics.append({'code':'EXTERNAL_ARTIFACTS','declared':packinfo.get('external_files_count',0),
                                   'verified':ev['counts']['verified'],'mismatched':ev['counts']['mismatched'],
                                   'missing':ev['counts']['missing'],'unverifiable':ev['counts']['unverifiable'],
                                   'verification':ev})
    intermod_ops=analyze_cross_mod_calls(cross_entries)
    merged.operations.extend(intermod_ops)
    merged.diagnostics.append({'code':'INTERMOD_ANALYSIS','calls':len(intermod_ops),
                               'resolved':sum(1 for o in intermod_ops if o.args.get('resolved')),
                               'adaptable':sum(1 for o in intermod_ops if not o.args.get('resolved'))})

    by_jar={n.source:jar for jar,_,n in records}
    resource_seen={}
    resource_conflicts=[]
    # Build each Java mod using its own namespace, then merge operations in dependency order.
    for node in resolution.ordered:
        jar=by_jar[node.source]
        info,p=build_ir(jar)
        merged.diagnostics.extend([{'code':'MODPACK_MOD_DIAGNOSTIC','mod_id':node.mod_id,**d} for d in p.diagnostics])
        for o in p.operations:
            o.source = o.source or node.source
            o.args = dict(o.args)
            o.args.setdefault('mod_id', node.mod_id)
            if o.op.startswith('register_'):
                key=(o.op,o.id)
                prior=resource_seen.get(key)
                if prior is None:
                    resource_seen[key]=o
                    merged.operations.append(o)
                else:
                    prior_args=dict(prior.args); prior_args.pop('mod_id',None)
                    current_args=dict(o.args); current_args.pop('mod_id',None)
                    same=(prior.status==o.status and prior_args==current_args)
                    if same:
                        merged.diagnostics.append({'code':'DUPLICATE_RESOURCE_DEDUP','op':o.op,'id':o.id,'kept_mod':prior.args.get('mod_id'),'duplicate_mod':node.mod_id})
                    else:
                        rec={'op':o.op,'id':o.id,'first_mod':prior.args.get('mod_id'),'second_mod':node.mod_id,'first_source':prior.source,'second_source':o.source}
                        resource_conflicts.append(rec)
                        merged.operations.append(Operation('resource_conflict',f"{o.op}:{o.id}:{node.mod_id}",rec,'adaptable','modpack',o.source))
            else:
                merged.operations.append(o)
        for cfg in extract_mod_config(jar, node.mod_id):
            merged.add(Operation('register_config',
                                 f"{node.mod_id}:{cfg['path']}",
                                 cfg,
                                 'convertible' if 'parse_error' not in cfg else 'adaptable',
                                 node.loader,
                                 node.source))

    # De-duplicate identical config paths if a pack contains repeated jar entries.
    merged.diagnostics.append({'code':'CONFIG_ANALYSIS', 'files':sum(1 for o in merged.operations if o.op=='register_config'),
                               'parsed':sum(1 for o in merged.operations if o.op=='register_config' and 'value' in o.args)})
    merged.diagnostics.append({'code':'RESOURCE_CONFLICT_ANALYSIS','conflicts':resource_conflicts,
                               'deduplicated':sum(1 for d in merged.diagnostics if d.get('code')=='DUPLICATE_RESOURCE_DEDUP')})
    for dep in resolution.missing:
        merged.operations.append(Operation('dependency_error',f'dependency:{dep.source_mod}:{dep.mod_id}',{'required':dep.mod_id,'version_spec':dep.version_spec,'source_mod':dep.source_mod},'adaptable','modpack'))
    for c in resolution.conflicts:
        cid=f"conflict:{c.get('type')}:{c.get('mod_id') or c.get('required_mod') or 'unknown'}"
        merged.operations.append(Operation('dependency_error',cid,c,'adaptable','modpack'))
    for cycle in resolution.cycles:
        merged.operations.append(Operation('dependency_error','cycle:'+':'.join(cycle),{'cycle':cycle},'adaptable','modpack'))
    return merged, resolution, tmp
