from pathlib import Path
import io, json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.modpack import build_modpack_ir

ROOT=Path('/tmp/nex101'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
outer=ROOT/'host.jar'; embedded=io.BytesIO()
with zipfile.ZipFile(embedded,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'embedded.classes','version':'1.0.0'}))
    # This must be read while the embedded ZIP is still open.
    z.writestr('embedded/Foo.class',b'not-a-real-class-but-readable-by-the-scanner')
with zipfile.ZipFile(outer,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'host.classes','version':'1.0.0'}))
    z.writestr('META-INF/jarjar/embedded.jar',embedded.getvalue())
pack=ROOT/'pack'; (pack/'mods').mkdir(parents=True)
shutil.copy2(outer,pack/'mods/host.jar')
program,res,tmp=build_modpack_ir(pack,'embeddedclasses')
try:
    assert any(n.mod_id=='embedded.classes' for n in res.ordered)
    # A malformed class is an explicit diagnostic, not a closed-ZIP crash.
    assert program is not None
    assert any(d.get('code')=='CLASSFILE_PARSE_FAILED' for d in program.diagnostics)
finally:
    shutil.rmtree(tmp,ignore_errors=True)
print('JAR-IN-JAR CLASS LIFETIME: PASS')
