from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).parents[2]
result=subprocess.run([sys.executable,str(ROOT/'tools'/'check_versions.py')],cwd=str(ROOT),capture_output=True,text=True)
assert result.returncode==0, result.stdout+result.stderr
ui=(ROOT/'android/app/src/main/res/values/strings.xml').read_text(encoding='utf-8')
version=(ROOT/'VERSION').read_text(encoding='utf-8').strip()
assert f'NEXLoader {version}' in ui
assert 'NEXLoader 7.8</string>' not in ui
main_activity=(ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.java').read_text(encoding='utf-8')
assert 'BuildConfig.VERSION_NAME' in main_activity
print('EXACT ANDROID VERSION: PASS')
