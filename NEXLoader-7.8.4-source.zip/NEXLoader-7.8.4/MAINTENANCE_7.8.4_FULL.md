# NEXLoader 7.8.4 — full maintenance pass

This maintenance pass focused on defects that can cause stale APKs, malformed Bedrock manifests, conversion crashes, or incorrect ModPack dependency decisions.

## Fixed

- Android UI version is derived from `BuildConfig.VERSION_NAME`; the source version gate now requires the exact `VERSION` value rather than only the major/minor prefix.
- Checked-in example manifests and nested `.mcpack`/`.mcaddon` archives were regenerated without stale `metadata.generated_with` entries from old generator versions.
- `output_validate.py` now validates `metadata.generated_with` according to its object/array shape when present instead of rejecting it categorically.
- Jar-in-Jar class scanning no longer reads from a ZIP after the ZIP has been closed.
- A corrupt/unparseable Java `.class` no longer aborts an otherwise valid conversion; it is reported as `CLASSFILE_PARSE_FAILED`.
- `conflicts` and `breaks` dependencies now apply only when the target version matches the declared range.
- Malformed external-file size metadata produces a structured diagnostic instead of raising `ValueError`/`TypeError`.
- Invalid model rotation data is reported as `MODEL_GEO_INVALID` and falls back to a safe full-block geometry.
- Core changes are synchronized into the Android embedded Python core.
- Current project docs were aligned to 7.8.4 where they described the active release.

## Verification

- Version check: PASS (7.8.4)
- Test suite: 54 PASS / 0 FAIL
- Release smoke conversion: PASS
- Release preflight: PASS
- Checked-in example manifest/archive scan: 0 problems
- Android build source was not compiled locally because this environment does not provide a Gradle/Android SDK installation; the GitHub workflow remains the build environment and performs an `aapt` version check against `VERSION`.
