#!/usr/bin/env python3
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
version = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()
checks = {
    'core': (ROOT / 'core/nex/version.py').read_text(encoding='utf-8'),
    'android-core': (ROOT / 'android/app/src/main/python/nexcore/nex/version.py').read_text(encoding='utf-8'),
    'gradle-version': (ROOT / 'android/app/build.gradle').read_text(encoding='utf-8'),
    'ui': (ROOT / 'android/app/src/main/res/values/strings.xml').read_text(encoding='utf-8'),
}
assert re.search(rf"NEXLOADER_VERSION\s*=\s*'{re.escape(version)}'", checks['core'])
assert re.search(rf"NEXLOADER_VERSION\s*=\s*'{re.escape(version)}'", checks['android-core'])
minor = int(version.split('.')[1]);
major, minor, patch = (int(x) for x in version.split('.'))
expected_code = major * 100 + minor * 10 + patch
assert (re.search(rf'versionCode\s+{expected_code}\b', checks['gradle-version']) or 'versionCode nexVersionCode' in checks['gradle-version'])
assert (re.search(rf"versionName\s+['\"]{re.escape(version)}['\"]", checks['gradle-version']) or 'versionName nexVersion' in checks['gradle-version'])
assert f'NEXLoader {version}' in checks['ui']
assert '7.8.0' not in checks['ui'] and '7.8.3.3' not in checks['ui']
print(f'VERSION CHECK PASS: {version}')
