# NEXLoader 7.8.4 — Maintenance audit

## Corrections

- Fixed embedded ModPack JAR analysis using a ZIP handle after the handle had already been closed.
- Made malformed Java `.class` files non-fatal: the analyzer records an adaptable `class_analysis_error` and continues processing the mod.
- Hardened configurable safety limits so invalid environment values fall back to positive safe defaults.
- Added a dedicated binary-asset ceiling for source textures and sound assets.
- Stopped TGA source textures from being selected for Bedrock emission when the converter does not emit that raster format.
- Synchronized all maintenance fixes into the embedded Android Python core.
- Updated 7.8.4 documentation/build status metadata to match the actual project version and test count.

## Verification

- Project tests: 50 PASS / 0 FAIL.
- Python compileall: PASS.
- Version check: PASS (7.8.4).
- Android source lint: 18/18 PASS.
- Core ↔ Android Python source diff: clean (excluding intentionally omitted tests/caches).
- Malformed class end-to-end conversion: PASS.
- Embedded ModPack end-to-end conversion: PASS.
- Bundled example MCADDON determinism: PASS.
- Bundled example conversion report determinism: PASS.
- Release preflight: PASS.

A real Android APK was not generated because this workspace does not provide the required local Android SDK/Gradle build toolchain. Source-level Android validation does pass.
