# Android build gate

NEXLoader 7.8.3 uses:
- Android Gradle Plugin 8.11.1
- Gradle 8.13
- Kotlin 2.2.20
- Chaquopy 17.0.0
- AndroidX Activity 1.13.0
- compileSdk/targetSdk 35
- Python 3.13 inside Chaquopy

The repository contains the Python converter under `android/app/src/main/python` and the Kotlin UI/bridge.

To build a debug APK on a machine with the Android SDK:

```bash
cd android
# Generate wrapper once if absent:
gradle wrapper --gradle-version 8.13
cd ..
ANDROID_SDK_ROOT=/path/to/Android/Sdk ./tools/build_android.sh
```

Required SDK components include platform 35 and build-tools 35.0.0. The project is intentionally not marked as having a verified APK until `assembleDebug` succeeds.
