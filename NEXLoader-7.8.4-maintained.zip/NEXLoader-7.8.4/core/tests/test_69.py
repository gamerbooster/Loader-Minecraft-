from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0,str(Path(__file__).parents[1]))
from adapters.functions import translate_function
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex69'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
jar=ROOT/'fun.jar'
with zipfile.ZipFile(jar,'w') as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'fun','version':'1.0.0','depends':{'fabricloader':'*'}}))
    z.writestr('data/fun/functions/start.mcfunction','say hello\n/give @s minecraft:stone 1\n')
    z.writestr('data/fun/functions/complex.mcfunction','say ok\nexecute if score @s x matches 1 run say one\njava_custom_command x\n')
info,p=build_ir(jar)
funcs=[o for o in p.operations if o.op=='register_function']
assert len(funcs)==2
assert all(o.status=='convertible' for o in funcs if o.id=='fun:start')
assert any(o.status=='adaptable' for o in funcs if o.id=='fun:complex')
print('1 function analysis + conservative unknown-command handling: PASS')

out=ROOT/'out'
compile_program(p,out)
assert (out/'behavior_pack/functions/fun/start.mcfunction').exists()
assert (out/'behavior_pack/nex_untranslated/functions/fun/complex.mcfunction').exists()
assert (out/'behavior_pack/functions/fun/complex.mcfunction').exists()
json.loads((out/'conversion_report.json').read_text())
print('2 active vs archived function output: PASS')

status,text,diags=translate_function('/say x\n# comment\n')
assert status=='convertible' and text.startswith('say x')
print('3 slash normalization/comments: PASS')
print('ALL 3 TESTS PASS')
