from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path("/tmp/nex_hooks"); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
jar=ROOT/"fog.jar"
with zipfile.ZipFile(jar,"w",zipfile.ZIP_DEFLATED) as z:
    z.writestr("fabric.mod.json", json.dumps({"id":"lunareclipse.watching","version":"1.0.0"}))
    z.writestr("data/lunareclipse.watching/function/main/tick.mcfunction", "execute as @e[type=#lunareclipse.watching:herobrine,tag=watching.herobrine] at @s run function lunareclipse.watching:main/entity_ticks/herobrine\n")
    z.writestr("data/lunareclipse.watching/function/main/nbt.mcfunction", "data get storage lunareclipse.watching:config_options\n")
    z.writestr("data/minecraft/tags/function/tick.json", json.dumps({"values":["lunareclipse.watching:main/tick"]}))
    z.writestr("data/minecraft/tags/function/load.json", json.dumps({"values":["lunareclipse.watching:start_events"]}))
    z.writestr("data/lunareclipse.watching/function/start_events.mcfunction", "say loaded\n")
    z.writestr('data/lunareclipse.watching/function/main/entity_ticks/herobrine.mcfunction', 'summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:stone"}}\n')
info,p=build_ir(jar)
out=compile_program(p, ROOT/"out")
tick=json.loads((out/"behavior_pack/functions/tick.json").read_text())
load=json.loads((out/"behavior_pack/functions/load.json").read_text())
assert tick["values"]==["lunareclipse.watching/main/tick"]
assert load["values"]==["lunareclipse.watching/start_events"]
txt=(out/"behavior_pack/functions/lunareclipse.watching/main/tick.mcfunction").read_text()
assert "function lunareclipse.watching/main/entity_ticks/herobrine" in txt
assert "type=lunareclipse.watching:herobrine" in txt
nbt=(out/"behavior_pack/functions/lunareclipse.watching/main/nbt.mcfunction").read_text()
assert "NEX_UNTRANSLATED_JAVA" in nbt
her=(out/"behavior_pack/functions/lunareclipse.watching/main/entity_ticks/herobrine.mcfunction").read_text()
assert her.strip()=="summon lunareclipse.watching:herobrine ~ ~ ~"
print("Datapack hook + Java function normalization: PASS")
