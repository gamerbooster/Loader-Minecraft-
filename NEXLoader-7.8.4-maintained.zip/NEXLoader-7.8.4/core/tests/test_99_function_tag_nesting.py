from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex_tag_nesting_784'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
jar=ROOT/'tags.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'tag.test','version':'1.0.0'}))
    z.writestr('data/tag.test/function/a.mcfunction', 'say A\n')
    z.writestr('data/tag.test/function/b.mcfunction', 'say B\n')
    z.writestr('data/tag.test/function/c.mcfunction', 'say C\n')
    z.writestr('data/tag.test/tags/function/common.json', json.dumps({'values':['tag.test:a','tag.test:b']}))
    z.writestr('data/minecraft/tags/function/tick.json', json.dumps({'values':['#tag.test:common','tag.test:c']}))

_, program=build_ir(jar)
out=compile_program(program, ROOT/'out')
tick=json.loads((out/'behavior_pack/functions/tick.json').read_text())
assert tick['values']==['tag.test/a','tag.test/b','tag.test/c']
print('NESTED FUNCTION TAGS: PASS')
