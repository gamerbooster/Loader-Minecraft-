import json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'core'))

from adapters.resources import build_ir, texture_path
from adapters.modpack import build_modpack_ir


def mkjar(path, *, mod_id='demo', classes=None, extra=None):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json', json.dumps({'id': mod_id, 'version': '1.0.0'}))
        for name, data in (classes or {}).items():
            z.writestr(name, data)
        for name, data in (extra or {}).items():
            z.writestr(name, data)


def main():
    td=Path(tempfile.mkdtemp(prefix='nex_maint_'))
    try:
        # Malformed individual class files must not abort a whole mod analysis.
        bad=td/'bad.jar'
        mkjar(bad, classes={'bad/Broken.class': b'\xca\xfe\xba\xbe\x00'})
        _info, program=build_ir(bad)
        assert any(o.op == 'class_analysis_error' for o in program.operations)
        print('1 malformed class is non-fatal: PASS')

        # Embedded JAR inspection/build must read members while the ZIP is open.
        inner=td/'inner.jar'
        mkjar(inner, mod_id='embedded')
        pack=td/'pack.zip'
        with zipfile.ZipFile(pack, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('mods/outer.jar', inner.read_bytes())
        prog, resolution, tmp=build_modpack_ir(pack)
        shutil.rmtree(tmp, ignore_errors=True)
        assert 'embedded' in [n.mod_id for n in resolution.ordered]
        print('2 embedded JAR build path: PASS')

        # TGA is deliberately not selected as an emitted Bedrock texture format.
        names={'assets/demo/textures/block/test.tga'}
        assert texture_path('demo:block/test', 'demo', names) is None
        print('3 TGA texture guard: PASS')

        # Invalid environment values must fall back instead of breaking imports.
        env=os.environ.copy()
        env['NEX_MAX_CONFIG_BYTES']='not-a-number'
        env['NEX_MAX_ARCHIVE_MEMBERS']='-5'
        env['NEX_MAX_EXTERNAL_BYTES']='bad'
        code='from adapters.loader import MAX_CONFIG_BYTES; from adapters.modpack import MAX_ARCHIVE_MEMBERS; print(MAX_CONFIG_BYTES, MAX_ARCHIVE_MEMBERS)'
        run=subprocess.run([sys.executable,'-c',code],cwd=ROOT,env={**env,'PYTHONPATH':str(ROOT/'core')},capture_output=True,text=True)
        assert run.returncode == 0, run.stderr
        values=run.stdout.strip().split()
        assert int(values[0]) > 0 and int(values[1]) > 0
        print('4 invalid safety env values: PASS')
    finally:
        shutil.rmtree(td, ignore_errors=True)
    print('ALL MAINTENANCE TESTS PASS')


if __name__ == '__main__':
    main()
