# NEXLoader 7.8.3 — datapack/runtime hardening

- Keeps generated Bedrock manifests free of the incompatible optional `metadata.generated_with` field.
- Synchronizes the embedded Android core to 7.8.3.
- Converts Java `minecraft` function tags `tick` / `load` to Bedrock `functions/tick.json` / `functions/load.json`.
- Normalizes Java namespaced `/function ns:path` calls to Bedrock file paths.
- Adds conservative handling for Java NBT/data commands and display-entity selectors/summons.
- Keeps partially translated functions active with explicit `NEX_UNTRANSLATED_JAVA` comments and archives them for audit.
- Updates release checks and stale tests to the manifest contract.
