# NEXLoader 7.8.4

Java/Fabric/Quilt/Forge/NeoForge → Bedrock 1.26.52.3 reconstruction layer.

NEXLoader treats a mod or ModPack as a program: analyze loaders/dependencies, build NEX-IR, lower behavior/resources/runtime modules, then emit a `.mcaddon`.

## Inputs
- `.jar`
- ModPack directory
- `.zip` / `.modpack`
- `.mrpack` when its contained/override JARs are available

## Android
The Android app embeds the same Python core from `core/` through Chaquopy. `tools/sync_android_core.py` keeps the embedded copy synchronized. The app can:

- pick a mod/ModPack;
- receive supported archives through a `VIEW` intent;
- run the **same Python preflight analyzer as desktop**, with the Kotlin analyzer as fallback;
- invoke the real converter;
- share or attempt to open the resulting `.mcaddon`.

## Worldgen compatibility

NEXLoader 7.8.3 adds a conservative Bedrock lowering path for simple Java worldgen chains: fixed-block ore features, fixed single-block providers, simple placed-feature counts/height ranges, and biome feature attachment through Bedrock feature rules. Complex noise, structures, processors and generator graphs are still preserved in `nex_untranslated/` and reported as adaptable. Bedrock supports feature JSON definitions and feature rules as separate worldgen systems.

## Compatibility campaign

Use `tools/compat_campaign.py` to batch-analyze a folder of Java mod JARs and produce an aggregate compatibility report. With `--convert`, it also compiles each analyzed JAR.

```bash
python3 tools/compat_campaign.py ./mods ./compatibility.json
python3 tools/compat_campaign.py ./mods ./compatibility.json --convert --conversion-dir ./converted
```

## Runtime compatibility
Java entity registrations are reconstructed into Bedrock behavior entities; matching entity textures are reused when found in the source JAR.

The generated Behavior Pack may include modular NEX runtime bridges for actions, input, UI, particles, physics, state, scheduling, configs and inter-mod contracts. Direct capabilities are lowered into exported helpers only when the Java receiver/arguments are not safe to wire automatically; unsupported cases remain explicit in the conversion report.

## Build gate
A verified APK is produced only after a real Android Gradle build succeeds. AGP 8.11 requires Gradle 8.13 and JDK 17. Chaquopy 17.0.0 is the embedded Python bridge used by this project.

## CLI
```bash
python3 core/nex_convert.py mod.jar out/
python3 core/nex_convert.py ./MyModPack out/ --modpack
python3 core/nex_convert.py MyPack.mrpack out/ --modpack
python3 core/nex_convert.py MyPack.zip out/ --modpack --strict
python3 core/nex_convert.py MyPack.mrpack out/ --modpack --fetch-externals
```
