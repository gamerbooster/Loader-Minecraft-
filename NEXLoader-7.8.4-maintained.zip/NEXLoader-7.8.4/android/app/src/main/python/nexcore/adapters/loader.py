import json, zipfile, tomllib, configparser, base64, os
from pathlib import Path
from .dependencies import Dependency
from nex.io_limits import ArchiveLimitError, MAX_JSON_BYTES, env_limit, read_zip_member, read_zip_member_text
from dataclasses import asdict

MAX_CONFIG_BYTES = env_limit('NEX_MAX_CONFIG_BYTES', 16 * 1024 * 1024)
MAX_MANIFEST_BYTES = env_limit('NEX_MAX_MANIFEST_BYTES', 4 * 1024 * 1024)


def _fabric_deps(mod_id, data):
    deps=[]
    for kind in ('depends','recommends','suggests','conflicts','breaks'):
        raw=data.get(kind,{}) or {}
        if isinstance(raw,list):
            raw={x:'*' for x in raw}
        for dep_id,spec in sorted(raw.items()):
            deps.append(Dependency(dep_id,str(spec),kind not in {'recommends','suggests','conflicts','breaks'},kind,mod_id,'fabric'))
    return deps


def _forge_deps(mod_id, data, loader_name='forge'):
    deps=[]
    raw=data.get('dependencies',[]) or []
    if isinstance(raw,dict):
        # tomllib parses [[dependencies.modid]] as {"dependencies": {"modid": [...]}}.
        scoped=raw.get(mod_id) if isinstance(raw.get(mod_id),list) else None
        raw=scoped if scoped is not None else [raw]
    for entry in raw:
        if not isinstance(entry,dict): continue
        dep_id=entry.get('modId') or entry.get('mod_id')
        if not dep_id: continue
        mandatory=str(entry.get('mandatory','true')).lower() == 'true'
        deps.append(Dependency(str(dep_id),str(entry.get('versionRange') or '*'),mandatory,'depends',mod_id,loader_name))
    return deps


def _quilt_deps(mod_id, data):
    deps=[]
    raw=data.get('quilt_loader',{}) if isinstance(data,dict) else {}
    raw_deps=raw.get('depends',[]) if isinstance(raw,dict) else []
    if isinstance(raw_deps,dict): raw_deps=[raw_deps]
    for entry in raw_deps:
        if isinstance(entry,dict):
            dep_id=entry.get('id') or entry.get('mod_id')
            if not dep_id: continue
            ver=entry.get('versions') or entry.get('version') or '*'
            if isinstance(ver,list): ver=' || '.join(map(str,ver)) if ver else '*'
            deps.append(Dependency(str(dep_id),str(ver),True,'depends',mod_id,'quilt'))
    return deps


def extract_mod_config(jar, mod_id=None):
    """Extract common static config defaults from a Java mod jar."""
    out=[]
    with zipfile.ZipFile(jar) as z:
        for name in sorted(z.namelist()):
            lower=name.lower()
            if not lower.startswith('config/') or name.endswith('/'):
                continue
            info = z.getinfo(name)
            if info.file_size > MAX_CONFIG_BYTES:
                out.append({'path':name,'mod_id':mod_id,'format':'raw','bytes_hex':'',
                            'parse_error':f'config file exceeds safety limit: {info.file_size} > {MAX_CONFIG_BYTES}',
                            'bytes_truncated':True})
                continue
            raw=read_zip_member(z, name, MAX_CONFIG_BYTES)
            suffix=Path(name).suffix.lower()
            rec={'path':name,'mod_id':mod_id,'format':'raw','bytes_hex':raw.hex()}
            try:
                if suffix=='.json':
                    rec['format']='json'; rec['value']=json.loads(raw.decode('utf-8'))
                elif suffix=='.toml':
                    rec['format']='toml'; rec['value']=tomllib.loads(raw.decode('utf-8'))
                elif suffix in {'.ini','.cfg'}:
                    cp=configparser.ConfigParser(); cp.read_string(raw.decode('utf-8')); rec['format']='ini'; rec['value']={k:dict(cp[k]) for k in cp.sections()}
            except Exception as e:
                rec['parse_error']=str(e)
            out.append(rec)
    return out

def detect(jar):
    found=[]
    with zipfile.ZipFile(jar) as z:
        names=set(z.namelist())
        if 'fabric.mod.json' in names:
            try:
                d=json.loads(read_zip_member_text(z, 'fabric.mod.json', MAX_MANIFEST_BYTES))
                mid=d.get('id','unknown')
                found.append({'loader':'fabric','id':mid,'version':str(d.get('version','1.0.0')),'dependencies':[asdict(x) for x in _fabric_deps(mid,d)],'name':d.get('name') or mid,'entrypoints':d.get('entrypoints',{}),'mixins':d.get('mixins',[])})
            except Exception as exc:
                raise ValueError(f'invalid fabric.mod.json: {exc}') from exc
        if 'quilt.mod.json' in names:
            try:
                d=json.loads(read_zip_member_text(z, 'quilt.mod.json', MAX_MANIFEST_BYTES))
                q=d.get('quilt_loader',{}) if isinstance(d,dict) else {}
                mid=q.get('id','unknown') if isinstance(q,dict) else 'unknown'
                version=q.get('version','1.0.0') if isinstance(q,dict) else '1.0.0'
                found.append({'loader':'quilt','id':mid,'version':str(version),'dependencies':[asdict(x) for x in _quilt_deps(mid,d)],'name':q.get('name') or mid if isinstance(q,dict) else mid,'entrypoints':q.get('entrypoints',{}) if isinstance(q,dict) else {},'mixins':q.get('mixin',[]) if isinstance(q,dict) else []})
            except Exception as exc:
                raise ValueError(f'invalid quilt.mod.json: {exc}') from exc
        forge_files=[]
        if 'META-INF/neoforge.mods.toml' in names: forge_files.append(('neoforge','META-INF/neoforge.mods.toml'))
        if 'META-INF/mods.toml' in names: forge_files.append(('forge','META-INF/mods.toml'))
        for forge_loader,forge_file in forge_files:
            try:
                d=tomllib.loads(read_zip_member_text(z, forge_file, MAX_MANIFEST_BYTES))
                mods=d.get('mods',[]); mods=mods if isinstance(mods,list) else [mods]
                raw_deps=d.get('dependencies',[]) or []
                for m in mods:
                    mid=m.get('modId','unknown')
                    if isinstance(raw_deps,dict):
                        md=raw_deps.get(mid,[])
                    else:
                        md=[x for x in raw_deps if isinstance(x,dict) and x.get('modId')==mid]
                    found.append({'loader':forge_loader,'id':mid,'version':str(m.get('version','1.0.0')),'dependencies':[asdict(x) for x in _forge_deps(mid, {'dependencies':md}, forge_loader)],'name':m.get('displayName') or mid})
                if not mods: found.append({'loader':forge_loader,'id':'unknown','version':None,'dependencies':[],'name':'unknown'})
            except Exception as exc:
                raise ValueError(f'invalid {forge_file}: {exc}') from exc
    loaders=sorted({x['loader'] for x in found})
    return {'loader':('unknown' if not loaders else loaders[0] if len(loaders)==1 else 'hybrid'),'mods':found}
