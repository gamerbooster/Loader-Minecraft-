from __future__ import annotations

import os
from typing import BinaryIO


class ArchiveLimitError(ValueError):
    """Raised when a ZIP member exceeds a bounded decompression/read limit."""


def env_limit(name: str, default: int) -> int:
    raw = os.environ.get(name)
    try:
        value = int(raw) if raw is not None else default
    except ValueError:
        value = default
    return max(1, value)


MAX_ZIP_MEMBER_BYTES = env_limit("NEX_MAX_ZIP_MEMBER_BYTES", 256 * 1024 * 1024)
MAX_CLASS_BYTES = env_limit("NEX_MAX_CLASS_BYTES", 64 * 1024 * 1024)
MAX_JSON_BYTES = env_limit("NEX_MAX_JSON_BYTES", 16 * 1024 * 1024)
MAX_BINARY_ASSET_BYTES = env_limit("NEX_MAX_BINARY_ASSET_BYTES", 64 * 1024 * 1024)


def read_stream_limited(stream: BinaryIO, max_bytes: int, *, chunk_size: int = 1024 * 1024) -> bytes:
    max_bytes = max(1, int(max_bytes))
    out = bytearray()
    while True:
        chunk = stream.read(min(chunk_size, max_bytes - len(out) + 1))
        if not chunk:
            return bytes(out)
        out.extend(chunk)
        if len(out) > max_bytes:
            raise ArchiveLimitError(f"archive member exceeds safety limit: {len(out)} > {max_bytes}")


def read_zip_member(z, name: str, max_bytes: int = MAX_ZIP_MEMBER_BYTES) -> bytes:
    info = z.getinfo(name)
    declared = int(getattr(info, "file_size", 0) or 0)
    if declared > max_bytes:
        raise ArchiveLimitError(f"archive member exceeds safety limit: {name}: {declared} > {max_bytes}")
    with z.open(info) as stream:
        return read_stream_limited(stream, max_bytes)


def read_zip_member_text(z, name: str, max_bytes: int = MAX_JSON_BYTES, encoding: str = "utf-8") -> str:
    return read_zip_member(z, name, max_bytes).decode(encoding)
