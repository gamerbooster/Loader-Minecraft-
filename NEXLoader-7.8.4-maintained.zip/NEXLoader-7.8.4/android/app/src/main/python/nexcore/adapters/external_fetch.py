from __future__ import annotations
import hashlib
import os
import io
import urllib.parse
import urllib.request
from pathlib import Path
import tempfile
from nex.io_limits import env_limit

MAX_EXTERNAL_BYTES = env_limit("NEX_MAX_EXTERNAL_BYTES", 1024 * 1024 * 1024)

ALLOWED_HOSTS={
    'cdn.modrinth.com',
    'github.com',
    'raw.githubusercontent.com',
    'gitlab.com',
}

class ExternalFetchError(RuntimeError):
    pass


def _validate_url(url: str):
    u=urllib.parse.urlparse(str(url or ''))
    if u.scheme!='https' or not u.hostname or u.hostname.lower() not in ALLOWED_HOSTS:
        raise ExternalFetchError(f'blocked external URL: {url}')
    return u


def _safe_target(root: Path, rel: str):
    rel=str(rel or '').replace('\\','/').lstrip('/')
    target=(root/rel).resolve()
    try: target.relative_to(root.resolve())
    except ValueError: raise ExternalFetchError(f'unsafe external path: {rel}')
    return target


def _verify_file(path: Path, rec: dict):
    expected=rec.get('hashes') or {}
    try:
        actual_size=path.stat().st_size
    except OSError as exc:
        return False, {'reason':'stat_error','detail':str(exc)}
    if rec.get('size') is not None and actual_size != int(rec['size']):
        return False, {'reason':'size_mismatch','expected':int(rec['size']),'actual':actual_size}
    hashers={algo:hashlib.new(algo) for algo in ('sha1','sha512') if str(expected.get(algo) or '').strip()}
    with path.open('rb') as fh:
        while True:
            chunk=fh.read(1024 * 1024)
            if not chunk: break
            for h in hashers.values(): h.update(chunk)
    failures=[]
    for algo,h in hashers.items():
        value=str(expected.get(algo) or '').lower()
        got=h.hexdigest()
        if got!=value: failures.append({'algorithm':algo,'expected':value,'actual':got})
    if failures: return False, {'reason':'hash_mismatch','details':failures}
    if expected or rec.get('size') is not None: return True, {'size':actual_size}
    return False, {'reason':'no_integrity_metadata'}


def fetch_modrinth_files(root: Path, packinfo: dict, opener=None, timeout: int=30):
    """Optionally materialize missing Modrinth files, verifying URL, size and hashes.

    Data is streamed to a temporary file and hashed from disk; unverified data is never
    published at the requested target path.
    """
    opener=opener or urllib.request.urlopen
    downloaded=[]; skipped=[]; failed=[]
    if packinfo.get('format')!='modrinth':
        return {'downloaded':downloaded,'skipped':skipped,'failed':failed}
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    for rec in packinfo.get('external_files',[]) or []:
        rel=str(rec.get('path') or '').replace('\\','/').lstrip('/')
        if not rel:
            skipped.append({**rec,'reason':'no_path'}); continue
        try: target=_safe_target(root,rel)
        except ExternalFetchError as exc:
            failed.append({**rec,'error':str(exc)}); continue
        if target.exists() and target.is_file():
            skipped.append({**rec,'reason':'already_present'}); continue
        urls=[]
        for raw_url in rec.get('downloads') or []:
            try: _validate_url(raw_url); urls.append(str(raw_url))
            except ExternalFetchError: continue
        if not urls:
            failed.append({**rec,'error':'no_allowed_https_download_url'}); continue
        declared=rec.get('size')
        try:
            if declared is not None and int(declared) > MAX_EXTERNAL_BYTES:
                raise ExternalFetchError(f'declared external file too large: {declared}')
        except (TypeError, ValueError) as exc:
            failed.append({**rec,'error':{'reason':'invalid_declared_size','detail':str(exc)}}); continue
        last_error=None
        for url in urls:
            temp_path=None
            try:
                with opener(url, timeout=timeout) as response:
                    final_url=getattr(response,'geturl',lambda:url)()
                    _validate_url(final_url)
                    fd,temp_name=tempfile.mkstemp(prefix='nexfetch_',dir=str(root))
                    os.close(fd)
                    temp_path=Path(temp_name)
                    total=0
                    with temp_path.open('wb') as fh:
                        while True:
                            try:
                                chunk=response.read(1024 * 1024)
                            except TypeError:
                                # Compatibility for injected test openers that only expose read().
                                chunk=response.read()
                                if not isinstance(chunk,(bytes,bytearray)):
                                    raise ExternalFetchError('download response returned non-bytes data')
                                if len(chunk) > MAX_EXTERNAL_BYTES-total:
                                    raise ExternalFetchError(f'external file exceeds safety limit: {total + len(chunk)}')
                                fh.write(chunk); total += len(chunk)
                                break
                            if not chunk:
                                break
                            if not isinstance(chunk,(bytes,bytearray)):
                                raise ExternalFetchError('download response returned non-bytes data')
                            total += len(chunk)
                            if total > MAX_EXTERNAL_BYTES:
                                raise ExternalFetchError(f'external file exceeds safety limit: {total}')
                            fh.write(chunk)
                good,detail=_verify_file(temp_path,rec)
                if not good:
                    last_error=detail
                    temp_path.unlink(missing_ok=True)
                    temp_path=None
                    continue
                target.parent.mkdir(parents=True,exist_ok=True)
                os.replace(temp_path,target)
                temp_path=None
                downloaded.append({'path':rel,'url':final_url,'size':detail.get('size',0),'status':'verified'})
                last_error=None
                break
            except Exception as exc:
                last_error={'reason':'download_error','detail':str(exc)}
            finally:
                if temp_path is not None:
                    try: temp_path.unlink(missing_ok=True)
                    except Exception: pass
        if last_error is not None:
            failed.append({**rec,'error':last_error})
    return {'downloaded':downloaded,'skipped':skipped,'failed':failed}
