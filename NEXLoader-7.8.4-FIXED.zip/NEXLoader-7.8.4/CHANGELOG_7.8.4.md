# NEXLoader 7.8.4

- Hardens malformed/null/list JSON handling to prevent conversion crashes such as `NoneType.get`.
- Preserves existing tag IDs while correctly resolving nested Java function tags.
- Validates generated manifests, custom entity references and tick/load function hooks before packaging.
- Strengthens Android version validation and aligns `versionCode`/`versionName` checks.
- Explicitly provisions Android SDK 36 in the GitHub Actions APK workflow.
- Adds regression tests for malformed JSON and nested function tags.
## Maintenance hardening

- Fixed ModPack embedded-JAR analysis using a ZIP handle after it had already been closed.
- A malformed Java `.class` now becomes an explicit adaptable `class_analysis_error` instead of aborting the entire conversion.
- Hardened configurable safety limits so invalid environment values fall back to safe defaults.
- Added binary asset ceilings for textures/sounds and stopped TGA files from being emitted as Bedrock textures.
- Added regression coverage for these cases.

- Added a final Bedrock manifest sanitizer that strips `metadata.generated_with` before validation and packaging.
- Android analyze/convert responses now include the embedded NEXLoader version for stale-APK detection.
