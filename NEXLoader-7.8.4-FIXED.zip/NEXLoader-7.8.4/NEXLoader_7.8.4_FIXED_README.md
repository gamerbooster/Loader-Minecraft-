# NEXLoader 7.8.4 — FIXED maintenance build

This package contains the maintained 7.8.4 source with an additional defense-in-depth fix for the exact Bedrock manifest warning shown in the supplied screenshot:

`/metadata/generated_with` validation/type error.

The generated Behavior Pack and Resource Pack manifests are now sanitized immediately after creation and again immediately before validation/packaging. Any accidental `metadata.generated_with` field is removed from NEX-generated manifests, and a malformed metadata root is removed as well.

The Android Python bridge also reports the embedded NEXLoader core version (`7.8.4`) in analyze/convert responses. This makes it possible to detect an older APK that is still running the previous embedded core.

Important: changing the source does not update an already installed APK. The Android project must be rebuilt so the corrected Python core is embedded in the APK.

Validation performed in this workspace:
- Python compileall: PASS
- Manifest sanitizer regression: PASS
- Malformed JSON regression: PASS
- Maintenance regression suite: PASS
- Embedded ModPack regression: PASS
- Final generated `.mcaddon` contains no `metadata.generated_with`: PASS

A real APK was not produced in this workspace because the Android SDK/Gradle toolchain is not installed here.
