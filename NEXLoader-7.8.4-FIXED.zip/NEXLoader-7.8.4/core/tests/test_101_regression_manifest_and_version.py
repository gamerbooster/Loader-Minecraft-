import json, shutil, sys, zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))

from nex.compiler import compile_program, sanitize_bedrock_manifest
from nex.ir import Program
from nex.version import NEXLOADER_VERSION

ROOT=Path('/tmp/nex_101'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

# Direct regression: the sanitizer removes the problematic generator metadata
# even if an accidental future path writes the field in the wrong shape.
p=ROOT/'manifest.json'
p.write_text(json.dumps({'format_version':2,'metadata':{'generated_with':'NEXLoader 7.8.3.3'}}), encoding='utf-8')
assert sanitize_bedrock_manifest(p) is True
data=json.loads(p.read_text(encoding='utf-8'))
assert 'metadata' not in data

# End-to-end compiler output must never contain generated_with.
program=Program('regression101')
out=compile_program(program, ROOT/'out')
for pack in ('behavior_pack','resource_pack'):
    m=json.loads((out/pack/'manifest.json').read_text(encoding='utf-8'))
    assert 'metadata' not in m
assert NEXLOADER_VERSION == '7.8.4'

# The exact Android embedded bridge reports the version that is actually bundled.
bridge=Path(__file__).parents[2] / 'android/app/src/main/python/nex_android_bridge.py'
bridge=bridge.read_text(encoding='utf-8')
assert 'nexloader_version' in bridge and 'NEXLOADER_VERSION' in bridge
print('MANIFEST + EMBEDDED VERSION REGRESSION: PASS')
