from collections import Counter
from .capability import classify_java_call
from nex.ir import Operation


def analyze_call(c, source_loader='java', source=None):
    cap = classify_java_call(c.get('owner',''), c.get('name',''), c.get('descriptor',''))
    if not cap:
        return None
    return Operation(
        op='capability', id=cap.name, args={
            'target': cap.target,
            'reason': cap.reason,
            'owner': c.get('owner'),
            'name': c.get('name'),
            'descriptor': c.get('descriptor'),
            'near_strings': c.get('near_strings') or [],
            'constant_hints': c.get('constant_hints') or [],
        }, status=cap.status, source_loader=source_loader, source=source
    )


def summarize(program):
    counts = Counter(o.status for o in program.operations if o.op == 'capability')
    return {
        'counts': dict(sorted(counts.items())),
        'capabilities': [
            {
                'id': o.id,
                'status': o.status,
                'target': o.args.get('target'),
                'reason': o.args.get('reason'),
                'source': o.source,
            }
            for o in program.operations if o.op == 'capability'
        ],
    }
