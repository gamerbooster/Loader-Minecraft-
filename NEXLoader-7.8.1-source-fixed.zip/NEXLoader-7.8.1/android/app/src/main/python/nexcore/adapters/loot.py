from __future__ import annotations
from typing import Any

SUPPORTED_ENTRY_TYPES={'item','empty','loot_table'}
SUPPORTED_CONDITIONS={
    'minecraft:killed_by_player':'killed_by_player',
    'killed_by_player':'killed_by_player',
    'minecraft:random_chance':'random_chance',
    'random_chance':'random_chance',
    'minecraft:random_chance_with_looting':'random_chance_with_looting',
    'random_chance_with_looting':'random_chance_with_looting',
    'minecraft:has_mark_variant':'has_mark_variant',
    'has_mark_variant':'has_mark_variant',
}
SUPPORTED_FUNCTIONS={
    'minecraft:set_count':'set_count','set_count':'set_count',
    'minecraft:set_data':'set_data','set_data':'set_data',
    'minecraft:set_damage':'set_damage','set_damage':'set_damage',
}


def _rolls(value: Any):
    if isinstance(value,int) and value >= 0: return value
    if isinstance(value,dict) and isinstance(value.get('min'),int) and isinstance(value.get('max'),int) and value['min'] >= 0 and value['max'] >= value['min']:
        return {'min':value['min'],'max':value['max']}
    return None


def _condition(value: Any):
    if not isinstance(value,dict): return None
    cond=SUPPORTED_CONDITIONS.get(str(value.get('condition','')).lower())
    if not cond: return None
    out={'condition':cond}
    for key,val in value.items():
        if key=='condition': continue
        if isinstance(val,(str,int,float,bool,dict,list)): out[key]=val
    return out


def _function(value: Any):
    if not isinstance(value,dict): return None
    fn=SUPPORTED_FUNCTIONS.get(str(value.get('function','')).lower())
    if not fn: return None
    out={'function':fn}
    for key,val in value.items():
        if key=='function': continue
        if isinstance(val,(str,int,float,bool,dict,list)): out[key]=val
    return out


def _loot_ref(value: str):
    v=value.strip()
    if not v: return None
    if v.endswith('.json') and v.startswith('loot_tables/'):
        return v
    if ':' in v:
        _,path=v.split(':',1)
    else:
        path=v
    path=path.lstrip('/')
    return 'loot_tables/' + path.removesuffix('.json') + '.json'


def translate_loot_table(java: dict, identifier: str):
    """Translate a conservative Java loot-table subset to Bedrock loot_tables JSON."""
    if not isinstance(java,dict): return 'adaptable',None,[{'code':'LOOT_TABLE_NOT_OBJECT'}]
    pools=java.get('pools')
    if not isinstance(pools,list) or not pools:
        return 'adaptable',None,[{'code':'LOOT_POOLS_INVALID'}]
    out_pools=[]; diags=[]
    for pi,pool in enumerate(pools):
        if not isinstance(pool,dict): return 'adaptable',None,[{'code':'LOOT_POOL_INVALID','pool':pi}]
        rolls=_rolls(pool.get('rolls',1))
        entries=pool.get('entries')
        if rolls is None or not isinstance(entries,list):
            return 'adaptable',None,[{'code':'LOOT_POOL_ROLLS_OR_ENTRIES_INVALID','pool':pi}]
        bout=[]
        for ei,entry in enumerate(entries):
            if not isinstance(entry,dict): return 'adaptable',None,[{'code':'LOOT_ENTRY_INVALID','pool':pi,'entry':ei}]
            typ=str(entry.get('type','')).lower()
            if typ not in SUPPORTED_ENTRY_TYPES:
                return 'adaptable',None,[{'code':'LOOT_ENTRY_TYPE_UNSUPPORTED','pool':pi,'entry':ei,'type':typ}]
            item={'type':typ}
            if typ=='item':
                if not isinstance(entry.get('name'),str) or not entry['name']:
                    return 'adaptable',None,[{'code':'LOOT_ITEM_NAME_MISSING','pool':pi,'entry':ei}]
                item['name']=entry['name']
            elif typ=='loot_table':
                ref=_loot_ref(str(entry.get('name','')))
                if not ref: return 'adaptable',None,[{'code':'LOOT_TABLE_REF_INVALID','pool':pi,'entry':ei}]
                item['name']=ref
                if isinstance(entry.get('pools'),list):
                    diags.append({'code':'LOOT_INLINE_NESTED_TABLE_PASSTHROUGH','pool':pi,'entry':ei})
            if isinstance(entry.get('weight'),int) and entry['weight'] >= 0:
                item['weight']=entry['weight']
            elif 'weight' in entry:
                return 'adaptable',None,[{'code':'LOOT_WEIGHT_INVALID','pool':pi,'entry':ei}]
            if 'conditions' in entry:
                conds=[]
                for c in entry.get('conditions') or []:
                    bc=_condition(c)
                    if bc is None: return 'adaptable',None,[{'code':'LOOT_CONDITION_UNSUPPORTED','pool':pi,'entry':ei}]
                    conds.append(bc)
                item['conditions']=conds
            if 'functions' in entry:
                funcs=[]
                for f in entry.get('functions') or []:
                    bf=_function(f)
                    if bf is None: return 'adaptable',None,[{'code':'LOOT_FUNCTION_UNSUPPORTED','pool':pi,'entry':ei}]
                    funcs.append(bf)
                item['functions']=funcs
            bout.append(item)
        bp={'rolls':rolls,'entries':bout}
        if 'bonus_rolls' in pool:
            br=_rolls(pool['bonus_rolls'])
            if br is None: return 'adaptable',None,[{'code':'LOOT_BONUS_ROLLS_INVALID','pool':pi}]
            bp['bonus_rolls']=br
        if 'conditions' in pool:
            conds=[]
            for c in pool.get('conditions') or []:
                bc=_condition(c)
                if bc is None: return 'adaptable',None,[{'code':'LOOT_POOL_CONDITION_UNSUPPORTED','pool':pi}]
                conds.append(bc)
            bp['conditions']=conds
        out_pools.append(bp)
    return 'convertible', {'pools':out_pools}, diags
