import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))
from compat.translator import translate

x=translate({'kind':'add_effect','target':'entity','effect':'minecraft:speed','duration_ticks':100,'amplifier':1,'show_particles':False})
assert x['status']=='convertible'
assert 'entity.addEffect' in x['js']
assert 'minecraft:speed' in x['js']
y=translate({'kind':'teleport'})
assert y['status']=='bridge'
z=translate({'kind':'unknown_java_renderer'})
assert z['status']=='adaptable'
try:
    translate({'kind':'add_effect','target':'entity','effect':'minecraft:speed','duration_ticks':0})
except ValueError:
    pass
else:
    raise AssertionError('invalid duration was accepted')
print('compatibility self-test: PASS')
