from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class Capability:
    name: str
    status: str  # convertible | emulated | adaptable | incompatible
    target: str
    reason: str = ''

CAPABILITIES = {
    'effects.add': Capability('effects.add', 'convertible', 'Entity.addEffect', 'Bedrock exposes a direct effect API.'),
    'effects.remove': Capability('effects.remove', 'convertible', 'Entity.removeEffect', 'Bedrock exposes a direct effect API.'),
    'entity.teleport': Capability('entity.teleport', 'convertible', 'Entity.teleport', 'Direct entity teleport is exposed.'),
    'entity.damage': Capability('entity.damage', 'convertible', 'Entity.applyDamage', 'Direct entity damage is exposed.'),
    'entity.impulse': Capability('entity.impulse', 'convertible', 'Entity.applyImpulse', 'Direct impulse is exposed.'),
    'entity.command': Capability('entity.command', 'convertible', 'Entity.runCommand', 'Synchronous entity commands are exposed.'),
    'entity.dynamic_state': Capability('entity.dynamic_state', 'convertible', 'Entity.setDynamicProperty', 'Persistent per-entity dynamic state is exposed.'),
    'world.dynamic_state': Capability('world.dynamic_state', 'convertible', 'World.setDynamicProperty', 'Persistent world state is exposed.'),
    'tick.schedule': Capability('tick.schedule', 'convertible', 'system.run/system.runInterval', 'Tick scheduling is exposed.'),
    'client.input': Capability('client.input', 'emulated', 'WorldAfterEvents.playerButtonInput / Player.inputInfo', 'Bedrock exposes player button input state/change events; arbitrary Java key mapping still needs semantic lowering.'),
    'ui.screen': Capability('ui.screen', 'adaptable', '@minecraft/server-ui ActionFormData/ModalFormData', 'Java client screens cannot be loaded directly; simple menus can be reconstructed as Bedrock forms.'),
    'client.hud': Capability('client.hud', 'adaptable', 'Bedrock UI/resource reconstruction', 'Java HUD overlays require a Bedrock-side UI reconstruction rather than JVM rendering code.'),
    'particle.spawn': Capability('particle.spawn', 'adaptable', 'Dimension.spawnParticle / entity particle responses', 'Bedrock exposes particle spawning, but a Java particle type may need a Bedrock particle asset reconstruction.'),
    'event.bridge': Capability('event.bridge', 'emulated', 'NEX runtime event bridge', 'Java/Fabric/Forge events need semantic adaptation into Bedrock events.'),
    'physics.body': Capability('physics.body', 'emulated', 'NEX physics runtime', 'Rigid-body/fragment behavior can be approximated through scripted state, entities and impulses.'),
    'render.custom': Capability('render.custom', 'adaptable', 'Bedrock entity/resource implementation', 'Arbitrary Java-side renderer code is not directly executable and may need a resource/entity reconstruction.'),
    'shader.java_pipeline': Capability('shader.java_pipeline', 'adaptable', 'Bedrock graphics approximation', 'A Java shader pipeline cannot be loaded as JVM graphics code; it needs a Bedrock-side recreation.'),
    'java.jvm': Capability('java.jvm', 'incompatible', 'none', 'Bedrock cannot execute arbitrary JVM bytecode.'),
    'java.threading': Capability('java.threading', 'emulated', 'NEX scheduler/state runtime', 'Java threads must be lowered to deterministic tick scheduling/state transitions.'),
    'network.raw_socket': Capability('network.raw_socket', 'incompatible', 'none', 'Arbitrary Java socket networking cannot be embedded in a Bedrock pack.'),
}


def get(name: str) -> Optional[Capability]:
    return CAPABILITIES.get(name)


def classify_java_call(owner: str, name: str, descriptor: str = '') -> Optional[Capability]:
    o = owner or ''
    n = name or ''
    if o == 'net/minecraftforge/eventbus/api/IEventBus' and n in {'addListener', 'addGenericListener'}:
        return CAPABILITIES['event.bridge']
    if o.startswith('net/fabricmc/fabric/api/event/') and n in {'register', 'subscribe'}:
        return CAPABILITIES['event.bridge']
    if o in {'net/minecraft/entity/LivingEntity', 'net/minecraft/world/entity/LivingEntity'}:
        if n in {'addStatusEffect', 'addEffect'}: return CAPABILITIES['effects.add']
        if n in {'removeStatusEffect', 'removeEffect'}: return CAPABILITIES['effects.remove']
    if n in {'teleport', 'teleportTo'} and ('Entity' in o or 'entity' in o):
        return CAPABILITIES['entity.teleport']
    if n in {'attack', 'hurt', 'damage', 'applyDamage'} and ('Entity' in o or 'entity' in o):
        return CAPABILITIES['entity.damage']
    if n in {'push', 'addVelocity', 'setDeltaMovement', 'applyImpulse'} and ('Entity' in o or 'entity' in o):
        return CAPABILITIES['entity.impulse']
    if n in {'setPersistentData', 'setDynamicProperty', 'put'} and ('Persistent' in o or 'Dynamic' in o):
        return CAPABILITIES['entity.dynamic_state']
    if n in {'runCommand', 'runCommandSilent', 'performCommand'}:
        return CAPABILITIES['entity.command']
    if n in {'runEveryTick', 'schedule', 'scheduleRepeating', 'runLater'} and ('Scheduler' in o or 'Tick' in o or 'Server' in o):
        return CAPABILITIES['tick.schedule']
    if any(x in o.lower() for x in ('keybinding', 'keymapping', 'keyboardinput', 'inputkey', 'inputevent')) or any(x in n.lower() for x in ('registerkeymapping','registerkeybinding','keymapping','keybinding')):
        return CAPABILITIES['client.input']
    if any(x in o.lower() for x in ('screen', 'screenscreenhandler', 'screenhandler')) and n in {'setScreen','init','render','addDrawableChild','addRenderableWidget'}:
        return CAPABILITIES['ui.screen']
    if any(x in o.lower() for x in ('gui','hud','ingamegui','overlay')) and n in {'render','draw','renderOverlay','renderHud'}:
        return CAPABILITIES['client.hud']
    if any(x in o.lower() for x in ('particle','particles')) and n in {'addParticle','spawnParticle','emitParticle'}:
        return CAPABILITIES['particle.spawn']
    if any(x in o.lower() for x in ('renderer', 'renderlayer', 'shader', 'gl11', 'opengl', 'blaze3d')):
        if 'shader' in o.lower(): return CAPABILITIES['shader.java_pipeline']
        return CAPABILITIES['render.custom']
    if any(x in o.lower() for x in ('thread', 'executorservice', 'forkjoin')):
        return CAPABILITIES['java.threading']
    if any(x in o.lower() for x in ('socket', 'channel', 'httpclient', 'urlconnection')):
        return CAPABILITIES['network.raw_socket']
    return None
