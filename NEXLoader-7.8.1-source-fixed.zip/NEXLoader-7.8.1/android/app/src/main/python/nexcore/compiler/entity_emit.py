from __future__ import annotations
from pathlib import Path
import json

_PHYSICS_PNG = bytes.fromhex(
    '89504e470d0a1a0a0000000d49484452000000100000001008060000001ff3ff610000001a4944415478da63d8b061c37f4a30c3a801a3068c1a305c0c000062ba0f2ee60ed0880000000049454e44ae426082'
)


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')


def emit_physics_fragment(bp: Path, rp: Path, entity_id: str) -> dict:
    """Emit a minimal custom proxy entity used by NEX's scripted physics layer."""
    geometry_id = 'geometry.nex_physics_fragment'
    behavior = {
        'format_version': '1.20.80',
        'minecraft:entity': {
            'description': {
                'identifier': entity_id,
                'is_spawnable': False,
                'is_summonable': True,
                'is_experimental': False,
            },
            'components': {
                'minecraft:physics': {'has_gravity': False, 'has_collision': True},
                'minecraft:collision_box': {'width': 1.0, 'height': 1.0},
                'minecraft:pushable': {'is_pushable': True, 'is_pushable_by_piston': True},
            },
        },
    }
    client = {
        'format_version': '1.10.0',
        'minecraft:client_entity': {
            'description': {
                'identifier': entity_id,
                'materials': {'default': 'entity_alphatest'},
                'textures': {'default': 'textures/entity/nex_physics_fragment'},
                'geometry': {'default': geometry_id},
                'render_controllers': ['controller.render.default'],
            }
        },
    }
    geometry = {
        'format_version': '1.12.0',
        'minecraft:geometry': [{
            'description': {
                'identifier': geometry_id,
                'texture_width': 16,
                'texture_height': 16,
            },
            'bones': [{
                'name': 'root',
                'pivot': [0, 0, 0],
                'cubes': [{
                    'origin': [-8, -8, -8],
                    'size': [16, 16, 16],
                    'uv': [0, 0],
                }],
            }],
        }],
    }
    render_controller = {
        'format_version': '1.8.0',
        'render_controllers': {
            'controller.render.default': {
                'geometry': 'Geometry.default',
                'materials': [{'default': 'Material.default'}],
                'textures': ['Texture.default'],
            }
        },
    }
    _write(bp / 'entities' / 'nex_physics_fragment.json', behavior)
    _write(rp / 'entity' / 'nex_physics_fragment.entity.json', client)
    _write(rp / 'models' / 'geometry.nex_physics_fragment.geo.json', geometry)
    _write(rp / 'render_controllers' / 'nex_physics_fragment.render_controllers.json', render_controller)
    tex = rp / 'textures' / 'entity' / 'nex_physics_fragment.png'
    tex.parent.mkdir(parents=True, exist_ok=True)
    tex.write_bytes(_PHYSICS_PNG)
    return {'entity_id': entity_id, 'geometry': geometry_id, 'files': [
        'entities/nex_physics_fragment.json',
        'entity/nex_physics_fragment.entity.json',
        'models/geometry.nex_physics_fragment.geo.json',
        'render_controllers/nex_physics_fragment.render_controllers.json',
        'textures/entity/nex_physics_fragment.png',
    ]}
