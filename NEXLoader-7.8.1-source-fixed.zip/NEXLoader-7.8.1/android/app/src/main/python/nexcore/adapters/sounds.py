from __future__ import annotations
from pathlib import PurePosixPath

VALID_CATEGORIES={'master','music','record','weather','block','hostile','neutral','player','ambient','voice'}

def _sound_path(namespace: str, value: str):
    if not isinstance(value,str): return None
    v=value.strip()
    if not v: return None
    if ':' in v: ns,path=v.split(':',1)
    else: ns,path=namespace,v
    path=path.removesuffix('.ogg').removesuffix('.wav').removesuffix('.fsb')
    return ns,path

def translate_sound_event(namespace: str, event_name: str, data: dict, available_names: set[str]):
    sounds=data.get('sounds',[])
    if isinstance(sounds,(str,dict)): sounds=[sounds]
    if not isinstance(sounds,list):
        return None, {'code':'SOUND_LIST_INVALID','event':event_name}
    out=[]
    for item in sounds:
        if isinstance(item,str): ref=item; opts={}
        elif isinstance(item,dict): ref=item.get('name'); opts=item
        else: continue
        parsed=_sound_path(namespace,ref)
        if not parsed: continue
        ns,path=parsed
        candidate=None
        for ext in ('.ogg','.wav','.fsb'):
            cand=f'assets/{ns}/sounds/{path}{ext}'
            if cand in available_names:
                candidate=cand; break
        if candidate is None:
            return None, {'code':'SOUND_ASSET_MISSING','event':event_name,'reference':ref}
        entry={'name':'sounds/'+ns+'/'+path}
        if isinstance(opts.get('volume'),(int,float)): entry['volume']=float(opts['volume'])
        if isinstance(opts.get('pitch'),(int,float)): entry['pitch']=float(opts['pitch'])
        out.append((entry,candidate))
    if not out:
        return None, {'code':'SOUND_HAS_NO_VALID_ASSETS','event':event_name}
    category=str(data.get('category','master')).lower()
    if category not in VALID_CATEGORIES: category='master'
    definition={'category':category,'sounds':[x[0] for x in out]}
    if isinstance(data.get('replace'),bool): definition['replace']=data['replace']
    return {'identifier':f'{namespace}:{event_name}','definition':definition,'assets':[x[1] for x in out]}, None
