from nex.ir import Operation
from .classfile import parse, code_scan
from compat.analyzer import analyze_call

FABRIC_TICK_OWNERS={
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$EndTick':'server_tick',
 'net/fabricmc/fabric/api/event/lifecycle/v1/ServerTickEvents$StartTick':'server_tick',
}

def analyze_classes(entries):
    ops=[]
    for source,data in entries:
        p=parse(data)
        for m in p['methods']:
            calls=code_scan(p,m)
            has_entity_builder=any('EntityType' in (c.get('owner') or '') and ('Builder' in (c.get('owner') or '') or c.get('name') in {'create','build','of'}) for c in calls)
            for c in calls:
                cap_op = analyze_call(c, 'java', source)
                if cap_op:
                    ops.append(cap_op)
                owner,name=c.get('owner'),c.get('name')
                if cap_op and cap_op.id == 'client.input':
                    hints=' '.join(c.get('near_strings') or []).lower()
                    button='Jump' if 'jump' in hints else ('Sneak' if 'sneak' in hints or 'shift' in hints else None)
                    ops.append(Operation('keybind', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'),
                        'button_hint': button, 'hints': c.get('near_strings') or []
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'ui.screen':
                    title=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('ui_screen', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'title_hint': title
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'client.hud':
                    ops.append(Operation('hud_overlay', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor')
                    }, 'adaptable', 'java', source))
                elif cap_op and cap_op.id == 'particle.spawn':
                    particle=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('particle', f'{owner}.{name}', {
                        'owner': owner, 'method': name, 'descriptor': c.get('descriptor'), 'particle_hint': particle
                    }, 'convertible', 'java', source))
                if owner in FABRIC_TICK_OWNERS and name=='register':
                    cb=c.get('callback_target') or {}
                    ops.append(Operation('event',FABRIC_TICK_OWNERS[owner],{
                        'method':m['name'],'callback':cb
                    },'convertible','fabric',source))
                elif owner=='net/minecraft/world/World' and name=='sendMessage':
                    msg=(c.get('near_strings') or [None])[-1]
                    ops.append(Operation('world_message',f'{p["this"]}.{m["name"]}',{
                        'method':m['name'],'message':msg
                    },'convertible' if msg else 'adaptable','java',source))
                elif owner=='net/minecraft/registry/Registry' and name=='register':
                    ids=c.get('near_strings') or []
                    reg_id=next((x for x in reversed(ids) if isinstance(x,str) and ':' in x and all(x.split(':',1))), ids[-1] if ids else 'unknown')
                    if has_entity_builder and reg_id != 'unknown':
                        ops.append(Operation('register_entity',reg_id,{
                            'method':m['name'], 'owner':owner, 'near_strings':ids,
                            'entity_builder_detected':True, 'loader_hint':'java'
                        },'emulated','java',source))
                    else:
                        ops.append(Operation('register_content',reg_id,{
                            'method':m['name'], 'near_strings':ids
                        },'adaptable','java',source))
                elif owner=='net/minecraftforge/eventbus/api/IEventBus' and name in ('addListener','addGenericListener'):
                    ops.append(Operation('event',f'forge:{name}',{
                        'method':m['name'],'callback':c.get('callback_target') or {}
                    },'adaptable','forge',source))
    return ops
