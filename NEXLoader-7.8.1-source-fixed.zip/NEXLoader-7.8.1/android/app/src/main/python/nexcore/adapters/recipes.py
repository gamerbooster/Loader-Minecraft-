from __future__ import annotations
from typing import Any

SUPPORTED_CRAFTING = {
    'minecraft:crafting_shaped': 'minecraft:recipe_shaped',
    'minecraft:crafting_shapeless': 'minecraft:recipe_shapeless',
    'crafting_shaped': 'minecraft:recipe_shaped',
    'crafting_shapeless': 'minecraft:recipe_shapeless',
}
COOKING = {
    'minecraft:smelting': ('minecraft:recipe_furnace', ['furnace']),
    'minecraft:smoking': ('minecraft:recipe_furnace', ['smoker']),
    'minecraft:blasting': ('minecraft:recipe_furnace', ['blast_furnace']),
    'minecraft:campfire_cooking': ('minecraft:recipe_furnace', ['campfire']),
    'smelting': ('minecraft:recipe_furnace', ['furnace']),
    'smoking': ('minecraft:recipe_furnace', ['smoker']),
    'blasting': ('minecraft:recipe_furnace', ['blast_furnace']),
    'campfire_cooking': ('minecraft:recipe_furnace', ['campfire']),
}


def _item(value: Any):
    if isinstance(value, str):
        return {'item': value}
    if not isinstance(value, dict):
        return None
    if 'item' in value:
        out = {'item': str(value['item'])}
    elif 'tag' in value:
        out = {'tag': str(value['tag'])}
    else:
        return None
    if 'data' in value and isinstance(value['data'], int):
        out['data'] = value['data']
    return out


def _result(value: Any):
    if not isinstance(value, dict):
        return None
    if not value.get('item'):
        return None
    out = {'item': str(value['item'])}
    if isinstance(value.get('count'), int):
        out['count'] = value['count']
    elif isinstance(value.get('count'), float) and value['count'].is_integer():
        out['count'] = int(value['count'])
    else:
        out['count'] = 1
    if isinstance(value.get('data'), int):
        out['data'] = value['data']
    return out


def translate_recipe(java: dict, identifier: str):
    """Translate common Java recipe JSON into Bedrock recipe JSON.

    Returns (status, bedrock_json, diagnostics). Unsupported recipe semantics are
    deliberately marked adaptable rather than emitted as invalid Java JSON.
    """
    if not isinstance(java, dict):
        return 'adaptable', None, [{'code': 'RECIPE_NOT_OBJECT'}]
    typ = str(java.get('type', '')).lower()
    diag = []
    if typ in SUPPORTED_CRAFTING:
        kind = SUPPORTED_CRAFTING[typ]
        body = {'description': {'identifier': identifier}, 'tags': ['crafting_table']}
        if 'group' in java:
            diag.append({'code': 'RECIPE_GROUP_DROPPED', 'value': java.get('group')})
        if kind == 'minecraft:recipe_shaped':
            pattern = java.get('pattern')
            key = java.get('key')
            result = _result(java.get('result'))
            if not isinstance(pattern, list) or not all(isinstance(x, str) for x in pattern):
                return 'adaptable', None, diag + [{'code': 'RECIPE_PATTERN_INVALID'}]
            # Bedrock supports a 3x3 crafting grid; do not silently change a larger Java recipe.
            if len(pattern) > 3 or any(len(row) > 3 for row in pattern):
                return 'adaptable', None, diag + [{'code': 'RECIPE_GRID_GT_3X3', 'rows': len(pattern), 'widths': [len(x) for x in pattern]}]
            if not isinstance(key, dict) or result is None:
                return 'adaptable', None, diag + [{'code': 'RECIPE_KEY_OR_RESULT_INVALID'}]
            bkey = {}
            for k, v in key.items():
                if not isinstance(k, str) or len(k) != 1 or k == ' ':
                    return 'adaptable', None, diag + [{'code': 'RECIPE_KEY_INVALID', 'key': k}]
                iv = _item(v)
                if iv is None:
                    return 'adaptable', None, diag + [{'code': 'RECIPE_INGREDIENT_INVALID', 'key': k}]
                bkey[k] = iv
            body['pattern'] = pattern
            body['key'] = bkey
            body['result'] = result
        else:
            ingredients = java.get('ingredients')
            result = _result(java.get('result'))
            if not isinstance(ingredients, list) or result is None:
                return 'adaptable', None, diag + [{'code': 'RECIPE_INGREDIENTS_OR_RESULT_INVALID'}]
            bings = []
            for v in ingredients:
                iv = _item(v)
                if iv is None:
                    # Java alternatives are often lists of accepted ingredients; Bedrock can
                    # represent these only in some forms, so keep them adaptable here.
                    if isinstance(v, list):
                        alts = [_item(x) for x in v]
                        if alts and all(x is not None for x in alts):
                            diag.append({'code': 'RECIPE_ALTERNATIVE_COLLAPSED', 'alternatives': len(alts)})
                            bings.append(alts[0])
                            continue
                    return 'adaptable', None, diag + [{'code': 'RECIPE_INGREDIENT_INVALID'}]
                bings.append(iv)
            body['ingredients'] = bings
            body['result'] = result
        return 'convertible', {'format_version': '1.21.40', kind: body}, diag

    if typ in COOKING:
        kind, tags = COOKING[typ]
        inp = java.get('ingredient') or java.get('input')
        if isinstance(inp, list):
            if len(inp) != 1:
                return 'adaptable', None, [{'code': 'COOKING_ALTERNATIVES_UNSUPPORTED'}]
            inp = inp[0]
        iv = _item(inp)
        res = _result(java.get('result') or java.get('output'))
        if iv is None or res is None:
            return 'adaptable', None, [{'code': 'COOKING_INPUT_OR_OUTPUT_INVALID'}]
        body = {
            'description': {'identifier': identifier},
            'tags': tags,
            'input': iv.get('item') if 'item' in iv else iv,
            'output': res['item'],
        }
        return 'convertible', {'format_version': '1.21.40', kind: body}, []

    # Forge/NeoForge JSON can use custom recipe serializers. Such recipes need a
    # runtime/data-pack recreation; emitting the Java schema would create a broken pack.
    return 'adaptable', None, [{'code': 'RECIPE_TYPE_UNSUPPORTED', 'type': typ or None}]
