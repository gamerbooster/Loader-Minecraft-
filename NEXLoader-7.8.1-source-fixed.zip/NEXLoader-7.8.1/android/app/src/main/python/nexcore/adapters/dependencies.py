from __future__ import annotations

from dataclasses import dataclass, field
from functools import cmp_to_key
import re
from typing import Iterable


def _parts(v: str):
    # Deliberately loose semver-ish comparison; loader metadata often contains suffixes.
    raw = str(v or '0').strip().lower()
    raw = re.sub(r'^[v=]+', '', raw)
    out = []
    for token in re.split(r'[.\-_+]', raw):
        m = re.match(r'^(\d+)', token)
        if m:
            out.append(int(m.group(1)))
        elif token in {'snapshot', 'beta', 'alpha', 'rc'}:
            out.append(0)
    return tuple(out or [0])


def compare_versions(a: str, b: str) -> int:
    pa, pb = _parts(a), _parts(b)
    n = max(len(pa), len(pb))
    pa += (0,) * (n - len(pa))
    pb += (0,) * (n - len(pb))
    return (pa > pb) - (pa < pb)


def _range_match(version: str, spec: str) -> bool:
    spec = spec.strip()
    if spec in {'', '*', 'any', 'latest'}:
        return True
    # Maven-style single range: [1.0,2.0), (1.0,), (,2.0]
    m = re.fullmatch(r'([\[(])\s*([^,]*)\s*,\s*([^\])]*)\s*([\])])', spec)
    if m:
        lo, hi = m.group(2).strip(), m.group(3).strip()
        if lo:
            if m.group(1) == '[' and compare_versions(version, lo) < 0: return False
            if m.group(1) == '(' and compare_versions(version, lo) <= 0: return False
        if hi:
            if m.group(4) == ']' and compare_versions(version, hi) > 0: return False
            if m.group(4) == ')' and compare_versions(version, hi) >= 0: return False
        return True
    if spec.startswith('>='): return compare_versions(version, spec[2:].strip()) >= 0
    if spec.startswith('<='): return compare_versions(version, spec[2:].strip()) <= 0
    if spec.startswith('>'): return compare_versions(version, spec[1:].strip()) > 0
    if spec.startswith('<'): return compare_versions(version, spec[1:].strip()) < 0
    if spec.startswith('^'):
        base = spec[1:].strip(); pb = _parts(base); pv = _parts(version)
        return compare_versions(version, base) >= 0 and pv[0] == pb[0]
    if spec.startswith('~'):
        base = spec[1:].strip(); pb = _parts(base); pv = _parts(version)
        return compare_versions(version, base) >= 0 and pv[:2] == pb[:2]
    if spec.startswith('='): spec = spec[1:].strip()
    # Common wildcard forms.
    if 'x' in spec.lower() or '*' in spec:
        parts = spec.lower().replace('*', 'x').split('.')
        vp = str(version).lower().split('.')
        for i, part in enumerate(parts):
            if part == 'x':
                return len(vp) >= i and all(re.fullmatch(r'\d+', q or '') for q in vp[:i])
            if i >= len(vp) or compare_versions(vp[i], part) != 0:
                return False
        return True
    return compare_versions(version, spec) == 0


def satisfies(version: str, spec: str | None) -> bool:
    spec = (spec or '*').strip()
    if spec in {'', '*', 'any', 'latest'}: return True
    # Logical OR used by some pack/mod metadata.
    alternatives = [x.strip() for x in re.split(r'\s+\|\|\s+', spec) if x.strip()]
    if len(alternatives) > 1:
        return any(satisfies(version, x) for x in alternatives)
    # Space-separated constraints (e.g. ">=1.0 <2.0"). Do not split Maven ranges.
    if not (spec.startswith('[') or spec.startswith('(')) and ' ' in spec:
        return all(_range_match(version, x) for x in spec.split() if x)
    return _range_match(version, spec)


@dataclass(frozen=True)
class Dependency:
    mod_id: str
    version_spec: str = '*'
    mandatory: bool = True
    kind: str = 'depends'
    source_mod: str | None = None
    loader: str = 'unknown'


@dataclass
class ModNode:
    mod_id: str
    version: str = '1.0.0'
    loader: str = 'unknown'
    source: str = ''
    dependencies: list[Dependency] = field(default_factory=list)


@dataclass
class Resolution:
    ordered: list[ModNode] = field(default_factory=list)
    missing: list[Dependency] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)
    cycles: list[list[str]] = field(default_factory=list)
    warnings: list[dict] = field(default_factory=list)
    empty: bool = False

    @property
    def complete(self):
        return bool(self.ordered) and not self.missing and not self.conflicts and not self.cycles


def resolve(nodes: Iterable[ModNode]) -> Resolution:
    nodes = list(nodes)
    result = Resolution(empty=not nodes)
    by_id: dict[str, ModNode] = {}
    seen: dict[str, list[ModNode]] = {}

    for node in nodes:
        seen.setdefault(node.mod_id, []).append(node)
        if node.mod_id not in by_id:
            by_id[node.mod_id] = node
        elif compare_versions(node.version, by_id[node.mod_id].version) > 0:
            by_id[node.mod_id] = node

    for mod_id, items in sorted(seen.items()):
        versions = sorted({x.version for x in items}, key=cmp_to_key(compare_versions))
        if len(versions) > 1:
            result.conflicts.append({
                'type': 'duplicate_mod_version', 'mod_id': mod_id,
                'versions': versions, 'selected': by_id[mod_id].version,
                'sources': [x.source for x in items]
            })
        elif len(items) > 1:
            result.warnings.append({
                'code': 'DUPLICATE_MOD', 'mod_id': mod_id,
                'version': items[0].version, 'sources': [x.source for x in items]
            })

    visiting: list[str] = []
    visited: set[str] = set()
    order: list[ModNode] = []

    def dfs(mod_id: str):
        if mod_id in visited: return
        if mod_id in visiting:
            i = visiting.index(mod_id)
            cycle = visiting[i:] + [mod_id]
            if cycle not in result.cycles: result.cycles.append(cycle)
            return
        node = by_id.get(mod_id)
        if not node: return
        visiting.append(mod_id)
        for dep in sorted(node.dependencies, key=lambda d:(d.mod_id,d.version_spec,d.kind)):
            target = by_id.get(dep.mod_id)
            if dep.kind in {'conflicts','breaks'}:
                if not target:
                    continue
                matches = satisfies(target.version, dep.version_spec)
                if dep.kind == 'conflicts' or matches:
                    result.conflicts.append({
                        'type':'declared_conflict', 'kind':dep.kind, 'source_mod':dep.source_mod,
                        'mod_id':dep.mod_id, 'required':dep.version_spec, 'found':target.version,
                        'source':target.source
                    })
                continue
            if not target:
                if dep.mandatory:
                    result.missing.append(dep)
                else:
                    result.warnings.append({'code':'OPTIONAL_DEPENDENCY_MISSING','mod_id':dep.mod_id,'source_mod':dep.source_mod})
                continue
            if not satisfies(target.version, dep.version_spec):
                rec={'type':'version_mismatch','source_mod':dep.source_mod,'required_mod':dep.mod_id,
                     'required':dep.version_spec,'found':target.version,'source':target.source}
                if dep.mandatory: result.conflicts.append(rec)
                else: result.warnings.append({'code':'OPTIONAL_DEPENDENCY_VERSION_MISMATCH',**rec})
                continue
            dfs(dep.mod_id)
        visiting.pop(); visited.add(mod_id); order.append(node)

    for node in sorted(by_id.values(), key=lambda n:(n.mod_id,n.version,n.source)):
        dfs(node.mod_id)

    # Stable de-duplication for diagnostics.
    unique_missing={ (d.source_mod,d.mod_id,d.version_spec,d.kind): d for d in result.missing }
    result.missing=list(unique_missing.values())
    unique_cycles=[]
    for c in result.cycles:
        if c not in unique_cycles: unique_cycles.append(c)
    result.cycles=unique_cycles
    result.ordered=order
    return result
