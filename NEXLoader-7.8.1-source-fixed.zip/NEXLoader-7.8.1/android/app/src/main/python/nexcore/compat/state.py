from dataclasses import dataclass

@dataclass(frozen=True)
class StateKey:
    scope: str
    key: str


def normalize(scope: str, key: str) -> StateKey:
    if scope not in {'entity','world'}:
        raise ValueError('scope must be entity or world')
    if not key or len(key) > 64:
        raise ValueError('state key must be 1..64 characters')
    return StateKey(scope, key)
