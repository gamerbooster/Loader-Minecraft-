from dataclasses import dataclass, field, asdict
from typing import Any
import json

@dataclass
class Operation:
    op: str
    id: str
    args: dict[str, Any] = field(default_factory=dict)
    status: str = 'convertible'  # convertible | emulated | adaptable | incompatible
    source_loader: str = 'unknown'
    source: str | None = None

@dataclass
class Program:
    mod_id: str
    operations: list[Operation] = field(default_factory=list)
    version: str = '1.0.0'
    diagnostics: list[dict[str, Any]] = field(default_factory=list)

    def add(self, op): self.operations.append(op)
    def warn(self, code, message, source=None): self.diagnostics.append({'code':code,'message':message,'source':source})
    def to_dict(self): return {'mod_id':self.mod_id,'version':self.version,'operations':[asdict(x) for x in self.operations],'diagnostics':self.diagnostics}
    @classmethod
    def from_dict(cls,d):
        p=cls(d['mod_id'], version=d.get('version','1.0.0'))
        for x in d.get('operations',[]): p.add(Operation(x['op'],x['id'],x.get('args',{}),x.get('status','convertible'),x.get('source_loader','unknown'),x.get('source')))
        p.diagnostics.extend(d.get('diagnostics',[])); return p
    @classmethod
    def from_json(cls,path):
        with open(path,encoding='utf-8') as f: return cls.from_dict(json.load(f))
