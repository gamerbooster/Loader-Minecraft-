# Capability map for the NEX compatibility layer.
# These are target capabilities, not claims that Java APIs are identical.
CAPABILITIES = {
    'effects.add': {'bedrock': '@minecraft/server Entity.addEffect', 'mode': 'direct'},
    'effects.remove': {'bedrock': '@minecraft/server Entity.removeEffect', 'mode': 'direct'},
    'entity.teleport': {'bedrock': '@minecraft/server Entity.teleport', 'mode': 'direct'},
    'entity.damage': {'bedrock': '@minecraft/server Entity.applyDamage', 'mode': 'direct'},
    'entity.impulse': {'bedrock': '@minecraft/server Entity.applyImpulse', 'mode': 'direct'},
    'entity.command': {'bedrock': '@minecraft/server Entity.runCommand', 'mode': 'bridge'},
    'entity.dynamic_state': {'bedrock': '@minecraft/server Entity.setDynamicProperty', 'mode': 'bridge'},
    'block.event': {'bedrock': 'custom component / block event', 'mode': 'bridge'},
    'item.event': {'bedrock': 'custom component / item event', 'mode': 'bridge'},
    'tick.schedule': {'bedrock': '@minecraft/server system.run / runInterval', 'mode': 'direct'},
}

# Things that cannot be promised as a universal 1:1 conversion.
JAVA_ONLY = {
    'arbitrary_client_renderer': 'requires a Bedrock-side rendering implementation',
    'java_shader_pipeline': 'requires a separate graphics adaptation',
    'native_jvm_binary': 'cannot execute as Java bytecode inside Bedrock',
    'java_threading': 'requires scheduling/state adaptation',
}

def capability(name):
    return CAPABILITIES.get(name)
