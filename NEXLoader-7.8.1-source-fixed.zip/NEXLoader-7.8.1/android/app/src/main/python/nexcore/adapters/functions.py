from __future__ import annotations

from pathlib import PurePosixPath

# Conservative subset of commands whose Bedrock syntax commonly remains usable.
# The converter never rewrites unknown Java commands into potentially broken Bedrock commands.
SAFE_COMMANDS = {
    'say', 'tellraw', 'title', 'playsound', 'stopsound', 'particle',
    'summon', 'teleport', 'tp', 'give', 'clear', 'effect', 'tag',
    'scoreboard', 'setblock', 'fill', 'clone', 'kill', 'weather',
    'time', 'gamerule', 'difficulty', 'gamemode', 'spawnpoint',
    'setworldspawn', 'locate', 'execute', 'function', 'schedule',
    'data', 'experience', 'xp', 'damage', 'loot', 'attribute',
}


def _command_root(line: str) -> str | None:
    stripped = line.strip()
    if not stripped or stripped.startswith('#'):
        return None
    if stripped.startswith('/'):
        stripped = stripped[1:].lstrip()
    token = stripped.split(None, 1)[0] if stripped else ''
    return token.split(':')[-1].lower() if token else None


def translate_function(text: str):
    """Return status, translated text, diagnostics for a Java .mcfunction file.

    The safe subset is preserved byte-for-byte except for a leading '/' which
    Bedrock function files conventionally omit. Unknown commands are retained
    only as diagnostics and make the operation adaptable rather than silently
    producing an active but broken function.
    """
    diagnostics=[]
    out=[]
    unsupported=[]
    for line_no, raw in enumerate(text.splitlines(), 1):
        root=_command_root(raw)
        if root and root not in SAFE_COMMANDS:
            unsupported.append({'line':line_no,'command':root,'text':raw})
        # Bedrock function files generally accept commands without the leading slash.
        line=raw[1:] if raw.startswith('/') else raw
        out.append(line)
    if unsupported:
        diagnostics.append({'code':'FUNCTION_UNSUPPORTED_COMMAND','count':len(unsupported),'commands':unsupported})
        return 'adaptable', '\n'.join(out) + ('\n' if text.endswith('\n') or out else ''), diagnostics
    return 'convertible', '\n'.join(out) + ('\n' if text.endswith('\n') or out else ''), diagnostics


def function_path_info(name: str, default_namespace: str):
    parts=PurePosixPath(name).parts
    marker=next((i for i,part in enumerate(parts) if part in {'function','functions'}), None)
    if marker is None:
        return None
    if marker < 2 or marker + 1 >= len(parts):
        return None
    namespace=parts[1] or default_namespace
    rel='/'.join(parts[marker+1:])
    if not rel.endswith('.mcfunction'):
        return None
    rel=rel[:-len('.mcfunction')]
    if not rel:
        return None
    return namespace, rel
