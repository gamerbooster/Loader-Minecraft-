from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class PhysicsBody:
    body_id: str
    entity_type: str = 'minecraft:armor_stand'
    gravity: float = 0.08
    restitution: float = 0.25
    drag: float = 0.98
    fragments: int = 1
    tick_interval: int = 1

@dataclass
class PhysicsOperation:
    op: str
    body_id: str
    args: dict
    status: str = 'emulated'


def fragment_body(body_id: str, fragments: int, entity_type='minecraft:armor_stand') -> list[PhysicsOperation]:
    if fragments < 1 or fragments > 128:
        raise ValueError('fragments must be in [1, 128]')
    body = PhysicsBody(body_id, entity_type=entity_type, fragments=fragments)
    return [PhysicsOperation('spawn_body', body_id, asdict(body)),
            PhysicsOperation('tick_body', body_id, {'gravity': body.gravity, 'restitution': body.restitution, 'drag': body.drag, 'count': fragments})]


def to_ir_operations(body_id: str, fragments: int, entity_type='minecraft:armor_stand'):
    ops=[]
    for item in fragment_body(body_id, fragments, entity_type):
        args=dict(item.args)
        args['runtime_module']='physics'
        ops.append({'op': item.op, 'id': item.body_id, 'args': args, 'status': item.status})
    return ops
