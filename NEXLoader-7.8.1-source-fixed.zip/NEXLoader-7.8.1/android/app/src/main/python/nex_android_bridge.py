from __future__ import annotations
import json, shutil, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
CORE = ROOT / "nexcore"
if str(CORE) not in sys.path: sys.path.insert(0, str(CORE))
from adapters.resources import build_ir
from adapters.modpack import build_modpack_ir
from nex.compiler import compile_program, compile_modpack

def analyze(input_path: str, modpack: bool = False, fetch_externals: bool = False) -> str:
    src = Path(input_path).expanduser().resolve()
    is_pack = modpack or src.is_dir() or src.suffix.lower() in {".zip", ".mrpack", ".modpack"}
    if is_pack:
        program, resolution, tmp = build_modpack_ir(src, None, fetch_externals=fetch_externals)
        try:
            cap_counts = {}
            for op in program.operations:
                if op.op == "capability":
                    cap_counts[op.status] = cap_counts.get(op.status, 0) + 1
            invalid_diag = next((d for d in program.diagnostics if d.get("code") == "INVALID_JAR_FILES"), {})
            empty_diag = next((d for d in program.diagnostics if d.get("code") == "EMPTY_MODPACK"), None)
            payload = {
                "mode": "modpack",
                "status": "complete" if resolution.complete and not invalid_diag.get("count") else "partial",
                "mods": len(resolution.ordered),
                "ordered": [n.mod_id for n in resolution.ordered],
                "missing": [d.__dict__ for d in resolution.missing],
                "conflicts": resolution.conflicts,
                "cycles": resolution.cycles,
                "warnings": resolution.warnings,
                "capability_counts": cap_counts,
                "operations": len(program.operations),
                "invalid_jars": invalid_diag.get("count", 0),
                "empty_modpack": empty_diag is not None,
                "diagnostics": program.diagnostics,
            }
            return json.dumps(payload, ensure_ascii=False)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    info, program = build_ir(src)
    cap_counts = {}
    for op in program.operations:
        if op.op == "capability":
            cap_counts[op.status] = cap_counts.get(op.status, 0) + 1
    return json.dumps({
        "mode": "mod",
        "status": "partial" if any(o.status in {"adaptable", "incompatible"} for o in program.operations) else "complete",
        "loader": info.get("loader"),
        "mods": info.get("mods", []),
        "capability_counts": cap_counts,
        "operations": len(program.operations),
        "diagnostics": program.diagnostics,
    }, ensure_ascii=False)

def convert(input_path: str, output_root: str, modpack: bool = False, strict: bool = False, script_api: str = "2.9.0", fetch_externals: bool = False) -> str:
    src = Path(input_path).expanduser().resolve()
    out = Path(output_root).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    is_pack = modpack or src.is_dir() or src.suffix.lower() in {".zip", ".mrpack", ".modpack"}
    if is_pack:
        program, resolution, tmp = build_modpack_ir(src, None, fetch_externals=fetch_externals)
        try:
            if strict and not resolution.complete: raise ValueError("ModPack dependency resolution failed in strict mode")
            final = compile_modpack(program, out, resolution, script_api, strict=strict)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    else:
        _info, program = build_ir(src)
        final = compile_program(program, out, script_api)
    report_path = final / "conversion_report.json"
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
    addons = sorted(final.glob("*.mcaddon"))
    return json.dumps({
        "status": report.get("status", "complete"),
        "output_dir": str(final),
        "mcaddon": str(addons[0]) if addons else None,
        "report": str(report_path) if report_path.exists() else None,
        "runtime_modules": report.get("runtime_modules", []),
    }, ensure_ascii=False)
