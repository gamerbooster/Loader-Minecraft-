# Android build attempts — NEXLoader 7.8.0

The Android project is configured for AGP 8.11.1, Gradle 8.13, JDK 17+, Kotlin 2.2.20 and Chaquopy 17.0.0 with Python 3.13. AGP 8.11 documents Gradle 8.13, Build Tools 35.0.0 and JDK 17 as its compatibility baseline; Chaquopy 17 supports Python 3.10–3.14 and AGP 7.3–9.2. These version relationships were checked against the current official documentation.

## Attempts made in this workspace

1. `android/gradlew --version` — blocked: wrapper executable is not present in the source archive.
2. `gradle --version` — blocked: no system Gradle installation is present.
3. Download of the official Gradle 8.13 binary — blocked before transfer because the workspace cannot resolve `services.gradle.org` through DNS.
4. Android SDK discovery — no `android.jar`, `aapt2`, or `sdkmanager` was found in the workspace/container.
5. Host-side project validation — PASS: Python core tests, Android source lint, manifests/build metadata, and synchronization checks all pass.

A real APK is only claimed when `assembleDebug` produces `app-debug.apk`.
