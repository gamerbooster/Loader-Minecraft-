from pathlib import Path
ROOT=Path(__file__).parents[2]
main=(ROOT/"android/app/src/main/java/com/nex/loader/MainActivity.java").read_text(encoding="utf-8")
build=(ROOT/"android/app/build.gradle").read_text(encoding="utf-8")
bridge=ROOT/"android/app/src/main/python/nex_android_bridge.py"
assert bridge.exists() and "def convert(" in bridge.read_text(encoding="utf-8")
assert "FileProvider" in main and "application/zip" in main
assert "com.chaquo.python" in build and "arm64-v8a" in build and "x86_64" in build
assert "NEXLoader-6." not in main
print("1 Android Java shell points to embedded Python bridge + FileProvider: PASS")
print("2 Android build config uses Chaquopy + supported ABIs: PASS")
print("3 no hardcoded historical NEXLoader path in main source: PASS")
