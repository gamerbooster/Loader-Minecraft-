import json
from pathlib import Path

def _compiler_source():
    return (Path(__file__).parents[1] / "nex" / "compiler.py").read_text(encoding="utf-8")

def test_generated_with_uses_bedrock_manifest_shape():
    source = _compiler_source()
    assert "'generated_with': {'nexloader': [NEXLOADER_VERSION]}" in source

def test_generated_with_version_is_array_in_manifest_examples():
    examples = list((Path(__file__).parents[1] / ".." / "examples").glob("**/manifest.json"))
    assert examples
    checked = 0
    for path in examples:
        data = json.loads(path.read_text(encoding="utf-8"))
        gw = data.get("metadata", {}).get("generated_with")
        if gw is not None:
            assert isinstance(gw, dict)
            for versions in gw.values():
                assert isinstance(versions, list)
            checked += 1
    assert checked > 0
