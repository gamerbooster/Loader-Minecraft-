from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'core'))
bridge=(ROOT/'android/app/src/main/python/nex_android_bridge.py').read_text(encoding='utf-8')
main=(ROOT/'android/app/src/main/java/com/nex/loader/MainActivity.java').read_text(encoding='utf-8')
manifest=(ROOT/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)
ok('1 bridge exposes optional external fetch', 'fetch_externals: bool = False' in bridge and 'build_modpack_ir(src, None, fetch_externals=fetch_externals)' in bridge)
ok('2 Android fetch toggle exists and defaults off', 'fetchExternals = new CheckBox' in main and 'setChecked(false)'  in main)
ok('3 Android passes toggle to Python bridge', 'fetchMissingExternals = fetchExternals.isChecked()' in main)
ok('4 Internet permission declared', 'android.permission.INTERNET' in manifest)
print('ALL 4 ANDROID EXTERNAL FETCH TESTS PASS')
