from pathlib import Path
ROOT=Path(__file__).parents[2]
main=(ROOT/"android/app/src/main/java/com/nex/loader/MainActivity.java").read_text(encoding="utf-8")
bridge=(ROOT/"android/app/src/main/python/nex_android_bridge.py").read_text(encoding="utf-8")
build=(ROOT/"android/app/build.gradle").read_text(encoding="utf-8")
assert "public final class MainActivity extends Activity" in main
assert "Python.getInstance().getModule(\"nex_android_bridge\")" in main
assert 'bridge.callAttr("analyze"' in main and '"convert"' in main
assert "def analyze(" in bridge and "def convert(" in bridge
assert "application/x-modrinth-modpack+zip" in main
assert "compileSdk 36" in build
print("1 Android Java shell + Python bridge architecture: PASS")
print("2 file/modpack selection wiring retained: PASS")
print("3 compileSdk 36 retained: PASS")
print("ALL 3 TESTS PASS")
