from pathlib import Path
import sys, tempfile, zipfile, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.modpack import build_modpack_ir
from nex.compiler import compile_modpack
from adapters.dependencies import Resolution

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); pack=td/'pack'; pack.mkdir()
    payload=b'jar-bytes'
    (pack/'mods').mkdir(); (pack/'mods'/'demo.jar').write_bytes(payload)
    digest=hashlib.sha1(payload).hexdigest()
    (pack/'modrinth.index.json').write_text(json.dumps({'name':'hashpack','files':[{'path':'mods/demo.jar','fileSize':len(payload),'hashes':{'sha1':digest}}]}))
    program,res,tmp=build_modpack_ir(pack)
    try:
        diag=next(d for d in program.diagnostics if d.get('code')=='EXTERNAL_ARTIFACTS')
        v=diag['verification']
        ok('1 local Modrinth hash verified', v['counts']['verified']==1)
    finally:
        import shutil; shutil.rmtree(tmp,ignore_errors=True)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); pack=td/'pack'; pack.mkdir(); (pack/'mods').mkdir(); (pack/'mods'/'demo.jar').write_bytes(b'bad')
    (pack/'modrinth.index.json').write_text(json.dumps({'name':'badpack','files':[{'path':'mods/demo.jar','fileSize':3,'hashes':{'sha1':'00'*20}}]}))
    program,res,tmp=build_modpack_ir(pack)
    try:
        diag=next(d for d in program.diagnostics if d.get('code')=='EXTERNAL_ARTIFACTS')
        ok('2 hash mismatch detected', diag['verification']['counts']['mismatched']==1)
        failed=False
        try:
            compile_modpack(program,td/'out',res,strict=True)
        except ValueError:
            failed=True
        ok('3 strict rejects hash mismatch', failed)
    finally:
        import shutil; shutil.rmtree(tmp,ignore_errors=True)
print('ALL 3 EXTERNAL ARTIFACT TESTS PASS')
