from pathlib import Path
import json, zipfile, shutil, sys, io
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program
from nex.ir import Program, Operation

ROOT=Path('/tmp/nex35'); shutil.rmtree(ROOT,ignore_errors=True); ROOT.mkdir()
png=bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082')

def fixture(path, loader='fabric', modid='demo', extra=''):
    with zipfile.ZipFile(path,'w') as z:
        if loader=='fabric': z.writestr('fabric.mod.json', json.dumps({'id':modid,'version':'1.0.0'}))
        elif loader=='forge': z.writestr('META-INF/mods.toml', f'modLoader="javafml"\nloaderVersion="[1,)"\n[[mods]]\nmodId="{modid}"\nversion="1.0.0"\n')
        z.writestr(f'assets/{modid}/blockstates/machine.json', extra or '{"variants":{"":{"model":"'+modid+':block/machine"}}}')
        z.writestr(f'assets/{modid}/models/block/machine.json', '{"textures":{"all":"'+modid+':block/machine"},"elements":[{"from":[0,0,0],"to":[16,16,16],"uv":[0,0]}]}')
        z.writestr(f'assets/{modid}/textures/block/machine.png', png)

# 1 basic Fabric
f=ROOT/'fabric.jar'; fixture(f); info,p=build_ir(f); out=compile_program(p,ROOT/'fout'); assert (out/'demo.mcaddon').exists(); assert (out/'behavior_pack/blocks/machine.json').exists(); assert (out/'resource_pack/textures/block/machine.png').exists(); print('1 basic Fabric PASS')
# 2 Forge
fg=ROOT/'forge.jar'; fixture(fg,'forge','forge_demo'); info,p=build_ir(fg); assert info['loader']=='forge'; out=compile_program(p,ROOT/'fgout'); assert (out/'forge_demo.mcaddon').exists(); print('2 Forge PASS')
# 3 4-way state variants -> permutations + states
variants='{"variants": {"facing=north":{"model":"demo:block/machine"},"facing=south":{"model":"demo:block/machine"},"facing=east":{"model":"demo:block/machine"},"facing=west":{"model":"demo:block/machine"}}}'
fv=ROOT/'variants.jar'; fixture(fv,extra=variants); _,p=build_ir(fv); out=compile_program(p,ROOT/'varout'); b=json.loads((out/'behavior_pack/blocks/machine.json').read_text()); desc=b['minecraft:block']['description']; assert set(desc['states']['facing'])=={'north','south','east','west'}; assert len(b['minecraft:block']['permutations'])==3; print('3 multi-variant PASS')
# 4 parent chain
par=ROOT/'parent.jar'
with zipfile.ZipFile(par,'w') as z:
 z.writestr('fabric.mod.json',json.dumps({'id':'parentdemo','version':'1.0.0'}))
 z.writestr('assets/parentdemo/blockstates/x.json','{"variants":{"":{"model":"parentdemo:block/child"}}}')
 z.writestr('assets/parentdemo/models/block/base.json','{"textures":{"all":"parentdemo:block/x"},"elements":[{"from":[0,0,0],"to":[16,16,16]}]}')
 z.writestr('assets/parentdemo/models/block/child.json','{"parent":"parentdemo:block/base"}')
 z.writestr('assets/parentdemo/textures/block/x.png',png)
_,p=build_ir(par); out=compile_program(p,ROOT/'parout'); assert (out/'resource_pack/textures/block/x.png').exists(); assert (out/'behavior_pack/blocks/x.json').exists(); print('4 parent resolution PASS')
# 5 missing texture guard
bad=ROOT/'bad.jar'; fixture(bad, extra='{"variants":{"":{"model":"bad:block/machine"}}}')
# remove texture by rebuilding
with zipfile.ZipFile(bad,'a') as z: pass
# actually build a different fixture with no texture
shutil.rmtree('/tmp/badfix',ignore_errors=True)
with zipfile.ZipFile(ROOT/'bad2.jar','w') as z:
 z.writestr('fabric.mod.json',json.dumps({'id':'bad2','version':'1.0.0'})); z.writestr('assets/bad2/blockstates/x.json','{"variants":{"":{"model":"bad2:block/x"}}}'); z.writestr('assets/bad2/models/block/x.json','{"textures":{"all":"bad2:block/x"},"elements":[{"from":[0,0,0],"to":[16,16,16]}]}')
_,p=build_ir(ROOT/'bad2.jar'); out=compile_program(p,ROOT/'bad2out'); r=json.loads((out/'conversion_report.json').read_text()); assert r['status']=='partial' and r['missing_resources']; print('5 missing texture guard PASS')
# 6 deterministic output: same jar twice
_,p=build_ir(f); a=compile_program(p,ROOT/'d1'); _,p2=build_ir(f); c=compile_program(p2,ROOT/'d2')
def hashes(root):
 import hashlib
 return sorted((str(x.relative_to(root)), hashlib.sha256(x.read_bytes()).hexdigest()) for x in root.rglob('*') if x.is_file() and '.mcpack' not in x.name and '.mcaddon' not in x.name)
assert hashes(a)==hashes(c); print('6 deterministic source outputs PASS')
# 7 invalid id rejected
try: compile_program(Program('demo',[Operation('register_block','bad id',{},'convertible','fabric')]),ROOT/'badid')
except ValueError: print('7 invalid ID rejection PASS')
else: raise AssertionError('invalid id accepted')
# 8 mcaddon contains two valid packs, each has manifest
with zipfile.ZipFile(a/'demo.mcaddon') as z:
 assert set(z.namelist())=={'demo.behavior.mcpack','demo.resource.mcpack'}
 for n in z.namelist():
  with zipfile.ZipFile(io.BytesIO(z.read(n))) as sub:
   assert 'manifest.json' in sub.namelist()
   for j in [x for x in sub.namelist() if x.endswith('.json')]: json.loads(sub.read(j))
print('8 archive structure PASS')
print('ALL 8 TESTS PASS')
