from pathlib import Path
ROOT=Path(__file__).parents[2]
main=ROOT/"android/app/src/main/java/com/nex/loader/MainActivity.java"
build=ROOT/"android/app/build.gradle"
manifest=ROOT/"android/app/src/main/AndroidManifest.xml"
assert main.exists() and build.exists() and manifest.exists()
main_text=main.read_text(encoding="utf-8")
build_text=build.read_text(encoding="utf-8")
manifest_text=manifest.read_text(encoding="utf-8")
assert "ACTION_OPEN_DOCUMENT" in main_text
assert "ACTION_OPEN_DOCUMENT_TREE" in main_text
assert "application/zip" in main_text and "application/octet-stream" in main_text and "application/x-modrinth-modpack+zip" in main_text
assert "takePersistableUriPermission" in main_text
assert "startActivityForResult" in main_text
assert "com.chaquo.python" in build_text
version=(ROOT/"VERSION").read_text(encoding="utf-8").strip(); major,minor,patch=version.split('.')
assert f"versionCode {int(major)*10+int(minor)}" in build_text and f"versionName '0.{major}.{minor}'" in build_text
assert "android.intent.category.BROWSABLE" in manifest_text and "application/x-modrinth-modpack+zip" in manifest_text
print("1 Java file/folder picker wiring: PASS")
print("2 persistent URI handoff + supported MIME types: PASS")
print("3 Android version/dependency sync: PASS")
