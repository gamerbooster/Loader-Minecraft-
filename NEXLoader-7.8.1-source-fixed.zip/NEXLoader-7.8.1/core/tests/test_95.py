from pathlib import Path
import sys, tempfile, zipfile
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from nex.io_limits import ArchiveLimitError, read_zip_member

with tempfile.TemporaryDirectory() as td:
    td=Path(td); zpath=td/'a.zip'
    with zipfile.ZipFile(zpath,'w') as z: z.writestr('tiny.txt', b'12345')
    with zipfile.ZipFile(zpath) as z:
        assert read_zip_member(z,'tiny.txt',5)==b'12345'
        try:
            read_zip_member(z,'tiny.txt',4)
            raise AssertionError('expected ArchiveLimitError')
        except ArchiveLimitError:
            pass
print('1 bounded ZIP read exact ceiling: PASS')
print('2 bounded ZIP read rejects oversized member: PASS')
print('ALL 2 IO LIMIT TESTS PASS')
