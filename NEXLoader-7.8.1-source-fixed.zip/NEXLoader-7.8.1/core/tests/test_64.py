from pathlib import Path
import json, shutil, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.ir import Program, Operation
from nex.compiler import compile_program
from nex.version import NEXLOADER_VERSION

ROOT=Path('/tmp/nex64'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

# 1 unsafe config path can never escape the behavior pack root.
p=Program('safe',[Operation('register_config','safe:bad',{
    'mod_id':'safe','path':'config/../../outside.txt','format':'raw','bytes_hex':'4142'
},'convertible','fabric')])
out=compile_program(p,ROOT/'config')
assert not (out.parent/'outside.txt').exists()
assert json.loads((out/'conversion_report.json').read_text())['conflicts']
print('1 config path traversal blocked: PASS')

# 2 unsafe sound path is reported instead of written outside the resource pack.
p2=Program('safeaudio',[Operation('register_sound','safeaudio:bad',{
    'definition':{'category':'master','sounds':[{'name':'sounds/safeaudio/../escape'}]},
    'assets_bytes_hex':{'assets/safeaudio/sounds/../escape.ogg':'4f67'},
},'convertible','fabric')])
out2=compile_program(p2,ROOT/'sound')
report=json.loads((out2/'conversion_report.json').read_text())
assert not (out2/'resource_pack/escape.ogg').exists()
print('2 sound path traversal blocked: PASS')

# 3 safe ordinary nested config still copies into its own mod folder.
p3=Program('safeok',[Operation('register_config','safeok:cfg',{
    'mod_id':'safeok','path':'config/nex/settings.json','format':'json','bytes_hex':'7b7d'
},'convertible','fabric')])
out3=compile_program(p3,ROOT/'ok')
assert (out3/'behavior_pack/nex_config/safeok/config/nex/settings.json').read_bytes()==b'{}'
print('3 safe config preserved: PASS')

# 4 generated manifests still retain the generated_with metadata after hardening.
m=json.loads((out3/'behavior_pack/manifest.json').read_text())
assert m['metadata']['generated_with']['nexloader']==NEXLOADER_VERSION
print('4 manifest metadata preserved: PASS')

print('ALL 4 TESTS PASS')
