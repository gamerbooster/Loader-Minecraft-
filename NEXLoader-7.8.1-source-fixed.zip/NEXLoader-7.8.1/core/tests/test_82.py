from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'core'))
sys.path.insert(0,str(ROOT/'android/app/src/main/python'))
from nex_android_bridge import analyze

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)
raw=analyze(str(ROOT/'examples/capdemo.jar'))
data=json.loads(raw)
ok('1 Android bridge returns JSON', data['mode']=='mod')
ok('2 Android bridge uses core analyzer', data['operations']>0 and data['loader']=='fabric')
ok('3 Android bridge reports capabilities', isinstance(data.get('capability_counts'),dict))
print('ALL 3 ANDROID BRIDGE TESTS PASS')
