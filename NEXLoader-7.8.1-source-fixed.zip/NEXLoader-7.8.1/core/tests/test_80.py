from pathlib import Path
import sys,tempfile,zipfile,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.modpack import extract_pack

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)
with tempfile.TemporaryDirectory() as td:
    root=Path(td)/'pack'; (root/'overrides/config').mkdir(parents=True)
    (root/'overrides/config/demo.json').write_text('{}')
    (root/'client-overrides/resourcepacks').mkdir(parents=True)
    (root/'client-overrides/resourcepacks/rp.txt').write_text('x')
    out,info=extract_pack(root)
    overlays=info['overlays']
    ok('1 override scopes detected', {x['scope'] for x in overlays}=={'overrides','client-overrides'})
    ov=next(x for x in overlays if x['scope']=='overrides')
    ok('2 override categories detected', ov['categories'].get('config')==1)
    ok('3 override paths retained', ov['paths']==['config/demo.json'])
print('ALL 3 OVERLAY TESTS PASS')
