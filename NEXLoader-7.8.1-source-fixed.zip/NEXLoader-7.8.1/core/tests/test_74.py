from pathlib import Path
import json, shutil, sys, zipfile
ROOT=Path(__file__).parents[2]
sys.path.insert(0, str(ROOT/'android/app/src/main/python'))
import nex_android_bridge

for label, src, is_pack in [('jar', ROOT/'examples/capdemo.jar', False), ('mrpack', ROOT/'examples/bridge_test.mrpack', True)]:
    out=Path('/tmp')/f'nex74-{label}'; shutil.rmtree(out, ignore_errors=True); out.mkdir(parents=True)
    obj=json.loads(nex_android_bridge.convert(str(src), str(out), is_pack, False, '2.9.0'))
    addon=Path(obj['mcaddon'])
    assert addon.is_file(), obj
    with zipfile.ZipFile(addon) as outer:
        packs=[n for n in outer.namelist() if n.endswith('.mcpack')]
        assert len(packs) == 2, packs
        for name in packs:
            data=outer.read(name)
            with zipfile.ZipFile(__import__('io').BytesIO(data)) as inner:
                assert 'manifest.json' in inner.namelist(), name
                manifest=json.loads(inner.read('manifest.json'))
                assert manifest['header']['name']
    print(f'1 {label} bridge emits valid nested mcpack pair: PASS')
print('2 outer mcaddon archive validation: PASS')
