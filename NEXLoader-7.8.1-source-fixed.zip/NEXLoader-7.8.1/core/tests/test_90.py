from pathlib import Path
import json, zipfile, shutil, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex_worldgen_76'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
jar=ROOT/'worldgen.jar'
with zipfile.ZipFile(jar,'w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'wg','version':'1.0.0'}))
    z.writestr('data/wg/worldgen/configured_feature/copper_ore.json', json.dumps({
        'type':'minecraft:ore', 'config':{
            'size':9,
            'discard_chance_on_air_exposure':0.2,
            'targets':[
                {'target':{'predicate':{'blocks':'minecraft:stone'}},'state':{'Name':'wg:copper_ore'}},
                {'target':{'predicate':{'blocks':['minecraft:deepslate']}},'state':{'Name':'wg:deep_copper_ore'}}
            ]
        }
    }))
    z.writestr('data/wg/worldgen/placed_feature/copper_ore_placed.json', json.dumps({
        'feature':'wg:copper_ore', 'placement':[
            {'type':'minecraft:count','count':4},
            {'type':'minecraft:in_square'},
            {'type':'minecraft:height_range','height':{'type':'minecraft:uniform','min_inclusive':{'absolute':-32},'max_inclusive':{'absolute':64}}},
            {'type':'minecraft:biome'}
        ]
    }))
    z.writestr('data/wg/worldgen/biome/copper_plains.json', json.dumps({
        'temperature':0.7, 'downfall':0.3,
        'features':[['wg:copper_ore_placed']]
    }))
info,p=build_ir(jar)
wgops=[o for o in p.operations if o.op=='register_worldgen']
assert any(o.args.get('kind')=='configured_feature' and o.status=='emulated' for o in wgops)
assert any(o.args.get('kind')=='placed_feature' and o.status=='emulated' for o in wgops)
assert any(o.args.get('kind')=='feature_rule' and o.status=='emulated' for o in wgops)
out=compile_program(p, ROOT/'out')
ore=out/'behavior_pack/features/copper_ore.json'
placed=out/'behavior_pack/features/copper_ore_placed.json'
rules=list((out/'behavior_pack/feature_rules').glob('*.json'))
biome=out/'behavior_pack/biomes/copper_plains.json'
assert ore.exists() and placed.exists() and rules and biome.exists()
orej=json.loads(ore.read_text()); assert orej['minecraft:ore_feature']['count']==9
assert len(orej['minecraft:ore_feature']['replace_rules'])==2
pj=json.loads(placed.read_text()); assert pj['minecraft:scatter_feature']['distribution']['iterations']==4
bj=json.loads(biome.read_text()); tags=bj['minecraft:biome']['components']['minecraft:tags']['tags']; assert any(t.startswith('nex_biome_') for t in tags)
assert any(json.loads(x.read_text())['minecraft:feature_rules']['description']['places_feature']=='wg:copper_ore_placed' for x in rules)
print('1 simple Java ore -> Bedrock feature: PASS')
print('2 placed feature -> Bedrock scatter feature: PASS')
print('3 biome feature attachment -> Bedrock feature rule: PASS')
print('4 generated worldgen JSONs validate: PASS')
print('ALL 4 WORLDGEN LOWERING TESTS PASS')
