from pathlib import Path
import sys,tempfile,zipfile,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)
with tempfile.TemporaryDirectory() as td:
    td=Path(td); jar=td/'a.jar';
    with zipfile.ZipFile(jar,'w') as z: z.writestr('fabric.mod.json',json.dumps({'id':'analyze81','version':'1.0'}))
    out=subprocess.run([sys.executable,str(ROOT/'nex_convert.py'),str(jar),str(td/'out'),'--analyze-only'],cwd=ROOT.parent,capture_output=True,text=True,check=True)
    data=json.loads(out.stdout)
    ok('1 mod analyze-only returns JSON', data['mode']=='mod' and data['mod_id']=='analyze81')
    ok('2 analyze-only does not create output', not (td/'out').exists())
print('ALL 2 ANALYZE-ONLY TESTS PASS')
