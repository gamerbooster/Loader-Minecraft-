from pathlib import Path
import json, zipfile, shutil, subprocess, sys, io
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.modpack import build_modpack_ir
from nex.compiler import compile_modpack

ROOT=Path('/tmp/nex53'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

def make_jar(path, mod_id, version, deps, classes):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json', json.dumps({'id':mod_id,'version':version,'depends':deps}))
        for name,content in classes.items(): z.writestr(name,content)
        z.writestr(f'config/{mod_id}.json', json.dumps({'enabled':True,'power':3}))
        z.writestr(f'config/{mod_id}.toml', 'enabled = true\npower = 3\n')
        z.writestr(f'config/{mod_id}.cfg', '[general]\nenabled=true\npower=3\n')

src=ROOT/'src'; (src/'api').mkdir(parents=True); (src/'main').mkdir(parents=True)
(src/'api/Api.java').write_text('''package api; public class Api { public void ping() {} }''')
(src/'main/Main.java').write_text('''package main; public class Main { public void use(api.Api api) { api.ping(); } }''')
subprocess.run(['javac','-d',str(ROOT/'classes'),str(src/'api/Api.java'),str(src/'main/Main.java')],check=True)
api_cls=(ROOT/'classes/api/Api.class').read_bytes(); main_cls=(ROOT/'classes/main/Main.class').read_bytes()

jar_b=ROOT/'b.jar'; jar_a=ROOT/'a.jar'
make_jar(jar_b,'modb','1.0.0',{}, {'com/modb/Api.class':api_cls})
# Rewrite Main package owner into com.moda but its bytecode calls api.Api; instead compile a package-named fixture.
src2=ROOT/'src2'; (src2/'com/modb').mkdir(parents=True); (src2/'com/moda').mkdir(parents=True)
(src2/'com/modb/Api.java').write_text('''package com.modb; public class Api { public void ping() {} }''')
(src2/'com/moda/Main.java').write_text('''package com.moda; public class Main { public void use(com.modb.Api api) { api.ping(); } }''')
subprocess.run(['javac','-d',str(ROOT/'classes2'),str(src2/'com/modb/Api.java'),str(src2/'com/moda/Main.java')],check=True)
api2=(ROOT/'classes2/com/modb/Api.class').read_bytes(); main2=(ROOT/'classes2/com/moda/Main.class').read_bytes()
make_jar(jar_b,'modb','1.0.0',{}, {'com/modb/Api.class':api2})
make_jar(jar_a,'moda','1.0.0',{'modb':'>=1.0.0'}, {'com/moda/Main.class':main2})

pack=ROOT/'pack'; (pack/'mods').mkdir(parents=True)
shutil.copy2(jar_a,pack/'mods/a.jar'); shutil.copy2(jar_b,pack/'mods/b.jar')
program,res,tmp=build_modpack_ir(pack,'contracts')
ops=[o for o in program.operations if o.op=='intermod_call']
assert len(ops)==1 and ops[0].args['target_mod']=='modb' and ops[0].args['resolved'] is True and ops[0].status=='emulated'
configs=[o for o in program.operations if o.op=='register_config']
assert len(configs)==6
assert sum(1 for o in configs if 'value' in o.args)==6
out=ROOT/'out'; compile_modpack(program,out,res)
assert (out/'behavior_pack/scripts/nex_runtime/intermod.js').exists()
assert (out/'behavior_pack/scripts/nex_runtime/config.js').exists()
assert (out/'behavior_pack/nex_config/moda/config/moda.json').exists()
assert (out/'behavior_pack/nex_config/moda/config/moda.toml').exists()
report=json.loads((out/'conversion_report.json').read_text())
assert report['intermod_contracts'] and report['configs']
print('1 inter-mod resolved call + contracts: PASS')
print('2 config JSON/TOML/CFG extraction: PASS')
print('3 runtime modules packaged: PASS')
print('4 modpack report includes configs/contracts: PASS')

# unresolved cross-mod call: same owner+name but incompatible descriptor must not be called resolved.
src3=ROOT/'src3'; (src3/'com/moda').mkdir(parents=True); (src3/'com/modx').mkdir(parents=True)
(src3/'com/modx/ApiCaller.java').write_text('''package com.modx; public class ApiCaller { public static void call() {} }''')
(src3/'com/modx/Api.java').write_text('''package com.modx; public class Api { public void ping() {} }''')
(src3/'com/moda/Main.java').write_text('''package com.moda; public class Main { public void use(com.modx.Api api) { api.ping(1); } }''')
# Caller is compiled against a temporary stub whose signature differs from the target jar signature.
stub=ROOT/'stub'; (stub/'com/modx').mkdir(parents=True)
(stub/'com/modx/Api.java').write_text('''package com.modx; public class Api { public void ping(int value) {} }''')
subprocess.run(['javac','-d',str(ROOT/'classes3'),str(stub/'com/modx/Api.java'),str(src3/'com/moda/Main.java')],check=True)
subprocess.run(['javac','-d',str(ROOT/'classes3_target'),str(src3/'com/modx/Api.java')],check=True)
jar_x=ROOT/'x.jar'; jar_caller=ROOT/'caller.jar'
make_jar(jar_x,'modx','1.0.0',{}, {'com/modx/Api.class':(ROOT/'classes3_target/com/modx/Api.class').read_bytes()})
make_jar(jar_caller,'moda2','1.0.0',{'modx':'*'}, {'com/moda/Main.class':(ROOT/'classes3/com/moda/Main.class').read_bytes()})
pack2=ROOT/'pack2'; (pack2/'mods').mkdir(parents=True)
shutil.copy2(jar_x,pack2/'mods/x.jar'); shutil.copy2(jar_caller,pack2/'mods/caller.jar')
p2,r2,t2=build_modpack_ir(pack2,'unresolved')
ops2=[o for o in p2.operations if o.op=='intermod_call']
assert len(ops2)==1 and ops2[0].args['target_mod']=='modx' and ops2[0].args['resolved'] is False and ops2[0].status=='adaptable'
print('5 unresolved inter-mod signature mismatch: PASS')
shutil.rmtree(t2,ignore_errors=True)

# 6-7 resource collision policy inside a ModPack.
def resource_jar(path, mod_id, png_bytes):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json', json.dumps({'id':mod_id,'version':'1.0.0'}))
        z.writestr('assets/shared/items/chip.json','{}')
        z.writestr('assets/shared/textures/item/chip.png',png_bytes)

a=ROOT/'ra.jar'; b=ROOT/'rb.jar'
resource_jar(a,'ra',b'A'); resource_jar(b,'rb',b'A')
pack3=ROOT/'pack3'; (pack3/'mods').mkdir(parents=True)
shutil.copy2(a,pack3/'mods/a.jar'); shutil.copy2(b,pack3/'mods/b.jar')
p3,r3,t3=build_modpack_ir(pack3,'dedup')
dedup=[d for d in p3.diagnostics if d.get('code')=='DUPLICATE_RESOURCE_DEDUP']
assert dedup and not any(d.get('conflicts') for d in p3.diagnostics if d.get('code')=='RESOURCE_CONFLICT_ANALYSIS')
compile_modpack(p3,ROOT/'dedup_out',r3,strict=True)
print('6 identical resource collision deduplication: PASS')
shutil.rmtree(t3,ignore_errors=True)

resource_jar(b,'rb',b'B')
shutil.copy2(b,pack3/'mods/b.jar')
p4,r4,t4=build_modpack_ir(pack3,'collision')
rc=[d for d in p4.diagnostics if d.get('code')=='RESOURCE_CONFLICT_ANALYSIS'][0]
assert len(rc['conflicts'])==1
out4=compile_modpack(p4,ROOT/'collision_out',r4,strict=False)
rep4=json.loads((out4/'conversion_report.json').read_text())
assert rep4['status']=='partial'
try:
    compile_modpack(p4,ROOT/'collision_strict',r4,strict=True)
except ValueError as e:
    assert 'resource conflicts' in str(e)
else:
    raise AssertionError('strict mode accepted resource collision')
print('7 differing resource collision + strict rejection: PASS')
shutil.rmtree(t4,ignore_errors=True)
shutil.rmtree(tmp,ignore_errors=True)
