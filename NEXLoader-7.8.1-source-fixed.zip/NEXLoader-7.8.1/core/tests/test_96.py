from pathlib import Path
import sys, tempfile, zipfile, json
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from adapters.resources import build_ir

with tempfile.TemporaryDirectory() as td:
    td=Path(td); jar=td/'bigclass.jar'
    big=b'0'*1024
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json', json.dumps({'id':'bigclass','version':'1.0.0'}))
        z.writestr('com/example/Huge.class', big)
    # A deliberately tiny env ceiling proves the per-class guard is actually wired.
    import os
    old=os.environ.get('NEX_MAX_CLASS_BYTES'); os.environ['NEX_MAX_CLASS_BYTES']='16'
    try:
        # module constants are evaluated on import, so the test validates the diagnostic
        # through the actual default-sized path using a monkeypatched module constant.
        import adapters.resources as resources
        oldlim=resources.MAX_CLASS_BYTES; resources.MAX_CLASS_BYTES=16
        try:
            _, program=build_ir(jar)
        finally:
            resources.MAX_CLASS_BYTES=oldlim
    finally:
        if old is None: os.environ.pop('NEX_MAX_CLASS_BYTES',None)
        else: os.environ['NEX_MAX_CLASS_BYTES']=old
    assert any(d.get('code')=='CLASSFILE_SKIPPED_LIMIT' for d in program.diagnostics)
print('1 oversized Java class is skipped with diagnostic: PASS')
print('ALL CLASS LIMIT TESTS PASS')
