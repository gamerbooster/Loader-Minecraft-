from pathlib import Path
import json, zipfile, shutil, subprocess, sys, io, hashlib
sys.path.insert(0, str(Path(__file__).parents[1]))

from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program
from nex.ir import Program, Operation
from compat.capability import classify_java_call
from compat.physics import to_ir_operations

ROOT=Path('/tmp/nex52'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

# Tiny valid 1x1 PNG.
png=bytes.fromhex('89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000D49444154789C63600000FFFF0005FE02FEA7D0A8D00000000049454E44AE426082')

# 1: resource-only Fabric remains compatible.
fab=ROOT/'fabric.jar'
with zipfile.ZipFile(fab,'w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'demo52','version':'1.0.0'}))
    z.writestr('assets/demo52/blockstates/machine.json','{"variants":{"":{"model":"demo52:block/machine"}}}')
    z.writestr('assets/demo52/models/block/machine.json','{"textures":{"all":"demo52:block/machine"},"elements":[{"from":[0,0,0],"to":[16,16,16]}]}')
    z.writestr('assets/demo52/textures/block/machine.png', png)
_, p=build_ir(fab)
out=compile_program(p, ROOT/'fabric_out')
assert (out/'demo52.mcaddon').exists()
assert json.loads((out/'conversion_report.json').read_text())['status']=='complete'
print('1 resource Fabric: PASS')

# 2: compile a Java class that calls several recognizable APIs and verify those calls land in NEX-IR.
java=ROOT/'capdemo'
(java/'src/pkg').mkdir(parents=True)
(java/'src/pkg/Demo.java').write_text('''package pkg;\npublic class Demo {\n  public void f(net.minecraft.entity.LivingEntity e) {\n    e.addStatusEffect(null);\n    e.removeStatusEffect(null);\n    e.teleportTo(0,0,0);\n    e.push(0.0,1.0,0.0);\n    e.hurt(null, 1.0f);\n  }\n}\n''')
# Stub only what javac needs.
(java/'src/net/minecraft/entity').mkdir(parents=True)
(java/'src/net/minecraft/entity/LivingEntity.java').write_text('''package net.minecraft.entity;\npublic class LivingEntity {\n public void addStatusEffect(Object x){} public void removeStatusEffect(Object x){}\n public void teleportTo(double x,double y,double z){} public void push(double x,double y,double z){}\n public boolean hurt(Object src,float amount){return true;}\n}\n''')
subprocess.run(['javac','-d',str(java/'classes'),str(java/'src/pkg/Demo.java'),str(java/'src/net/minecraft/entity/LivingEntity.java')],check=True)
capjar=ROOT/'capdemo.jar'
with zipfile.ZipFile(capjar,'w') as z:
    z.writestr('fabric.mod.json', json.dumps({'id':'capdemo','version':'1.0.0'}))
    for f in (java/'classes').rglob('*.class'): z.write(f, f.relative_to(java/'classes'))
info,cp=build_ir(capjar)
ids=[o.id for o in cp.operations if o.op=='capability']
assert 'effects.add' in ids and 'effects.remove' in ids and 'entity.teleport' in ids and 'entity.impulse' in ids and 'entity.damage' in ids
report=compile_program(cp,ROOT/'capdemo_out')
r=json.loads((report/'conversion_report.json').read_text())
assert r['capability_counts'].get('convertible',0) >= 5
print('2 Java capability recovery: PASS')

# 3: rendering and JVM/socket classifications remain explicit.
assert classify_java_call('com/mojang/blaze3d/vertex/PoseStack','pushPose').status=='adaptable'
assert classify_java_call('org/lwjgl/opengl/GL11','glBegin').status=='adaptable'
assert classify_java_call('java/net/Socket','connect').status=='incompatible'
assert classify_java_call('java/lang/Thread','start').status=='emulated'
print('3 impossible/needs-rebuild classes: PASS')

# 4: runtime physics IR compiles and packages modular runtime code.
p=Program('physics52')
for x in to_ir_operations('wreck', 8):
    p.add(Operation(x['op'], x['id'], x['args'], x['status'], 'runtime'))
out=compile_program(p,ROOT/'physics_out')
assert (out/'behavior_pack/scripts/nex_runtime/physics.js').exists()
bridge=(out/'behavior_pack/scripts/nex_bridge.js').read_text()
assert 'startPhysics' in bridge and 'nexPhysicsBodies' in bridge
assert 'scripts/nex_bridge.js' in json.loads((out/'behavior_pack/manifest.json').read_text())['modules'][1]['entry']
print('4 physics runtime packaging: PASS')

# 5: adaptable/incompatible findings cause partial report but do not disappear.
p=Program('limits52', [
    Operation('capability','render.custom',{'target':'Bedrock entity/resource implementation','reason':'renderer'},'adaptable','java','Render.java'),
    Operation('capability','java.jvm',{'target':'none','reason':'JVM'},'incompatible','java','Main.class'),
])
out=compile_program(p,ROOT/'limits_out')
r=json.loads((out/'conversion_report.json').read_text())
assert r['status']=='partial' and r['capability_counts']=={'adaptable':1,'incompatible':1}
skipped=r['skipped']
assert {x['id'] for x in skipped}=={'render.custom','java.jvm'}
print('5 explicit limitation report: PASS')

# 6: output is deterministic, including generated scripts.
p=Program('det52', [Operation('capability','physics.body',{'target':'NEX physics runtime','reason':'x'},'emulated','java') , Operation('spawn_body','wreck',{'fragments':2},'emulated','runtime')])
a=compile_program(p,ROOT/'d1'); b=compile_program(p,ROOT/'d2')
def files_hash(root):
    vals=[]
    for f in sorted(root.rglob('*')):
        if f.is_file() and not f.name.endswith(('.mcpack','.mcaddon')):
            vals.append((str(f.relative_to(root)), hashlib.sha256(f.read_bytes()).hexdigest()))
    return vals
assert files_hash(a)==files_hash(b)
print('6 deterministic runtime output: PASS')

# 7: nested mcaddon remains structurally valid.
with zipfile.ZipFile(a/'det52.mcaddon') as z:
    assert set(z.namelist())=={'det52.behavior.mcpack','det52.resource.mcpack'}
    for member in z.namelist():
        with zipfile.ZipFile(io.BytesIO(z.read(member))) as pack:
            assert 'manifest.json' in pack.namelist()
            for name in pack.namelist():
                if name.endswith('.json'): json.loads(pack.read(name))
print('7 mcaddon archive validation: PASS')

print('ALL 7 TESTS PASS')
