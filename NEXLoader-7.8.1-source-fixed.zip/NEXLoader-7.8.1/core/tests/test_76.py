from pathlib import Path
import sys, tempfile, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nex.ir import Program, Operation
from nex.compiler import compile_program
from nex.target import SCRIPT_UI_API

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    p=Program('ui_runtime_test')
    p.add(Operation('ui_screen','ui_runtime_test:screen',{'title_hint':'Settings'},'adaptable','java','fixture'))
    out=Path(td)
    compile_program(p,out)
    ui=out/'behavior_pack'/'scripts'/'nex_runtime'/'ui.js'
    bridge=out/'behavior_pack'/'scripts'/'nex_bridge.js'
    manifest=json.loads((out/'behavior_pack'/'manifest.json').read_text())
    deps=manifest.get('dependencies',[])
    ui_dep=next((d for d in deps if d.get('module_name')=='@minecraft/server-ui'),None)
    ok('1 adaptable UI activates runtime', ui.exists() and bridge.exists())
    ok('2 UI dependency is present', ui_dep is not None)
    ok('3 UI dependency is 2.2.0', ui_dep and ui_dep['version']==SCRIPT_UI_API=='2.2.0')
    text=ui.read_text()
    ok('4 toggle options syntax', 'defaultValue: Boolean(f.default)' in text)
    ok('5 slider options syntax', 'valueStep: Number(f.step ?? 1)' in text and 'defaultValue: Number(f.default ?? 0)' in text)
    ok('6 dropdown options syntax', 'defaultValueIndex: Number(f.default ?? 0)' in text)
    ok('7 text field options syntax', 'defaultValue: String(f.default ?? "")' in text)
with tempfile.TemporaryDirectory() as td:
    p=Program('input_runtime_test')
    p.add(Operation('keybind','input_runtime_test:jump',{'button_hint':'Jump'},'adaptable','java','fixture'))
    out=Path(td); compile_program(p,out)
    ok('8 adaptable keybind activates input runtime', (out/'behavior_pack'/'scripts'/'nex_runtime'/'input.js').exists())
print('ALL 8 TESTS PASS')
