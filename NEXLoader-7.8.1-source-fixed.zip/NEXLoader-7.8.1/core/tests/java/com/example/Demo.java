package com.example;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.world.World;
public class Demo {
  public static void init() { ServerTickEvents.END_SERVER_TICK.register(Demo::onTick); }
  public static void onTick(World world) { world.sendMessage("tick"); }
}
