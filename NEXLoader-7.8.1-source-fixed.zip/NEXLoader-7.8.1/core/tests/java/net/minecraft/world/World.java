package net.minecraft.world;
public class World { public void sendMessage(String s) {} }
