package net.minecraftforge.eventbus.api;
import java.util.function.Consumer;
public interface IEventBus { void addListener(Consumer<Object> c); }
