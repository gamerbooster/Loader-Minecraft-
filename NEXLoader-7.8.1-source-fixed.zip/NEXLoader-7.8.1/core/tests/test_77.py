from pathlib import Path
import sys, tempfile, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nex.ir import Program, Operation
from nex.compiler import compile_program

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    p=Program('worldgen_runtime_test')
    p.add(Operation('register_worldgen','demo:sky',{
        'kind':'dimension','capability':'worldgen.dimension','source_path':'data/demo/dimension/sky.json',
        'java_json':{'ambient_light':0.2,'height':384,'generator':{'type':'minecraft:noise'}},
        'bedrock_plan':{'ambient_light':0.2,'height':384}
    },'adaptable','fabric','data/demo/dimension/sky.json'))
    out=Path(td); compile_program(p,out)
    report=json.loads((out/'conversion_report.json').read_text())
    archived=out/'behavior_pack'/'nex_untranslated'/'worldgen'/'data/demo/dimension/sky.json'
    emitted=[x for x in report['emitted'] if x.get('op')=='register_worldgen']
    ok('1 worldgen op emitted', bool(emitted))
    ok('2 worldgen report present', len(report.get('worldgen',[]))==1 and report['worldgen'][0]['kind']=='dimension')
    ok('3 raw worldgen preserved', archived.exists() and json.loads(archived.read_text())['height']==384)
    ok('4 adaptable remains explicit', report['worldgen'][0]['status']=='adaptable')
print('ALL 4 WORLDGEN TESTS PASS')
