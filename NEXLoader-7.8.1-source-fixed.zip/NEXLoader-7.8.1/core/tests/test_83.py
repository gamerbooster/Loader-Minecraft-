from pathlib import Path
import sys, tempfile, json, hashlib, io
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.external_fetch import fetch_modrinth_files, ExternalFetchError

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

payload=b'verified-mod-jar'
sha1=hashlib.sha1(payload).hexdigest(); sha512=hashlib.sha512(payload).hexdigest()
class Resp:
    def __enter__(self): return self
    def __exit__(self,*a): return False
    def read(self): return payload
    def geturl(self): return 'https://cdn.modrinth.com/data/x/file.jar'

def opener(url,timeout=30):
    assert url=='https://cdn.modrinth.com/data/x/file.jar'; return Resp()
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    pack={'format':'modrinth','external_files':[{'path':'mods/demo.jar','downloads':['https://cdn.modrinth.com/data/x/file.jar'],'hashes':{'sha1':sha1,'sha512':sha512},'size':len(payload)}]}
    r=fetch_modrinth_files(root,pack,opener=opener)
    ok('1 verified external file downloaded', r['downloaded'][0]['status']=='verified' and (root/'mods/demo.jar').read_bytes()==payload)

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    pack={'format':'modrinth','external_files':[{'path':'mods/demo.jar','downloads':['http://cdn.modrinth.com/x'],'hashes':{'sha1':sha1},'size':len(payload)}]}
    r=fetch_modrinth_files(root,pack,opener=opener)
    ok('2 non-HTTPS host/URL is blocked', len(r['failed'])==1)

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    pack={'format':'modrinth','external_files':[{'path':'../escape.jar','downloads':['https://cdn.modrinth.com/data/x/file.jar'],'hashes':{'sha1':sha1}}]}
    r=fetch_modrinth_files(root,pack,opener=opener)
    ok('3 path traversal is rejected', len(r['failed'])==1 and 'unsafe' in r['failed'][0]['error'])

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    bad=b'bad'
    class BadResp(Resp):
        def read(self): return bad
    def badopener(url,timeout=30): return BadResp()
    pack={'format':'modrinth','external_files':[{'path':'mods/demo.jar','downloads':['https://cdn.modrinth.com/data/x/file.jar'],'hashes':{'sha1':sha1},'size':len(payload)}]}
    r=fetch_modrinth_files(root,pack,opener=badopener)
    ok('4 integrity mismatch never writes file', len(r['failed'])==1 and not (root/'mods/demo.jar').exists())
print('ALL 4 EXTERNAL FETCH TESTS PASS')
