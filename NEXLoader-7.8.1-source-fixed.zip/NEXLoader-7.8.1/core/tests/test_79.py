from pathlib import Path
import sys, tempfile, zipfile, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapters.resources import build_ir
from nex.compiler import compile_program

def ok(n,c):
    print(f'{n}: ' + ('PASS' if c else 'FAIL'))
    if not c: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); jar=td/'biome.jar'
    entries={
      'fabric.mod.json':json.dumps({'id':'biomemod','version':'1.0','depends':{}}).encode(),
      'data/biomemod/worldgen/biome/test.json':json.dumps({'temperature':0.8,'downfall':0.4,'effects':{'sky_color':123456}}).encode()
    }
    with zipfile.ZipFile(jar,'w') as z:
        for n,b in entries.items(): z.writestr(n,b)
    _, prog=build_ir(jar)
    out=Path(td/'out'); compile_program(prog,out)
    biome=out/'behavior_pack'/'biomes'/'test.json'
    raw=out/'behavior_pack'/'nex_untranslated'/'worldgen'/'data/biomemod/worldgen/biome/test.json'
    data=json.loads(biome.read_text())
    ok('1 Java biome climate is emitted', biome.exists())
    ok('2 Bedrock biome identifier preserved', data['minecraft:biome']['description']['identifier']=='biomemod:test')
    ok('3 climate mapped', data['minecraft:biome']['components']['minecraft:climate']=={'temperature':0.8,'downfall':0.4})
    ok('4 source biome preserved', raw.exists())
print('ALL 4 BIOME TESTS PASS')
