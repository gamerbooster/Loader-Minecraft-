from pathlib import Path
import io, json, tempfile, zipfile, hashlib, sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'android/app/src/main/python'))
from adapters.loader import detect
from adapters.modpack import inspect_modpack, build_modpack_ir
from adapters.external_fetch import fetch_modrinth_files
import nex_android_bridge

def ok(name, condition):
    print(f"{name}: " + ("PASS" if condition else "FAIL"))
    if not condition: raise SystemExit(1)

# 1: malformed Java loader manifests are explicit errors, not silent "unknown" mods.
with tempfile.TemporaryDirectory() as td:
    jar=Path(td)/'broken.jar'
    with zipfile.ZipFile(jar,'w') as z:
        z.writestr('fabric.mod.json','{"id":')
    try:
        detect(jar)
    except ValueError as exc:
        ok('1 malformed Fabric manifest is explicit', 'invalid fabric.mod.json' in str(exc))
    else:
        ok('1 malformed Fabric manifest is explicit', False)

# 2: empty ModPacks are incomplete and surfaced by the Android bridge.
with tempfile.TemporaryDirectory() as td:
    pack=Path(td)/'empty.mrpack'
    with zipfile.ZipFile(pack,'w') as z:
        z.writestr('modrinth.index.json',json.dumps({'formatVersion':1,'name':'empty','versionId':'1','files':[]}))
    info=inspect_modpack(pack)
    ok('2 empty ModPack resolution is incomplete', info['resolution'].complete is False and info['resolution'].ordered == [])
    program,res,tmp=build_modpack_ir(pack,'empty')
    try:
        ok('3 empty ModPack emits explicit diagnostic', any(d.get('code')=='EMPTY_MODPACK' for d in program.diagnostics))
        ok('4 empty ModPack emits adaptable operation', any(o.op=='modpack_empty' and o.status=='adaptable' for o in program.operations))
    finally:
        import shutil; shutil.rmtree(tmp,ignore_errors=True)
    payload=json.loads(nex_android_bridge.analyze(str(pack), True))
    ok('5 Android bridge reports empty ModPack', payload['status']=='partial' and payload['empty_modpack'] is True)

# 3: verified download remains streaming and does not require an in-memory full payload API.
class StreamingOnlyResponse:
    def __init__(self, raw, url): self.buf=io.BytesIO(raw); self.url=url
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def geturl(self): return self.url
    def read(self, n=-1):
        if n < 0: raise AssertionError('full-buffer read() forbidden')
        return self.buf.read(n)

with tempfile.TemporaryDirectory() as td:
    raw=(b'NX'*1024*1024)+b'end'
    sha1=hashlib.sha1(raw).hexdigest()
    pack={'format':'modrinth','external_files':[{'path':'mods/stream.jar','downloads':['https://cdn.modrinth.com/stream.jar'],'hashes':{'sha1':sha1},'size':len(raw)}]}
    def opener(url, timeout=30): return StreamingOnlyResponse(raw,url)
    report=fetch_modrinth_files(Path(td),pack,opener=opener)
    ok('6 external artifact verifies without full-buffer read', report['downloaded'][0]['status']=='verified')
print('ALL 6 HARDENING REGRESSION TESTS PASS')
