from pathlib import Path
import json, shutil, sys, zipfile
sys.path.insert(0, str(Path(__file__).parents[1]))
from adapters.resources import build_ir
from nex.compiler import compile_program

ROOT=Path('/tmp/nex61'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()
jar=ROOT/'audio_lang.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'audio','version':'1.0.0'}))
    z.writestr('assets/audio/lang/en_us.json',json.dumps({'item.audio:test':'Test Item','block.audio:test':'Test Block'}))
    z.writestr('assets/audio/lang/es_es.json',json.dumps({'item.audio:test':'Objeto de prueba'}))
    z.writestr('assets/audio/sounds.json',json.dumps({
        'test.step':{'category':'player','sounds':['step1',{'name':'step2','volume':0.5,'pitch':1.1}]},
        'missing':{'category':'master','sounds':['nope']}
    }))
    z.writestr('assets/audio/sounds/step1.ogg',b'OggS-test-1')
    z.writestr('assets/audio/sounds/step2.ogg',b'OggS-test-2')

_, p=build_ir(jar)
langs=[o for o in p.operations if o.op=='register_language']
sounds=[o for o in p.operations if o.op=='register_sound']
assert {o.args['locale'] for o in langs}=={'en_US','es_ES'}
assert any(o.id=='audio:test.step' and o.status=='convertible' for o in sounds)
assert any(o.id=='audio:missing' and o.status=='adaptable' for o in sounds)
print('1 localization + sound analysis: PASS')

out=compile_program(p,ROOT/'out')
texts=out/'resource_pack/texts'
assert json.loads((texts/'languages.json').read_text())==['en_US','es_ES']
assert 'item.audio:test=Test Item' in (texts/'en_US.lang').read_text()
assert 'item.audio:test=Objeto de prueba' in (texts/'es_ES.lang').read_text()
sdef=json.loads((out/'resource_pack/sounds/sound_definitions.json').read_text())
assert 'audio:test.step' in sdef['sound_definitions']
assert sdef['sound_definitions']['audio:test.step']['sounds'][0]['name']=='sounds/audio/step1'
assert (out/'resource_pack/sounds/audio/step1.ogg').read_bytes()==b'OggS-test-1'
assert not (out/'resource_pack/sounds/audio/nope.ogg').exists()
print('2 compiled localization/sound assets: PASS')

# Missing English is repaired conservatively by copying an available locale and reporting partial.
jar2=ROOT/'no_en.jar'
with zipfile.ZipFile(jar2,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('fabric.mod.json',json.dumps({'id':'noen','version':'1.0.0'}))
    z.writestr('assets/noen/lang/es_es.json',json.dumps({'item.noen:test':'Solo ES'}))
_,p2=build_ir(jar2); out2=compile_program(p2,ROOT/'out2'); r=json.loads((out2/'conversion_report.json').read_text())
assert (out2/'resource_pack/texts/en_US.lang').exists() and r['status']=='partial'
assert any(x.get('reason','').startswith('generated en_US fallback') for x in r['skipped'])
print('3 en_US fallback is explicit: PASS')

# Multiple sound definitions are valid JSON and deterministic.
assert (out/'resource_pack/sounds.json').exists()
json.loads((out/'resource_pack/sounds.json').read_text())
print('4 sound event registry JSON: PASS')
print('ALL 4 TESTS PASS')
