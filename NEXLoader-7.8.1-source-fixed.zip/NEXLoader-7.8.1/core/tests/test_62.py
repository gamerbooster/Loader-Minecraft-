from pathlib import Path
import json, shutil, sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from nex.ir import Program, Operation
from nex.compiler import compile_program
from nex.version import NEXLOADER_VERSION

ROOT=Path('/tmp/nex62'); shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir()

# 1: scripted physics emits a real proxy entity + runtime spawn bridge.
p=Program('physicsdemo',[Operation('spawn_body','physicsdemo:body',{
    'fragments':4,'gravity':0.08,'restitution':0.5,'drag':0.97,'lifetime':200,'spread':0.05,'upward':0.12
},'emulated','java','Physics.java')])
out=compile_program(p,ROOT/'physics')
assert (out/'behavior_pack/entities/nex_physics_fragment.json').exists()
assert (out/'resource_pack/entity/nex_physics_fragment.entity.json').exists()
assert (out/'resource_pack/models/geometry.nex_physics_fragment.geo.json').exists()
assert (out/'resource_pack/render_controllers/nex_physics_fragment.render_controllers.json').exists()
assert (out/'resource_pack/textures/entity/nex_physics_fragment.png').read_bytes().startswith(b'\x89PNG')
js=(out/'behavior_pack/scripts/nex_bridge.js').read_text()
assert 'spawnPhysicsBody' in js and 'nex_spawn_body_0' in js and 'physicsdemo:nex_physics_fragment' in js
manifest=json.loads((out/'behavior_pack/manifest.json').read_text())
assert any(d.get('module_name')=='@minecraft/server' for d in manifest['dependencies'])
assert manifest['metadata']['generated_with']['nexloader']==NEXLOADER_VERSION
print('1 physics proxy entity + runtime bridge: PASS')

# 2: sounds are emitted even if a pack has no localization.
p2=Program('soundsonly',[Operation('register_sound','soundsonly:test',{
    'definition':{'category':'master','sounds':[{'name':'sounds/soundsonly/test'}]},
    'assets_bytes_hex':{'assets/soundsonly/sounds/test.ogg':'4f6767532d74657374'},
    'assets':['assets/soundsonly/sounds/test.ogg']
},'convertible','fabric','assets/soundsonly/sounds.json')])
out2=compile_program(p2,ROOT/'soundsonly')
assert (out2/'resource_pack/sounds/sound_definitions.json').exists()
assert (out2/'resource_pack/sounds/soundsonly/test.ogg').read_bytes()==b'OggS-test'
print('2 sounds without language: PASS')

# 3: conflicting language keys do not silently overwrite and report partial.
p3=Program('langs',[Operation('register_language','a:en_US',{'locale':'en_US','values':{'item.x':'A'},'mod_id':'a'},'convertible','fabric'),Operation('register_language','b:en_US',{'locale':'en_US','values':{'item.x':'B'},'mod_id':'b'},'convertible','fabric')])
out3=compile_program(p3,ROOT/'langs')
r=json.loads((out3/'conversion_report.json').read_text())
assert r['status']=='partial' and r['conflicts'] and 'item.x=A' in (out3/'resource_pack/texts/en_US.lang').read_text()
assert 'item.x=B' not in (out3/'resource_pack/texts/en_US.lang').read_text()
print('3 language conflict guard: PASS')

print('ALL 3 TESTS PASS')
