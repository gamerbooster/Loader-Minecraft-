from pathlib import Path
import tempfile, zipfile, os
ROOT=Path(__file__).resolve().parents[2]
import sys; sys.path.insert(0,str(ROOT/'core'))
import adapters.modpack as modpack
from adapters.modpack import extract_pack

def ok(name, condition):
    print(f"{name}: " + ("PASS" if condition else "FAIL"))
    if not condition: raise SystemExit(1)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); work=td/'work'
    evil=td/'evil.zip'
    with zipfile.ZipFile(evil,'w') as z: z.writestr('../escape.txt','blocked')
    try: extract_pack(evil, work)
    except ValueError as e: ok('1 ZIP traversal rejected', 'unsafe archive path' in str(e))
    else: ok('1 ZIP traversal rejected', False)

    original_limit=modpack.MAX_ARCHIVE_MEMBERS; modpack.MAX_ARCHIVE_MEMBERS=1
    many=td/'many.zip'
    with zipfile.ZipFile(many,'w') as z:
        z.writestr('a.txt','a'); z.writestr('b.txt','b')
    try: extract_pack(many, td/'work_many')
    except ValueError as e: ok('2 archive member limit enforced', 'too many members' in str(e))
    else: ok('2 archive member limit enforced', False)
    modpack.MAX_ARCHIVE_MEMBERS=original_limit
print('ALL 2 ARCHIVE SAFETY TESTS PASS')
