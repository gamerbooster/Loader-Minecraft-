# NEXLoader roadmap / stages

## Completed
1. Java/JAR analysis and loader detection — done
2. NEX-IR unified representation — done
3. Resources/models/blocks/items/recipes/loot/tags/localization/sounds — done
4. Behavioral reconstruction and NEX Runtime — done
5. Fabric/Quilt/Forge/NeoForge ModPack dependency graph — done
6. Inter-mod contracts, conflicts, Jar-in-Jar, security and difficult runtime modules — done
7. Android engine bridge with the real Python converter — source-level done
10. Android ModPack analysis regression fixed — done
11. ZIP extraction safety limits and canonical path validation — done
12. Chunked external artifact fetch with size ceiling — done
13. Reproducible tests/release preflight — done
14. Compatibility campaign tooling — done
15. Conservative Java worldgen lowering for simple feature chains — done
16. Archive/Android memory hardening — done

## Remaining gate to an installable APK
8. Real Android Gradle/SDK build and APK generation — requires an Android SDK + Gradle environment
9. Install on a real Android device and verify: pick JAR/ModPack → analyze → convert → open/share `.mcaddon` → import into Minecraft Bedrock 1.26.52.3

## Ongoing compatibility expansion
17. Run the compatibility campaign against representative real-world Fabric/Forge/NeoForge/Quilt mod sets.
18. Expand complex worldgen (noise, structures, processors, jigsaw graphs) where Bedrock equivalents can be mapped without pretending Java schemas are wire-compatible.
19. Expand AI, animations, rendering and shader reconstruction where Bedrock equivalents exist; keep unsupported behavior explicit.
