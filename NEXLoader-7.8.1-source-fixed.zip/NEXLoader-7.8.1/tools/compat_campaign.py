#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text(encoding='utf-8').strip().replace('.', '_')
CORE=ROOT/'core'
if str(CORE) not in sys.path:
    sys.path.insert(0,str(CORE))

from adapters.loader import detect
from adapters.resources import build_ir
from nex.compiler import compile_program
from nex.version import NEXLOADER_VERSION

SUPPORTED_SUFFIXES={'.jar'}

def analyze_jar(path: Path, convert_root: Path|None=None):
    info, program=build_ir(path)
    statuses=Counter(o.status for o in program.operations)
    ops=Counter(o.op for o in program.operations)
    incompatible=sorted({o.id for o in program.operations if o.status=='incompatible'})
    adaptable=sorted({o.id for o in program.operations if o.status=='adaptable'})
    result={
        'file':path.name,
        'path':str(path),
        'loader':info.get('loader'),
        'mods':info.get('mods',[]),
        'mod_id':program.mod_id,
        'version':program.version,
        'status_counts':dict(sorted(statuses.items())),
        'operation_counts':dict(sorted(ops.items())),
        'incompatible':incompatible,
        'adaptable':adaptable,
        'diagnostic_count':len(program.diagnostics),
        'diagnostic_codes':sorted(Counter(d.get('code','UNKNOWN') for d in program.diagnostics)),
    }
    if convert_root is not None:
        out=convert_root/program.mod_id
        compile_program(program,out)
        report=json.loads((out/'conversion_report.json').read_text(encoding='utf-8'))
        result['conversion']={
            'status':report.get('status'),
            'missing_resources':len(report.get('missing_resources') or []),
            'skipped':len(report.get('skipped') or []),
            'conflicts':len(report.get('conflicts') or []),
            'runtime_modules':report.get('runtime_modules',[]),
            'worldgen_converted':sum(1 for x in report.get('worldgen',[]) if x.get('bedrock_plan',{}).get('bedrock_json')),
            'worldgen_total':len(report.get('worldgen',[])),
        }
    return result


def main():
    ap=argparse.ArgumentParser(description='NEXLoader compatibility campaign for a directory of Java mod JARs')
    ap.add_argument('input_dir')
    ap.add_argument('output_json')
    ap.add_argument('--convert',action='store_true',help='also compile each JAR into a sibling output directory')
    ap.add_argument('--conversion-dir',default=None)
    args=ap.parse_args()
    src=Path(args.input_dir)
    if not src.is_dir():
        raise SystemExit(f'input directory not found: {src}')
    jars=sorted(p for p in src.rglob('*') if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES)
    if not jars:
        raise SystemExit('no JAR files found')
    conv=Path(args.conversion_dir) if args.convert and args.conversion_dir else (src.parent/(src.name+'_converted') if args.convert else None)
    if conv:
        shutil.rmtree(conv,ignore_errors=True); conv.mkdir(parents=True,exist_ok=True)
    results=[]; failures=[]
    for jar in jars:
        try:
            results.append(analyze_jar(jar,conv))
        except Exception as exc:
            failures.append({'file':str(jar),'error':f'{type(exc).__name__}: {exc}'})
    loader_counts=Counter(r.get('loader','unknown') for r in results)
    status_counts=Counter()
    for r in results: status_counts.update(r.get('status_counts') or {})
    aggregate={
        'nexloader_version':NEXLOADER_VERSION,
        'input_dir':str(src),
        'jar_count':len(jars),
        'analyzed':len(results),
        'failed':len(failures),
        'loader_counts':dict(sorted(loader_counts.items())),
        'status_counts':dict(sorted(status_counts.items())),
        'incompatible_operation_ids':sorted({x for r in results for x in r.get('incompatible',[])}),
        'adaptable_operation_ids':sorted({x for r in results for x in r.get('adaptable',[])}),
        'results':results,
        'failures':failures,
    }
    out=Path(args.output_json); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(aggregate,ensure_ascii=False,indent=2,sort_keys=True),encoding='utf-8')
    print(f'NEXLoader {NEXLOADER_VERSION} compatibility campaign')
    print(f'JARs found: {len(jars)} | analyzed: {len(results)} | failed: {len(failures)}')
    print('Loaders:', ', '.join(f'{k}={v}' for k,v in sorted(loader_counts.items())))
    print('Statuses:', ', '.join(f'{k}={v}' for k,v in sorted(status_counts.items())))
    print(f'Report: {out}')
    if failures: raise SystemExit(1)

if __name__=='__main__':
    main()
