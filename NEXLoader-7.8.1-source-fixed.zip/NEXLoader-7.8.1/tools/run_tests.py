#!/usr/bin/env python3
from __future__ import annotations
import runpy, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TEST_DIR=ROOT/'core'/'tests'
tests=sorted(TEST_DIR.glob('test_*.py')) + [TEST_DIR/'stress_test.py']
passed=[]; failed=[]
for test in tests:
    try:
        runpy.run_path(str(test), run_name=f'__nex_test_{test.stem}__')
        passed.append(test)
    except SystemExit as exc:
        code=exc.code if isinstance(exc.code,int) else 1
        if code==0:
            passed.append(test)
        else:
            failed.append((test,code))
            print(f'FAIL {test.relative_to(ROOT)} (SystemExit {code})')
    except Exception:
        failed.append((test,1))
        print(f'FAIL {test.relative_to(ROOT)}')
        traceback.print_exc()
print(f'TESTS PASS: {len(passed)}')
print(f'TESTS FAIL: {len(failed)}')
if failed: raise SystemExit(1)
