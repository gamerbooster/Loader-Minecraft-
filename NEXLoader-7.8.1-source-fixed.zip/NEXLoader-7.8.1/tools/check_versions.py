#!/usr/bin/env python3
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
version = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()
checks = {
    'core': (ROOT / 'core/nex/version.py').read_text(encoding='utf-8'),
    'android-core': (ROOT / 'android/app/src/main/python/nexcore/nex/version.py').read_text(encoding='utf-8'),
    'gradle-version': (ROOT / 'android/app/build.gradle').read_text(encoding='utf-8'),
    'ui': (ROOT / 'android/app/src/main/res/values/strings.xml').read_text(encoding='utf-8'),
}
assert re.search(rf"NEXLOADER_VERSION\s*=\s*'{re.escape(version)}'", checks['core'])
assert re.search(rf"NEXLOADER_VERSION\s*=\s*'{re.escape(version)}'", checks['android-core'])
minor = int(version.split('.')[1]);
assert f'versionCode {int(version.split(".")[0]) * 10 + minor}' in checks['gradle-version']
assert f'NEXLoader {version.rsplit(".",1)[0]}' in checks['ui']
print(f'VERSION CHECK PASS: {version}')
